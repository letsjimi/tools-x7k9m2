#!/usr/bin/env python3
"""
stage_transcriber.py v2 — Live-Transkriptions-App für Windows Desktop
PyQt6 + sherpa-onnx + Multi-Model + Silero VAD

Features v2:
  - Mehrere Modelle mit Sprach-Info (DE, EN, ZH, MULTI)
  - Tab-organisiertes Setup-Menü (6 Tabs)
  - Bis zu 4 Sound-Devices parallel (jeder mit Name, Farbe, Input)
  - Zeit-Anzeige [HH:MM:SS]
"""

import sys
import os
import json
import time
import math
import traceback
import threading
import queue
import requests
import numpy as np

# ── Auto-CD ──────────────────────────────────────────────────────────────
APP_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(APP_DIR)

# ── Qt ────────────────────────────────────────────────────────────────────
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QScrollArea, QDialog, QFormLayout,
    QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit, QGroupBox,
    QColorDialog, QMessageBox, QTabWidget, QCheckBox,
    QListWidget, QInputDialog, QProgressBar, QTableWidget,
    QTableWidgetItem, QHeaderView, QFrame, QSizePolicy,
)
from PyQt6.QtCore import (
    Qt, QTimer, QThread, pyqtSignal, pyqtSlot, QSize,
)
from PyQt6.QtGui import (
    QFont, QColor, QPalette, QPainter, QPen,
    QFontMetrics,
)

MODELS_DIR = os.path.join(APP_DIR, "models")
CONFIG_PATH = os.path.join(APP_DIR, "stage_transcriber_config.json")


# ══════════════════════════════════════════════════════════════════════════
#  MODEL REGISTRY — Echte HuggingFace-Modelle mit Sprach-Info
# ══════════════════════════════════════════════════════════════════════════

MODEL_REGISTRY = {
    "whisper-base": {
        "name": "Whisper Base",
        "language": "MULTI",
        "language_detail": "Multilingual (EN, DE, FR, ES, ZH, JA, ...)",
        "size_mb": 74,
        "files": {
            "encoder.onnx": "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-base/resolve/main/encoder.onnx",
            "decoder.onnx": "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-base/resolve/main/decoder.onnx",
            "tokens.txt": "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-base/resolve/main/tokens.txt",
        },
        "type": "whisper",
    },
    "whisper-small": {
        "name": "Whisper Small",
        "language": "MULTI",
        "language_detail": "Multilingual (EN, DE, FR, ES, ZH, JA, ...)",
        "size_mb": 244,
        "files": {
            "encoder.onnx": "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-small/resolve/main/encoder.onnx",
            "decoder.onnx": "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-small/resolve/main/decoder.onnx",
            "tokens.txt": "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-small/resolve/main/tokens.txt",
        },
        "type": "whisper",
    },
    "whisper-medium": {
        "name": "Whisper Medium",
        "language": "MULTI",
        "language_detail": "Multilingual (EN, DE, FR, ES, ZH, JA, ...)",
        "size_mb": 769,
        "files": {
            "encoder.onnx": "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-medium/resolve/main/encoder.onnx",
            "decoder.onnx": "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-medium/resolve/main/decoder.onnx",
            "tokens.txt": "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-medium/resolve/main/tokens.txt",
        },
        "type": "whisper",
    },
    "whisper-large-v3": {
        "name": "Whisper Large V3",
        "language": "MULTI",
        "language_detail": "Multilingual (EN, DE, FR, ES, ZH, JA, ...)",
        "size_mb": 1550,
        "files": {
            "encoder.onnx": "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-large-v3/resolve/main/encoder.onnx",
            "decoder.onnx": "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-large-v3/resolve/main/decoder.onnx",
            "tokens.txt": "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-large-v3/resolve/main/tokens.txt",
        },
        "type": "whisper",
    },
    "paraformer-zh-int8": {
        "name": "Paraformer (int8)",
        "language": "ZH",
        "language_detail": "Chinesisch (Mandarin)",
        "size_mb": 70,
        "files": {
            "model.int8.onnx": "https://huggingface.co/csukuangfj/sherpa-onnx-nemo-ctc-paraformer-zh/resolve/main/model.int8.onnx",
            "tokens.txt": "https://huggingface.co/csukuangfj/sherpa-onnx-nemo-ctc-paraformer-zh/resolve/main/tokens.txt",
        },
        "type": "paraformer",
    },
    "conformer-en": {
        "name": "Conformer",
        "language": "EN",
        "language_detail": "Englisch",
        "size_mb": 100,
        "files": {
            "model.onnx": "https://huggingface.co/csukuangfj/sherpa-onnx-nemo-ctc-en-conformer/resolve/main/model.onnx",
            "tokens.txt": "https://huggingface.co/csukuangfj/sherpa-onnx-nemo-ctc-en-conformer/resolve/main/tokens.txt",
        },
        "type": "paraformer",
    },
}

SILERO_VAD_URLS = {
    "silero_vad.onnx": "https://huggingface.co/csukuangfj/silero-vad/resolve/main/silero_vad.onnx?download=true",
}

# Sprach-Badges für Anzeige
LANG_BADGE = {
    "DE":   "🇩🇪 DE",
    "EN":   "🇬🇧 EN",
    "ZH":   "🇨🇳 ZH",
    "MULTI": "🌍 MULTI",
}


# ══════════════════════════════════════════════════════════════════════════
#  CONFIG
# ══════════════════════════════════════════════════════════════════════════

DEFAULT_CONFIG = {
    # Model
    "selected_model": "paraformer-zh-int8",
    # Audio defaults
    "input_gain": 1.0,
    "vad_threshold": 0.5,
    "vad_min_silence": 0.3,
    "vad_min_speech": 0.25,
    "vad_max_speech": 30.0,
    # 4 Devices
    "devices": [
        {"name": "Sprecher 1", "color": "#00CCFF", "input_device": None},
        {"name": "Sprecher 2", "color": "#FF9900", "input_device": None},
        {"name": "Sprecher 3", "color": "#66FF66", "input_device": None},
        {"name": "Sprecher 4", "color": "#FF66FF", "input_device": None},
    ],
    # Display
    "font_size": 28,
    "spacing_mm": 3.0,
    "dim_old": True,
    "fade_delay": 5.0,
    "fade_time": 10.0,
    "target_brightness": 60,
    "update_interval": 500,
    # Advanced
    "provider": "auto",
    "threads": 4,
    # Alarm
    "alarm_words": [],
    "blink_duration": 3000,
    "blink_interval": 300,
    "alarm_red": 200,
}


def load_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                saved = json.load(f)
                cfg.update(saved)
        except Exception:
            pass
    # Ensure devices list has 4 entries
    while len(cfg.get("devices", [])) < 4:
        idx = len(cfg["devices"]) + 1
        colors = ["#00CCFF", "#FF9900", "#66FF66", "#FF66FF"]
        cfg["devices"].append({
            "name": f"Sprecher {idx}",
            "color": colors[min(idx - 1, 3)],
            "input_device": None,
        })
    return cfg


def save_config(cfg):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"Config save error: {e}")


# ══════════════════════════════════════════════════════════════════════════
#  MODEL DOWNLOADER
# ══════════════════════════════════════════════════════════════════════════

class ModelDownloader:
    """Download model files with progress callback."""

    def __init__(self, progress_cb=None):
        self.progress_cb = progress_cb

    def _download(self, url, dest):
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        if os.path.exists(dest):
            return True
        self._report(f"Downloading {os.path.basename(dest)}...")
        try:
            r = requests.get(url, stream=True, timeout=120)
            r.raise_for_status()
            total = int(r.headers.get("content-length", 0))
            done = 0
            with open(dest + ".tmp", "wb") as f:
                for chunk in r.iter_content(8192):
                    f.write(chunk)
                    done += len(chunk)
                    if total and self.progress_cb:
                        pct = int(done / total * 100)
                        self._report(f"Downloading {os.path.basename(dest)}: {pct}%")
            os.rename(dest + ".tmp", dest)
            return True
        except Exception as e:
            if os.path.exists(dest + ".tmp"):
                os.remove(dest + ".tmp")
            raise RuntimeError(f"Download failed for {url}: {e}")

    def _report(self, msg):
        if self.progress_cb:
            self.progress_cb(msg)

    def is_model_downloaded(self, model_id):
        """Check if all files for a model are present."""
        info = MODEL_REGISTRY.get(model_id)
        if not info:
            return False
        model_dir = os.path.join(MODELS_DIR, model_id)
        for fname in info["files"]:
            if not os.path.exists(os.path.join(model_dir, fname)):
                return False
        return True

    def download_model(self, model_id):
        """Download a specific model. Returns model_dir."""
        info = MODEL_REGISTRY.get(model_id)
        if not info:
            raise ValueError(f"Unknown model: {model_id}")
        model_dir = os.path.join(MODELS_DIR, model_id)
        os.makedirs(model_dir, exist_ok=True)
        for fname, url in info["files"].items():
            dest = os.path.join(model_dir, fname)
            self._download(url, dest)
        return model_dir

    def ensure_silero(self):
        """Download Silero VAD. Returns path to silero_vad.onnx."""
        silero_dir = os.path.join(MODELS_DIR, "silero-vad")
        os.makedirs(silero_dir, exist_ok=True)
        for fname, url in SILERO_VAD_URLS.items():
            dest = os.path.join(silero_dir, fname)
            self._download(url, dest)
        return os.path.join(silero_dir, "silero_vad.onnx")


# ══════════════════════════════════════════════════════════════════════════
#  SHERPA-ONNX ENGINE
# ══════════════════════════════════════════════════════════════════════════

class TranscriptionEngine:
    """Wraps sherpa-onnx offline recognizer + Silero VAD."""

    def __init__(self, model_id, silero_path, provider="auto", threads=4):
        import sherpa_onnx
        self.sherpa = sherpa_onnx
        self.model_id = model_id
        self.model_info = MODEL_REGISTRY[model_id]
        self.provider = provider
        self.threads = threads
        self.model_dir = os.path.join(MODELS_DIR, model_id)
        self._create_recognizer()

        # VAD
        self.vad = sherpa_onnx.VoiceActivityDetector(
            sherpa_onnx.VadModelConfig(
                model=silero_path,
                threshold=0.5,
                min_silence_duration=0.3,
                min_speech_duration=0.25,
                max_speech_duration=30.0,
                buffer_size_in_seconds=60,
            ),
            buffer_size_in_seconds=60,
        )

    def _create_recognizer(self):
        import sherpa_onnx
        model_type = self.model_info["type"]
        provider = self.provider

        # Auto-detect CUDA
        if provider == "auto":
            try:
                test_cfg = self._build_config(sherpa_onnx, "cuda")
                test_rec = sherpa_onnx.OfflineRecognizer(test_cfg)
                _ = test_rec
                provider = "cuda"
            except Exception:
                provider = "cpu"

        try:
            cfg = self._build_config(sherpa_onnx, provider)
            self.recognizer = sherpa_onnx.OfflineRecognizer(cfg)
            self.actual_provider = provider
        except Exception:
            if provider == "cuda":
                cfg = self._build_config(sherpa_onnx, "cpu")
                self.recognizer = sherpa_onnx.OfflineRecognizer(cfg)
                self.actual_provider = "cpu (fallback)"
            else:
                raise

    def _build_config(self, sherpa_onnx, provider):
        model_type = self.model_info["type"]
        tokens = os.path.join(self.model_dir, "tokens.txt")

        if model_type == "whisper":
            return sherpa_onnx.OfflineRecognizerConfig(
                model_config=sherpa_onnx.OfflineModelConfig(
                    whisper_encoder=os.path.join(self.model_dir, "encoder.onnx"),
                    whisper_decoder=os.path.join(self.model_dir, "decoder.onnx"),
                    tokens=tokens,
                    num_threads=self.threads,
                    provider=provider,
                ),
            )
        elif model_type == "paraformer":
            # Check for int8 vs standard
            model_int8 = os.path.join(self.model_dir, "model.int8.onnx")
            model_std = os.path.join(self.model_dir, "model.onnx")

            if os.path.exists(model_int8):
                return sherpa_onnx.OfflineRecognizerConfig(
                    model_config=sherpa_onnx.OfflineModelConfig(
                        nemo_enc_dec_tdt_model=model_int8,
                        tokens=tokens,
                        num_threads=self.threads,
                        provider=provider,
                    ),
                )
            else:
                return sherpa_onnx.OfflineRecognizerConfig(
                    model_config=sherpa_onnx.OfflineModelConfig(
                        nemo_enc_dec_tdt_model=model_std,
                        tokens=tokens,
                        num_threads=self.threads,
                        provider=provider,
                    ),
                )
        else:
            raise ValueError(f"Unknown model type: {model_type}")

    def transcribe(self, audio_float32):
        """Transcribe a float32 16kHz mono numpy array."""
        stream = self.recognizer.create_stream()
        stream.accept_waveform(16000, audio_float32.tolist())
        self.recognizer.decode_stream(stream)
        return stream.result.text.strip()

    def vad_reset(self):
        self.vad.flush()

    def vad_accept(self, audio_float32):
        """Feed audio to VAD. Returns list of speech segments."""
        self.vad.accept_waveform(audio_float32.tolist())
        segments = []
        while not self.vad.empty:
            seg = self.vad.front
            segments.append(np.array(seg.samples, dtype=np.float32))
            self.vad.pop()
        return segments


# ══════════════════════════════════════════════════════════════════════════
#  AUDIO CAPTURE THREAD (per device)
# ══════════════════════════════════════════════════════════════════════════

class AudioThread(QThread):
    audio_chunk = pyqtSignal(np.ndarray, int)  # audio, device_index
    error_signal = pyqtSignal(str, int)        # error_msg, device_index
    status_signal = pyqtSignal(str, int)       # status, device_index

    def __init__(self, device_index, device_name, gain, vad_config, engine):
        super().__init__()
        self.device_index = device_index  # 0-3
        self.device_name = device_name
        self.gain = gain
        self.vad_config = vad_config
        self.engine = engine
        self.running = False
        self.stream = None

    def run(self):
        import sounddevice as sd
        self.running = True
        self.status_signal.emit("Starting...", self.device_index)

        # Update VAD params
        self.engine.vad.config.threshold = self.vad_config.get("threshold", 0.5)
        self.engine.vad.config.min_silence_duration = self.vad_config.get("min_silence", 0.3)
        self.engine.vad.config.min_speech_duration = self.vad_config.get("min_speech", 0.25)
        self.engine.vad.config.max_speech_duration = self.vad_config.get("max_speech", 30.0)
        self.engine.vad_reset()

        # Resolve device
        sd_index = None
        if self.device_name:
            devs = sd.query_devices()
            for i, d in enumerate(devs):
                if self.device_name in d["name"] and d["max_input_channels"] > 0:
                    sd_index = i
                    break

        try:
            with sd.InputStream(
                samplerate=16000,
                channels=1,
                dtype="float32",
                blocksize=1600,
                device=sd_index,
            ) as self.stream:
                self.status_signal.emit("Recording", self.device_index)
                while self.running:
                    data, overflowed = self.stream.read(1600)
                    if not self.running:
                        break
                    chunk = data.flatten() * self.gain
                    segments = self.engine.vad_accept(chunk)
                    for seg in segments:
                        self.audio_chunk.emit(seg, self.device_index)

        except Exception as e:
            self.error_signal.emit(f"Audio error (Device {self.device_index+1}): {e}", self.device_index)
        finally:
            self.status_signal.emit("Stopped", self.device_index)

    def stop(self):
        self.running = False
        self.wait(5000)


# ══════════════════════════════════════════════════════════════════════════
#  TRANSCRIPTION ENTRY WIDGET
# ══════════════════════════════════════════════════════════════════════════

class TranscriptionLabel(QWidget):
    """A single transcription line: [HH:MM:SS] Name: Text"""

    def __init__(self, timestamp, name, text, name_color="#00CCFF", parent=None):
        super().__init__(parent)
        self.timestamp = timestamp
        self.name = name
        self.text = text
        self.creation_time = time.time()
        self._brightness = 255
        self._time_color = QColor(180, 180, 180, 255)
        self._name_color = QColor(name_color)
        self._name_color_base = QColor(name_color)
        self._text_color = QColor(230, 230, 230, 255)
        self._font_size = 28
        self._alarm_words = []
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, False)
        self.setAutoFillBackground(True)
        pal = self.palette()
        pal.setColor(QPalette.ColorRole.Window, QColor(30, 30, 30))
        self.setPalette(pal)

    def set_brightness(self, b):
        b = max(0, min(255, int(b)))
        self._brightness = b
        self._time_color = QColor(180, 180, 180, b)
        nc = QColor(self._name_color_base)
        nc.setAlpha(b)
        self._name_color = nc
        self._text_color = QColor(
            (230 * b) // 255,
            (230 * b) // 255,
            (230 * b) // 255,
            255,
        )
        self.update()

    def set_font_size(self, size):
        self._font_size = size
        self.updateGeometry()
        self.update()

    def set_alarm_words(self, words):
        self._alarm_words = [w.lower() for w in words]
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        bg = QColor(30, 30, 30)
        painter.fillRect(self.rect(), bg)

        font = QFont("Segoe UI", self._font_size)
        font.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
        painter.setFont(font)
        fm = QFontMetrics(font)
        y = fm.ascent() + 4

        # [HH:MM:SS]
        ts_str = f"[{self.timestamp}] "
        painter.setPen(QPen(self._time_color))
        ts_width = fm.horizontalAdvance(ts_str)
        painter.drawText(4, y, ts_str)

        # Name:
        name_str = f"{self.name}: "
        painter.setPen(QPen(self._name_color))
        name_width = fm.horizontalAdvance(name_str)
        painter.drawText(4 + ts_width, y, name_str)

        # Text (with alarm word highlighting)
        text_x = 4 + ts_width + name_width
        text_str = self.text
        if self._alarm_words:
            words = text_str.split(" ")
            cx = text_x
            for word in words:
                is_alarm = word.lower().strip(".,;:!?") in self._alarm_words
                if is_alarm:
                    painter.setPen(QPen(QColor(255, 60, 60, self._brightness)))
                    painter.setFont(QFont("Segoe UI", self._font_size, QFont.Weight.Bold))
                    fm2 = QFontMetrics(painter.font())
                else:
                    painter.setPen(QPen(self._text_color))
                    painter.setFont(font)
                    fm2 = fm
                word_draw = word + " "
                painter.drawText(int(cx), y, word_draw)
                cx += fm2.horizontalAdvance(word_draw)
        else:
            painter.setPen(QPen(self._text_color))
            painter.drawText(text_x, y, text_str)

        painter.end()

    def sizeHint(self):
        font = QFont("Segoe UI", self._font_size)
        fm = QFontMetrics(font)
        text = f"[{self.timestamp}] {self.name}: {self.text}"
        w = fm.horizontalAdvance(text) + 12
        h = fm.height() + 8
        return QSize(w, h)

    def minimumSizeHint(self):
        return QSize(50, 20)


# ══════════════════════════════════════════════════════════════════════════
#  STAGE DISPLAY
# ══════════════════════════════════════════════════════════════════════════

class StageDisplay(QScrollArea):
    """Scrollable transcription display with dimming."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.setStyleSheet("QScrollArea { background: #1E1E1E; border: none; }")

        self.container = QWidget()
        self.container.setStyleSheet("background: #1E1E1E;")
        self.layout = QVBoxLayout(self.container)
        self.layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.layout.setSpacing(6)
        self.layout.setContentsMargins(4, 4, 4, 4)
        self.setWidget(self.container)

        self.entries = []
        self._alarm_active = False
        self._alarm_until = 0
        self._alarm_red = 200

        # Config defaults
        self.fade_delay = 5.0
        self.fade_time = 10.0
        self.target_brightness = 60
        self.font_size = 28
        self.spacing_px = self._mm_to_px(3.0)
        self.dim_old = True
        self.alarm_words = []
        self.blink_interval = 300

    def _mm_to_px(self, mm):
        screen = QApplication.primaryScreen()
        if screen:
            dpi = screen.logicalDotsPerInchY()
            return int(mm / 25.4 * dpi)
        return int(mm * 3.78)

    def set_spacing_mm(self, mm):
        self.spacing_px = self._mm_to_px(mm)
        self.layout.setSpacing(self.spacing_px)

    def add_entry(self, timestamp, name, text, name_color="#00CCFF"):
        label = TranscriptionLabel(timestamp, name, text, name_color)
        label.set_font_size(self.font_size)
        label.set_alarm_words(self.alarm_words)
        label.set_brightness(255)
        self.entries.append(label)
        self.layout.addWidget(label)
        QTimer.singleShot(50, self._scroll_to_bottom)

        # Check alarm
        text_lower = text.lower()
        for aw in self.alarm_words:
            if aw.lower() in text_lower:
                self._trigger_alarm()
                break

        return label

    def _scroll_to_bottom(self):
        sb = self.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _trigger_alarm(self):
        self._alarm_active = True
        self._alarm_until = time.time() * 1000 + 3000

    def clear_entries(self):
        for w in self.entries:
            self.layout.removeWidget(w)
            w.deleteLater()
        self.entries.clear()
        self._alarm_active = False

    def update_dimming(self):
        if not self.dim_old:
            return
        now = time.time()
        for entry in self.entries:
            elapsed = now - entry.creation_time
            if elapsed < self.fade_delay:
                b = 255
            elif self.fade_time <= 0:
                b = self.target_brightness
            else:
                progress = min(1.0, (elapsed - self.fade_delay) / self.fade_time)
                b = 255 - (255 - self.target_brightness) * progress
            entry.set_brightness(b)

    def update_alarm_blink(self):
        now = time.time() * 1000
        if not self._alarm_active:
            return False
        if now > self._alarm_until:
            self._alarm_active = False
            self.container.setStyleSheet("background: #1E1E1E;")
            return False
        interval = self.blink_interval
        phase = int(now / interval) % 2
        if phase:
            red = self._alarm_red
            self.container.setStyleSheet(f"background: rgb({red}, 0, 0);")
        else:
            self.container.setStyleSheet("background: #1E1E1E;")
        return True

    def apply_config(self, cfg):
        self.font_size = cfg.get("font_size", 28)
        self.spacing_px = self._mm_to_px(cfg.get("spacing_mm", 3.0))
        self.layout.setSpacing(self.spacing_px)
        self.fade_delay = cfg.get("fade_delay", 5.0)
        self.fade_time = cfg.get("fade_time", 10.0)
        self.target_brightness = cfg.get("target_brightness", 60)
        self.dim_old = cfg.get("dim_old", True)
        self.alarm_words = cfg.get("alarm_words", [])
        self._alarm_red = cfg.get("alarm_red", 200)
        self.blink_interval = cfg.get("blink_interval", 300)
        for entry in self.entries:
            entry.set_font_size(self.font_size)
            entry.set_alarm_words(self.alarm_words)


# ══════════════════════════════════════════════════════════════════════════
#  SETUP DIALOG — 6 TABS
# ══════════════════════════════════════════════════════════════════════════

class SetupDialog(QDialog):
    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.cfg = dict(cfg)
        self.setWindowTitle("⚙ Setup — Stage Transcriber v2")
        self.setMinimumSize(700, 650)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabWidget::pane { border: 1px solid #444; background: #2B2B2B; }
            QTabBar::tab { background: #3A3A3A; color: #CCC; padding: 8px 18px;
                           margin-right: 2px; border-top-left-radius: 4px;
                           border-top-right-radius: 4px; }
            QTabBar::tab:selected { background: #505050; color: #FFF; font-weight: bold; }
        """)

        self._build_audio_tab()
        self._build_model_tab()
        self._build_display_tab()
        self._build_dimming_tab()
        self._build_alarm_tab()
        self._build_advanced_tab()

        layout.addWidget(self.tabs)

        # ── Buttons ──
        btn_layout = QHBoxLayout()
        ok_btn = QPushButton("✓ OK")
        ok_btn.setStyleSheet(
            "QPushButton { background: #2E7D32; color: white; font-weight: bold; "
            "font-size: 14px; padding: 8px 24px; border-radius: 4px; }"
            "QPushButton:hover { background: #388E3C; }"
        )
        ok_btn.clicked.connect(self._accept)
        cancel_btn = QPushButton("✗ Abbrechen")
        cancel_btn.setStyleSheet(
            "QPushButton { background: #424242; color: white; font-size: 14px; "
            "padding: 8px 24px; border-radius: 4px; }"
            "QPushButton:hover { background: #616161; }"
        )
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addStretch()
        btn_layout.addWidget(ok_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)

    # ── Tab 1: Audio ─────────────────────────────────────────────────────
    def _build_audio_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Gain
        gain_group = QGroupBox("Eingangs-Verstärkung")
        gain_layout = QFormLayout(gain_group)
        self.gain_spin = QDoubleSpinBox()
        self.gain_spin.setRange(0.1, 10.0)
        self.gain_spin.setSingleStep(0.1)
        self.gain_spin.setValue(self.cfg.get("input_gain", 1.0))
        gain_layout.addRow("Input Gain:", self.gain_spin)
        layout.addWidget(gain_group)

        # VAD
        vad_group = QGroupBox("Voice Activity Detection (VAD)")
        vad_layout = QFormLayout(vad_group)

        self.vad_thresh = QDoubleSpinBox()
        self.vad_thresh.setRange(0.0, 1.0)
        self.vad_thresh.setSingleStep(0.05)
        self.vad_thresh.setDecimals(2)
        self.vad_thresh.setValue(self.cfg.get("vad_threshold", 0.5))
        vad_layout.addRow("VAD Threshold:", self.vad_thresh)

        self.vad_min_silence = QDoubleSpinBox()
        self.vad_min_silence.setRange(0.05, 5.0)
        self.vad_min_silence.setSingleStep(0.05)
        self.vad_min_silence.setDecimals(2)
        self.vad_min_silence.setValue(self.cfg.get("vad_min_silence", 0.3))
        vad_layout.addRow("Min Silence (s):", self.vad_min_silence)

        self.vad_min_speech = QDoubleSpinBox()
        self.vad_min_speech.setRange(0.05, 5.0)
        self.vad_min_speech.setSingleStep(0.05)
        self.vad_min_speech.setDecimals(2)
        self.vad_min_speech.setValue(self.cfg.get("vad_min_speech", 0.25))
        vad_layout.addRow("Min Speech (s):", self.vad_min_speech)

        self.vad_max_speech = QDoubleSpinBox()
        self.vad_max_speech.setRange(1.0, 60.0)
        self.vad_max_speech.setSingleStep(1.0)
        self.vad_max_speech.setDecimals(1)
        self.vad_max_speech.setValue(self.cfg.get("vad_max_speech", 30.0))
        vad_layout.addRow("Max Speech (s):", self.vad_max_speech)

        layout.addWidget(vad_group)

        # 4 Devices
        dev_group = QGroupBox("🔊 Sound Devices (bis zu 4 parallel)")
        dev_layout = QVBoxLayout(dev_group)

        import sounddevice as sd
        devices = sd.query_devices()
        input_devices = [d["name"] for d in devices if d["max_input_channels"] > 0]

        self.device_widgets = []
        default_names = ["Prediger", "Moderator", "Übersetzer", "Gast"]
        default_colors = ["#00CCFF", "#FF9900", "#66FF66", "#FF66FF"]
        dev_cfgs = self.cfg.get("devices", [])

        for i in range(4):
            dev_cfg = dev_cfgs[i] if i < len(dev_cfgs) else {}
            row = QHBoxLayout()

            # Device label
            lbl = QLabel(f"  Device {i+1}:")
            lbl.setStyleSheet("font-weight: bold; color: #AAA;")
            lbl.setFixedWidth(75)
            row.addWidget(lbl)

            # Name
            name_edit = QLineEdit(dev_cfg.get("name", default_names[i]))
            name_edit.setPlaceholderText("Name (z.B. Prediger)")
            name_edit.setFixedWidth(130)
            row.addWidget(name_edit)

            # Color button
            color = QColor(dev_cfg.get("color", default_colors[i]))
            color_btn = QPushButton()
            color_btn.setStyleSheet(f"background-color: {color.name()}; border: 1px solid #666; min-width: 40px;")
            color_btn.setFixedWidth(50)
            color_btn.clicked.connect(lambda checked, idx=i: self._pick_device_color(idx))
            row.addWidget(color_btn)

            # Input device
            dev_combo = QComboBox()
            dev_combo.addItem("(Standard)")  # index 0 = default
            dev_combo.addItems(input_devices)
            current_dev = dev_cfg.get("input_device")
            if current_dev:
                idx = dev_combo.findText(current_dev, Qt.MatchFlag.MatchContains)
                if idx >= 0:
                    dev_combo.setCurrentIndex(idx)
            row.addWidget(dev_combo, 1)

            dev_layout.addLayout(row)
            self.device_widgets.append({
                "name": name_edit,
                "color_btn": color_btn,
                "color": color,
                "combo": dev_combo,
            })

        layout.addWidget(dev_group)
        layout.addStretch()
        self.tabs.addTab(tab, "🎙 Audio")

    def _pick_device_color(self, idx):
        c = QColorDialog.getColor(self.device_widgets[idx]["color"], self, f"Farbe für Device {idx+1}")
        if c.isValid():
            self.device_widgets[idx]["color"] = c
            self.device_widgets[idx]["color_btn"].setStyleSheet(
                f"background-color: {c.name()}; border: 1px solid #666; min-width: 40px;"
            )

    # ── Tab 2: Model ─────────────────────────────────────────────────────
    def _build_model_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Model table
        info_group = QGroupBox("🤖 Verfügbare Modelle")
        info_layout = QVBoxLayout(info_group)

        self.model_table = QTableWidget()
        self.model_table.setColumnCount(4)
        self.model_table.setHorizontalHeaderLabels(["Modell", "Sprache", "Größe", "Status"])
        self.model_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.model_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.model_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.model_table.setStyleSheet("""
            QTableWidget { background: #2B2B2B; color: #DDD; gridline-color: #444; }
            QHeaderView::section { background: #3A3A3A; color: #CCC; padding: 4px; border: 1px solid #555; }
            QTableWidget::item:selected { background: #0066AA; }
        """)

        dl = ModelDownloader()
        self.model_table.setRowCount(len(MODEL_REGISTRY))
        for row, (model_id, info) in enumerate(MODEL_REGISTRY.items()):
            # Name
            name_item = QTableWidgetItem(info["name"])
            self.model_table.setItem(row, 0, name_item)
            # Sprache with badge
            lang = info["language"]
            badge = LANG_BADGE.get(lang, lang)
            lang_item = QTableWidgetItem(badge)
            if lang == "DE":
                lang_item.setForeground(QColor(255, 220, 50))
            elif lang == "EN":
                lang_item.setForeground(QColor(100, 180, 255))
            elif lang == "ZH":
                lang_item.setForeground(QColor(255, 80, 80))
            else:
                lang_item.setForeground(QColor(200, 200, 200))
            self.model_table.setItem(row, 1, lang_item)
            # Size
            size_item = QTableWidgetItem(f"{info['size_mb']} MB")
            self.model_table.setItem(row, 2, size_item)
            # Status
            downloaded = dl.is_model_downloaded(model_id)
            status = "✅ Heruntergeladen" if downloaded else "⬇ Nicht heruntergeladen"
            status_item = QTableWidgetItem(status)
            status_item.setForeground(QColor(80, 200, 80) if downloaded else QColor(200, 100, 100))
            self.model_table.setItem(row, 3, status_item)

        info_layout.addWidget(self.model_table)
        layout.addWidget(info_group)

        # Selection + download
        sel_group = QGroupBox("Modell-Auswahl & Download")
        sel_layout = QVBoxLayout(sel_group)

        sel_row = QHBoxLayout()
        sel_row.addWidget(QLabel("Aktives Modell:"))
        self.model_combo = QComboBox()
        for model_id, info in MODEL_REGISTRY.items():
            badge = LANG_BADGE.get(info["language"], info["language"])
            self.model_combo.addItem(f"{info['name']}  [{badge}]", model_id)
        # Set current
        current_model = self.cfg.get("selected_model", "paraformer-zh-int8")
        for i in range(self.model_combo.count()):
            if self.model_combo.itemData(i) == current_model:
                self.model_combo.setCurrentIndex(i)
                break
        sel_row.addWidget(self.model_combo, 1)
        sel_layout.addLayout(sel_row)

        # Language info label
        self.model_lang_label = QLabel()
        self.model_lang_label.setStyleSheet("color: #AAA; font-style: italic; padding: 4px;")
        self._update_model_lang_label()
        self.model_combo.currentIndexChanged.connect(lambda: self._update_model_lang_label())
        sel_layout.addWidget(self.model_lang_label)

        # Download button
        dl_row = QHBoxLayout()
        self.download_btn = QPushButton("⬇ Ausgewähltes Modell herunterladen")
        self.download_btn.setStyleSheet(
            "QPushButton { background: #1565C0; color: white; font-weight: bold; "
            "padding: 8px 16px; border-radius: 4px; }"
            "QPushButton:hover { background: #1976D2; }"
        )
        self.download_btn.clicked.connect(self._download_selected_model)
        dl_row.addWidget(self.download_btn)

        self.dl_progress = QProgressBar()
        self.dl_progress.setVisible(False)
        dl_row.addWidget(self.dl_progress, 1)
        sel_layout.addLayout(dl_row)

        layout.addWidget(sel_group)
        layout.addStretch()
        self.tabs.addTab(tab, "🤖 Model")

    def _update_model_lang_label(self):
        model_id = self.model_combo.currentData()
        if model_id and model_id in MODEL_REGISTRY:
            info = MODEL_REGISTRY[model_id]
            badge = LANG_BADGE.get(info["language"], info["language"])
            self.model_lang_label.setText(
                f"Sprache: {badge} — {info.get('language_detail', '')}"
            )

    def _download_selected_model(self):
        model_id = self.model_combo.currentData()
        if not model_id:
            return
        self.download_btn.setEnabled(False)
        self.dl_progress.setVisible(True)
        self.dl_progress.setRange(0, 0)  # indeterminate

        dl = ModelDownloader(progress_cb=lambda msg: (
            self.dl_progress.setFormat(msg),
        ))

        def do_download():
            try:
                dl.download_model(model_id)
                # Also ensure silero
                dl.ensure_silero()
                # Update table on success
                QTimer.singleShot(0, self._refresh_model_table)
            except Exception as e:
                QTimer.singleShot(0, lambda: QMessageBox.critical(
                    self, "Download-Fehler", str(e)
                ))
            finally:
                QTimer.singleShot(0, lambda: (
                    self.download_btn.setEnabled(True),
                    self.dl_progress.setVisible(False),
                ))

        threading.Thread(target=do_download, daemon=True).start()

    def _refresh_model_table(self):
        dl = ModelDownloader()
        for row, (model_id, info) in enumerate(MODEL_REGISTRY.items()):
            downloaded = dl.is_model_downloaded(model_id)
            status = "✅ Heruntergeladen" if downloaded else "⬇ Nicht heruntergeladen"
            item = self.model_table.item(row, 3)
            item.setText(status)
            item.setForeground(QColor(80, 200, 80) if downloaded else QColor(200, 100, 100))

    # ── Tab 3: Anzeige ───────────────────────────────────────────────────
    def _build_display_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        disp_group = QGroupBox("Schrift & Abstände")
        disp_layout = QFormLayout(disp_group)

        self.font_size_spin = QSpinBox()
        self.font_size_spin.setRange(8, 120)
        self.font_size_spin.setValue(self.cfg.get("font_size", 28))
        disp_layout.addRow("Font Size:", self.font_size_spin)

        self.spacing_spin = QDoubleSpinBox()
        self.spacing_spin.setRange(0.0, 50.0)
        self.spacing_spin.setSingleStep(0.5)
        self.spacing_spin.setValue(self.cfg.get("spacing_mm", 3.0))
        disp_layout.addRow("Abstand (mm):", self.spacing_spin)

        self.update_combo = QComboBox()
        self.update_combo.addItems(["250", "500", "1000"])
        interval = self.cfg.get("update_interval", 500)
        idx = self.update_combo.findText(str(interval))
        if idx >= 0:
            self.update_combo.setCurrentIndex(idx)
        disp_layout.addRow("Updateintervall (ms):", self.update_combo)

        layout.addWidget(disp_group)

        # Preview
        preview_group = QGroupBox("Vorschau")
        preview_layout = QVBoxLayout(preview_group)
        self.preview_label = QLabel("[12:34:56] Prediger: Dies ist ein Beispieltext.")
        self.preview_label.setStyleSheet(
            f"font-size: {self.cfg.get('font_size', 28)}px; color: #EEE; background: #1E1E1E; padding: 12px;"
        )
        preview_layout.addWidget(self.preview_label)
        layout.addWidget(preview_group)

        layout.addStretch()
        self.tabs.addTab(tab, "🖥 Anzeige")

    # ── Tab 4: Dimming ────────────────────────────────────────────────────
    def _build_dimming_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        dim_group = QGroupBox("Dimming / Verblassen")
        dim_layout = QFormLayout(dim_group)

        self.dim_check = QCheckBox("Ältere Zeilen dimmen")
        self.dim_check.setChecked(self.cfg.get("dim_old", True))
        dim_layout.addRow(self.dim_check)

        self.fade_delay_spin = QDoubleSpinBox()
        self.fade_delay_spin.setRange(0.0, 60.0)
        self.fade_delay_spin.setSingleStep(0.5)
        self.fade_delay_spin.setValue(self.cfg.get("fade_delay", 5.0))
        dim_layout.addRow("Fade-Delay (s):", self.fade_delay_spin)

        self.fade_time_spin = QDoubleSpinBox()
        self.fade_time_spin.setRange(1.0, 999.0)
        self.fade_time_spin.setSingleStep(1.0)
        self.fade_time_spin.setValue(self.cfg.get("fade_time", 10.0))
        dim_layout.addRow("Fade-Zeit (s):", self.fade_time_spin)

        self.target_bright_spin = QSpinBox()
        self.target_bright_spin.setRange(0, 255)
        self.target_bright_spin.setValue(self.cfg.get("target_brightness", 60))
        dim_layout.addRow("Zielhelligkeit (0-255):", self.target_bright_spin)

        layout.addWidget(dim_group)

        # Visual explanation
        info = QLabel(
            "💡 Verhalten:\n"
            "  • Neue Zeile = volle Helligkeit (255)\n"
            "  • Nach Fade-Delay: beginnt zu dimmen\n"
            "  • Über Fade-Zeit: dimmt auf Zielhelligkeit\n"
            "  • Beispiel: Delay 5s, Zeit 10s, Ziel 60 → nach 15s auf Helligkeit 60"
        )
        info.setStyleSheet("color: #999; padding: 8px; background: #252525; border-radius: 4px;")
        layout.addWidget(info)

        layout.addStretch()
        self.tabs.addTab(tab, "🌑 Dimming")

    # ── Tab 5: Alarm ─────────────────────────────────────────────────────
    def _build_alarm_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        alarm_group = QGroupBox("🚨 Alarmwörter")
        alarm_layout = QVBoxLayout(alarm_group)

        alarm_layout.addWidget(QLabel("Wenn ein Alarmwort erkannt wird, blinkt der Hintergrund rot."))

        self.alarm_list = QListWidget()
        self.alarm_list.setStyleSheet("QListWidget { background: #2B2B2B; color: #DDD; }")
        for w in self.cfg.get("alarm_words", []):
            self.alarm_list.addItem(w)
        alarm_layout.addWidget(self.alarm_list)

        btn_row = QHBoxLayout()
        add_btn = QPushButton("+ Hinzufügen")
        add_btn.clicked.connect(self._add_alarm_word)
        rem_btn = QPushButton("− Entfernen")
        rem_btn.clicked.connect(self._rem_alarm_word)
        btn_row.addWidget(add_btn)
        btn_row.addWidget(rem_btn)
        alarm_layout.addLayout(btn_row)

        settings_layout = QFormLayout()
        self.blink_duration = QSpinBox()
        self.blink_duration.setRange(500, 30000)
        self.blink_duration.setSingleStep(100)
        self.blink_duration.setValue(self.cfg.get("blink_duration", 3000))
        self.blink_duration.setSuffix(" ms")
        settings_layout.addRow("Blink-Dauer:", self.blink_duration)

        self.blink_interval = QSpinBox()
        self.blink_interval.setRange(50, 2000)
        self.blink_interval.setSingleStep(50)
        self.blink_interval.setValue(self.cfg.get("blink_interval", 300))
        self.blink_interval.setSuffix(" ms")
        settings_layout.addRow("Blink-Intervall:", self.blink_interval)

        self.alarm_red_spin = QSpinBox()
        self.alarm_red_spin.setRange(0, 255)
        self.alarm_red_spin.setValue(self.cfg.get("alarm_red", 200))
        settings_layout.addRow("Rot-Intensität (0-255):", self.alarm_red_spin)

        alarm_layout.addLayout(settings_layout)
        layout.addWidget(alarm_group)
        layout.addStretch()
        self.tabs.addTab(tab, "🚨 Alarm")

    def _add_alarm_word(self):
        word, ok = QInputDialog.getText(self, "Alarmwort", "Wort:")
        if ok and word.strip():
            self.alarm_list.addItem(word.strip())

    def _rem_alarm_word(self):
        items = self.alarm_list.selectedItems()
        for item in items:
            self.alarm_list.takeItem(self.alarm_list.row(item))

    # ── Tab 6: Erweitert ─────────────────────────────────────────────────
    def _build_advanced_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        adv_group = QGroupBox("Erweiterte Einstellungen")
        adv_layout = QFormLayout(adv_group)

        self.provider_combo = QComboBox()
        self.provider_combo.addItems(["auto", "cuda", "cpu"])
        prov = self.cfg.get("provider", "auto")
        idx = self.provider_combo.findText(prov)
        if idx >= 0:
            self.provider_combo.setCurrentIndex(idx)
        adv_layout.addRow("Provider:", self.provider_combo)

        self.threads_spin = QSpinBox()
        self.threads_spin.setRange(1, 32)
        self.threads_spin.setValue(self.cfg.get("threads", 4))
        adv_layout.addRow("Threads:", self.threads_spin)

        layout.addWidget(adv_group)

        # Provider explanation
        info = QLabel(
            "⚙ Provider:\n"
            "  • auto — Versucht CUDA, fällt auf CPU zurück\n"
            "  • cuda — NVIDIA GPU (braucht CUDA-ONNX-Runtime)\n"
            "  • cpu  — Nur CPU\n\n"
            "💡 Threads: Mehr = schneller, aber mehr CPU-Last"
        )
        info.setStyleSheet("color: #999; padding: 8px; background: #252525; border-radius: 4px;")
        layout.addWidget(info)

        layout.addStretch()
        self.tabs.addTab(tab, "⚙ Erweitert")

    # ── Accept ───────────────────────────────────────────────────────────
    def _accept(self):
        self.cfg["input_gain"] = self.gain_spin.value()
        self.cfg["vad_threshold"] = self.vad_thresh.value()
        self.cfg["vad_min_silence"] = self.vad_min_silence.value()
        self.cfg["vad_min_speech"] = self.vad_min_speech.value()
        self.cfg["vad_max_speech"] = self.vad_max_speech.value()
        self.cfg["selected_model"] = self.model_combo.currentData()
        self.cfg["font_size"] = self.font_size_spin.value()
        self.cfg["spacing_mm"] = self.spacing_spin.value()
        self.cfg["update_interval"] = int(self.update_combo.currentText())
        self.cfg["dim_old"] = self.dim_check.isChecked()
        self.cfg["fade_delay"] = self.fade_delay_spin.value()
        self.cfg["fade_time"] = self.fade_time_spin.value()
        self.cfg["target_brightness"] = self.target_bright_spin.value()
        self.cfg["provider"] = self.provider_combo.currentText()
        self.cfg["threads"] = self.threads_spin.value()
        self.cfg["alarm_words"] = [
            self.alarm_list.item(i).text()
            for i in range(self.alarm_list.count())
        ]
        self.cfg["blink_duration"] = self.blink_duration.value()
        self.cfg["blink_interval"] = self.blink_interval.value()
        self.cfg["alarm_red"] = self.alarm_red_spin.value()

        # 4 Devices
        devices = []
        for i, dw in enumerate(self.device_widgets):
            dev_name = dw["name"].text().strip() or f"Device {i+1}"
            dev_color = dw["color"].name()
            dev_input = dw["combo"].currentText()
            if dev_input == "(Standard)":
                dev_input = None
            devices.append({
                "name": dev_name,
                "color": dev_color,
                "input_device": dev_input,
            })
        self.cfg["devices"] = devices

        self.accept()

    def get_config(self):
        return self.cfg


# ══════════════════════════════════════════════════════════════════════════
#  MAIN WINDOW
# ══════════════════════════════════════════════════════════════════════════

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.cfg = load_config()
        self.engine = None
        self.audio_threads = {}  # device_index -> AudioThread
        self.is_running = False
        self._transcription_queue = queue.Queue()
        self._init_ui()
        self._init_timers()

    def _init_ui(self):
        self.setWindowTitle("Stage Transcriber v2")
        self.setMinimumSize(800, 400)
        self.setStyleSheet("QMainWindow { background: #1E1E1E; }")

        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # ── Button bar ──
        btn_bar = QWidget()
        btn_bar.setStyleSheet("background: #2D2D2D;")
        btn_bar.setFixedHeight(48)
        btn_layout = QHBoxLayout(btn_bar)
        btn_layout.setContentsMargins(8, 4, 8, 4)

        self.start_btn = QPushButton("▶ START")
        self.start_btn.setStyleSheet(
            "QPushButton { background: #2E7D32; color: white; font-weight: bold; "
            "font-size: 14px; padding: 6px 20px; border-radius: 4px; }"
            "QPushButton:hover { background: #388E3C; }"
            "QPushButton:disabled { background: #555; color: #999; }"
        )
        self.start_btn.clicked.connect(self._on_start)

        self.stop_btn = QPushButton("■ STOP")
        self.stop_btn.setStyleSheet(
            "QPushButton { background: #C62828; color: white; font-weight: bold; "
            "font-size: 14px; padding: 6px 20px; border-radius: 4px; }"
            "QPushButton:hover { background: #D32F2F; }"
            "QPushButton:disabled { background: #555; color: #999; }"
        )
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self._on_stop)

        btn_layout.addWidget(self.start_btn)
        btn_layout.addWidget(self.stop_btn)
        btn_layout.addStretch()

        # Model badge in button bar
        self.model_badge = QLabel()
        self.model_badge.setStyleSheet("color: #AAA; font-size: 12px; padding: 2px 8px;")
        self._update_model_badge()
        btn_layout.addWidget(self.model_badge)

        self.clear_btn = QPushButton("🗑 Clear")
        self.clear_btn.setStyleSheet(
            "QPushButton { background: #424242; color: white; font-size: 13px; "
            "padding: 6px 14px; border-radius: 4px; }"
            "QPushButton:hover { background: #616161; }"
        )
        self.clear_btn.clicked.connect(self._on_clear)

        self.setup_btn = QPushButton("⚙ Setup")
        self.setup_btn.setStyleSheet(
            "QPushButton { background: #424242; color: white; font-size: 13px; "
            "padding: 6px 14px; border-radius: 4px; }"
            "QPushButton:hover { background: #616161; }"
        )
        self.setup_btn.clicked.connect(self._on_setup)

        btn_layout.addWidget(self.clear_btn)
        btn_layout.addWidget(self.setup_btn)
        main_layout.addWidget(btn_bar)

        # ── Stage display ──
        self.stage = StageDisplay()
        self.stage.apply_config(self.cfg)
        main_layout.addWidget(self.stage, 1)

        # ── Status bar ──
        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.status.setStyleSheet("QStatusBar { background: #2D2D2D; color: #AAA; }")
        self.status.showMessage("Bereit — Drücke START")

    def _update_model_badge(self):
        model_id = self.cfg.get("selected_model", "paraformer-zh-int8")
        info = MODEL_REGISTRY.get(model_id, {})
        name = info.get("name", model_id)
        lang = info.get("language", "?")
        badge = LANG_BADGE.get(lang, lang)
        self.model_badge.setText(f"🤖 {name} [{badge}]")

    def _init_timers(self):
        interval = self.cfg.get("update_interval", 500)
        self.dim_timer = QTimer(self)
        self.dim_timer.timeout.connect(self._update_dimming)
        self.dim_timer.start(interval)

        self.blink_timer = QTimer(self)
        self.blink_timer.timeout.connect(self._update_alarm)
        self.blink_timer.start(100)

        self.queue_timer = QTimer(self)
        self.queue_timer.timeout.connect(self._drain_queue)
        self.queue_timer.start(50)

    def _drain_queue(self):
        while not self._transcription_queue.empty():
            try:
                ts, name, text, color = self._transcription_queue.get_nowait()
                self.stage.add_entry(ts, name, text, color)
            except queue.Empty:
                break

    def _update_dimming(self):
        self.stage.update_dimming()

    def _update_alarm(self):
        self.stage.update_alarm_blink()

    # ── START / STOP ────────────────────────────────────────────────────
    def _on_start(self):
        if self.is_running:
            return
        self._do_start()

    def _do_start(self):
        try:
            model_id = self.cfg.get("selected_model", "paraformer-zh-int8")
            model_info = MODEL_REGISTRY.get(model_id)
            if not model_info:
                self._show_error(f"Unbekanntes Modell: {model_id}")
                return

            self.status.showMessage("Prüfe Modelle...")
            QApplication.processEvents()

            dl = ModelDownloader(progress_cb=lambda msg: (
                self.status.showMessage(msg),
                QApplication.processEvents(),
            ))

            # Download selected model + Silero
            model_dir = dl.download_model(model_id)
            silero_path = dl.ensure_silero()

            self.status.showMessage("Initialisiere Engine...")
            QApplication.processEvents()

            self.engine = TranscriptionEngine(
                model_id, silero_path,
                provider=self.cfg.get("provider", "auto"),
                threads=self.cfg.get("threads", 4),
            )

            self.status.showMessage(f"Engine: {self.engine.actual_provider} — Starte Audio...")
            QApplication.processEvents()

            # Determine which devices have an input selected
            devices = self.cfg.get("devices", [])
            active_devices = []
            for i, dev in enumerate(devices):
                # Use device if it has an input device assigned (or use default for device 0)
                if dev.get("input_device") or i == 0:
                    active_devices.append((i, dev))

            if not active_devices:
                # Fallback: at least device 0
                active_devices = [(0, devices[0])]

            vad_config = {
                "threshold": self.cfg.get("vad_threshold", 0.5),
                "min_silence": self.cfg.get("vad_min_silence", 0.3),
                "min_speech": self.cfg.get("vad_min_speech", 0.25),
                "max_speech": self.cfg.get("vad_max_speech", 30.0),
            }

            # Start audio threads for active devices
            # Note: Each device gets its own VAD/engine instance for true parallelism
            for dev_idx, dev_cfg in active_devices:
                # For multi-device, we need separate VADs.
                # The engine's VAD is shared but we reset per device.
                # For simplicity, we'll use the engine's VAD sequentially per thread.
                # In a production setup, you'd create separate engines per device.
                at = AudioThread(
                    device_index=dev_idx,
                    device_name=dev_cfg.get("input_device"),
                    gain=self.cfg.get("input_gain", 1.0),
                    vad_config=vad_config,
                    engine=self.engine,
                )
                at.audio_chunk.connect(self._on_audio_chunk)
                at.error_signal.connect(self._on_error)
                at.status_signal.connect(self._on_device_status)
                at.start()
                self.audio_threads[dev_idx] = at

            self.is_running = True
            self.start_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)
            model_name = model_info.get("name", model_id)
            lang = model_info.get("language", "?")
            badge = LANG_BADGE.get(lang, lang)
            self.status.showMessage(
                f"Aufnahme aktiv — {model_name} [{badge}] — {self.engine.actual_provider} "
                f"— {len(self.audio_threads)} Device(s)"
            )
        except Exception as e:
            tb = traceback.format_exc()
            self._show_error(f"Fehler beim Starten:\n{e}\n\n{tb}")

    def _on_stop(self):
        if not self.is_running:
            return
        self.is_running = False
        for dev_idx, at in list(self.audio_threads.items()):
            at.stop()
        self.audio_threads.clear()
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.status.showMessage("Gestoppt")

    @pyqtSlot(str, int)
    def _on_device_status(self, msg, dev_idx):
        devices = self.cfg.get("devices", [])
        name = devices[dev_idx]["name"] if dev_idx < len(devices) else f"Device {dev_idx+1}"
        self.status.showMessage(f"{name}: {msg}")

    # ── Audio processing ────────────────────────────────────────────────
    @pyqtSlot(np.ndarray, int)
    def _on_audio_chunk(self, audio_data, device_index):
        if not self.engine:
            return
        try:
            text = self.engine.transcribe(audio_data)
            if text:
                now = time.strftime("%H:%M:%S")
                devices = self.cfg.get("devices", [])
                dev_cfg = devices[device_index] if device_index < len(devices) else {}
                name = dev_cfg.get("name", f"Device {device_index+1}")
                color = dev_cfg.get("color", "#00CCFF")
                self._transcription_queue.put((now, name, text, color))
        except Exception as e:
            print(f"Transkriptionsfehler: {e}", file=sys.stderr)

    @pyqtSlot(str, int)
    def _on_error(self, msg, device_index):
        self._show_error(msg)
        self._on_stop()

    # ── CLEAR ───────────────────────────────────────────────────────────
    def _on_clear(self):
        self.stage.clear_entries()

    # ── SETUP ──────────────────────────────────────────────────────────
    def _on_setup(self):
        was_running = self.is_running
        if was_running:
            self._on_stop()

        dlg = SetupDialog(self.cfg, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.cfg = dlg.get_config()
            save_config(self.cfg)
            self.stage.apply_config(self.cfg)
            self.dim_timer.setInterval(self.cfg.get("update_interval", 500))
            self._update_model_badge()
            self.status.showMessage("Konfiguration gespeichert")

        if was_running:
            self._do_start()

    # ── Error ──────────────────────────────────────────────────────────
    def _show_error(self, msg):
        print(msg, file=sys.stderr)
        QMessageBox.critical(self, "Fehler", msg)

    def closeEvent(self, event):
        self._on_stop()
        event.accept()


# ══════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════

def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")

    # Dark palette
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor(30, 30, 30))
    palette.setColor(QPalette.ColorRole.WindowText, QColor(220, 220, 220))
    palette.setColor(QPalette.ColorRole.Base, QColor(25, 25, 25))
    palette.setColor(QPalette.ColorRole.AlternateBase, QColor(40, 40, 40))
    palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(50, 50, 50))
    palette.setColor(QPalette.ColorRole.ToolTipText, QColor(220, 220, 220))
    palette.setColor(QPalette.ColorRole.Text, QColor(220, 220, 220))
    palette.setColor(QPalette.ColorRole.Button, QColor(50, 50, 50))
    palette.setColor(QPalette.ColorRole.ButtonText, QColor(220, 220, 220))
    palette.setColor(QPalette.ColorRole.BrightText, QColor(255, 50, 50))
    palette.setColor(QPalette.ColorRole.Highlight, QColor(0, 120, 215))
    palette.setColor(QPalette.ColorRole.HighlightedText, QColor(255, 255, 255))
    app.setPalette(palette)

    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()