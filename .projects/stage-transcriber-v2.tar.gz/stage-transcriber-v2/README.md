# Stage Transcriber v2

Live-Transkriptions-App für Windows Desktop mit PyQt6 + sherpa-onnx.

## 🤖 Verfügbare Modelle

| Name | Sprache | Größe | Typ |
|------|---------|-------|-----|
| Whisper Base | 🌍 MULTI (EN, DE, FR, ES, ZH, JA, ...) | 74 MB | Whisper |
| Whisper Small | 🌍 MULTI (EN, DE, FR, ES, ZH, JA, ...) | 244 MB | Whisper |
| Whisper Medium | 🌍 MULTI (EN, DE, FR, ES, ZH, JA, ...) | 769 MB | Whisper |
| Whisper Large V3 | 🌍 MULTI (EN, DE, FR, ES, ZH, JA, ...) | 1550 MB | Whisper |
| Paraformer (int8) | 🇨🇳 ZH (Chinesisch/Mandarin) | 70 MB | Nemo CTC |
| Conformer | 🇬🇧 EN (Englisch) | 100 MB | Nemo CTC |

### Sprach-Kennzeichnung

- **🇩🇪 DE** — Deutsch
- **🇬🇧 EN** — Englisch
- **🇨🇳 ZH** — Chinesisch (Mandarin)
- **🌍 MULTI** — Mehrsprachig (unterstützt Deutsch, Englisch, und viele weitere Sprachen)

### Modell-Empfehlungen

| Anwendung | Empfohlenes Modell | Grund |
|-----------|-------------------|-------|
| Deutsche Predigt/Rede | Whisper Small oder Medium | Gute DE-Erkennung, moderate Größe |
| Chinesisch | Paraformer (int8) | Spezialisiert, klein & schnell |
| Englisch | Conformer oder Whisper Base | Conformer für EN optimiert |
| Mehrsprachig | Whisper Large V3 | Beste Qualität, aber groß |
| Schnell & klein | Paraformer (int8) | Nur 70 MB, int8 quantisiert |

## 🔊 Multi-Device (bis zu 4 Mikrofone)

Jedes Device hat:
- **Eigener Name** (z.B. "Prediger", "Moderator", "Übersetzer", "Gast")
- **Eigene Farbe** (für Anzeige, z.B. Cyan, Orange, Grün, Magenta)
- **Eigenes Input-Gerät** (Mikrofon-Auswahl)

Anzeigeformat: `[HH:MM:SS] Name: Text`

Beispiel:
```
[12:34:56] Prediger: Und wir lesen aus dem Buch Jesaja
[12:34:58] Übersetzer: And we read from the book of Isaiah
[12:35:01] Prediger: Kapitel 53, Verse 1 bis 6
```

## ⚙ Setup-Menü (6 Tabs)

1. **🎙 Audio** — Devices (4x), Gain, VAD-Einstellungen
2. **🤖 Model** — Modellauswahl mit Sprach-Info, Download, Status-Tabelle
3. **🖥 Anzeige** — Schriftgröße, Abstände, Updateintervall
4. **🌑 Dimming** — Fade-Delay, Fade-Zeit, Zielhelligkeit
5. **🚨 Alarm** — Alarmwörter, Blink-Einstellungen
6. **⚙ Erweitert** — Provider (Auto/CUDA/CPU), Threads

## 📦 Installation

### Voraussetzungen

```bash
pip install PyQt6 sherpa-onnx sounddevice numpy requests
```

### Start

```bash
python stage_transcriber.py
```

Beim ersten Start werden die Modelle automatisch heruntergeladen (oder manuell im Setup-Dialog).

## 🔨 Als EXE bauen

```batch
build_exe.bat
```

Benötigt: `pip install pyinstaller`

## ⌨ Tastenkürzel

- **START** — Aufnahme beginnen (Modelle werden ggf. heruntergeladen)
- **STOP** — Aufnahme stoppen
- **Clear** — Transkriptionen löschen
- **Setup** — Konfiguration ändern

## 📁 Dateien

```
stage-transcriber-v2/
├── stage_transcriber.py   # Hauptanwendung
├── requirements.txt       # Python-Abhängigkeiten
├── build_exe.bat          # PyInstaller-Build
├── README.md              # Diese Datei
└── models/                # Automatisch erstellt, heruntergeladene Modelle
    ├── whisper-base/
    ├── whisper-small/
    ├── whisper-medium/
    ├── whisper-large-v3/
    ├── paraformer-zh-int8/
    ├── conformer-en/
    └── silero-vad/
```

## 🔄 Änderungen v1 → v2

- ✅ **Mehrere Modelle** mit Sprach-Info (DE, EN, ZH, MULTI)
- ✅ **6 Tabs** statt einer langen Liste (Audio, Model, Anzeige, Dimming, Alarm, Erweitert)
- ✅ **4 Sound-Devices** parallel (jeder mit Name, Farbe, eigenem Mikrofon)
- ✅ **Zeitformat [HH:MM:SS]** in jeder Zeile
- ✅ **Modell-Tabelle** mit Download-Status und Sprach-Badges
- ✅ **Modell-Download** direkt aus dem Setup-Dialog