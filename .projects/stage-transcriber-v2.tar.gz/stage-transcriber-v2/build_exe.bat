@echo off
echo ============================================
echo  Stage Transcriber v2 - Build EXE
echo ============================================
echo.

REM Check pyinstaller
pip show pyinstaller >nul 2>&1
if errorlevel 1 (
    echo Installing PyInstaller...
    pip install pyinstaller
)

echo Cleaning old build...
if exist "dist" rmdir /s /q dist
if exist "build" rmdir /s /q build

echo.
echo Building stage_transcriber.exe ...
pyinstaller --onefile ^
    --name "stage_transcriber" ^
    --noconsole ^
    --add-data "stage_transcriber.py;." ^
    --hidden-import=sherpa_onnx ^
    --hidden-import=sounddevice ^
    --hidden-import=numpy ^
    --hidden-import=requests ^
    --collect-all sherpa_onnx ^
    stage_transcriber.py

echo.
if exist "dist\stage_transcriber.exe" (
    echo ============================================
    echo  BUILD SUCCESSFUL!
    echo  Output: dist\stage_transcriber.exe
    echo ============================================
) else (
    echo ============================================
    echo  BUILD FAILED!
    echo ============================================
)

echo.
pause