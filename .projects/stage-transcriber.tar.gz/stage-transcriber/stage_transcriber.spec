# -*- mode: python ; coding: utf-8 -*-
import sys, os
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

block_cipher = None

datas = []
datas += collect_data_files('sherpa_onnx', include_py_files=False)
datas += collect_data_files('PyQt6', include_py_files=False)
datas += collect_data_files('PyQt6.QtCore', include_py_files=False)
datas += collect_data_files('PyQt6.QtWidgets', include_py_files=False)
datas += collect_data_files('PyQt6.QtGui', include_py_files=False)

binaries = []
hiddenimports = collect_submodules('sherpa_onnx')
hiddenimports += collect_submodules('sounddevice')
hiddenimports += ['numpy', 'requests', 'json', 'threading', 'queue', 'time', 'traceback']

a = Analysis(
    ['stage_transcriber.py'],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='stage_transcriber',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='stage_transcriber',
)