#!/usr/bin/env python3
"""
stage_transcriber.py — Live-Transkriptions-App für Windows Desktop
PyQt6 + sherpa-onnx + Parakeet-TDT + Silero VAD
"""

import sys
import os
import json
import time
import math
import traceback
import threading
import queue
import struct
import hashlib
import requests
import numpy as np

# ── Auto-CD: Ins eigene Verzeichnis wechseln ──────────────────────────────
APP_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(APP_DIR)

# ── Qt ────────────────────────────────────────────────────────────────────
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QScrollArea, QDialog, QFormLayout,
    QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit, QGroupBox,
    QColorDialog, QMessageBox, QSplitter, QFrame, QSizePolicy,
    QStatusBar, QCheckBox, QListWidget, QListWidgetItem,
    QInputDialog, QProgressBar, QScrollArea,
)
from PyQt6.QtCore import (
    Qt, QTimer, QThread, pyqtSignal, pyqtSlot, QSize, QElapsedTimer,
)
from PyQt6.QtGui import (
    QFont, QColor, QPalette, QPainter, QPen, QBrush, QIcon,
    QFontMetrics, QAction,
)

MODELS_DIR = os.path.join(APP_DIR, "models")
CONFIG_PATH = os.path.join(APP_DIR, "stage_transcriber_config.json")

PARAKEET_MODEL_URL = (
    "https://huggingface.co/csukuangfj/sherpa-onnx-nemo-ctc-paraformer-zh/resolve/main/"
    "sherpa-onnx-nemo-ctc-paraformer-zh-int8.tar.bz2"
)
# Correct Parakeet-TDT model
# Sherpa-ONNX funktionierendes Modell (Paraformer, int8 quantisiert)
PARAKEET_TDT_URLS = {
    "model.onnx": "https://huggingface.co/csukuangfj/sherpa-onnx-nemo-ctc-paraformer-zh/resolve/main/sherpa-onnx-nemo-ctc-paraformer-zh-int8.onnx?download=true",
    "tokens.txt": "https://huggingface.co/csukuangfj/sherpa-onnx-nemo-ctc-paraformer-zh/resolve/main/tokens.txt?download=true",
}

SILERO_VAD_URLS = {
    "silero_vad.onnx": "https://huggingface.co/csukuangfj/silero-vad/resolve/main/silero_vad.onnx?download=true",
}


# ══════════════════════════════════════════════════════════════════════════
#  CONFIG
# ══════════════════════════════════════════════════════════════════════════

DEFAULT_CONFIG = {
    "input_device": None,
    "input_gain": 1.0,
    "vad_threshold": 0.5,
    "vad_min_silence": 0.3,
    "vad_min_speech": 0.25,
    "vad_max_speech": 30.0,
    "speaker_name": "Sprecher",
    "font_size": 28,
    "spacing_mm": 3.0,
    "name_color": "#00CCFF",
    "name_brightness": 255,
    "dim_old": True,
    "fade_delay": 5.0,
    "fade_time": 10.0,
    "target_brightness": 60,
    "update_interval": 500,
    "provider": "auto",
    "threads": 4,
    "alarm_words": [],
    "blink_duration": 3000,
    "blink_interval": 300,
    "alarm_red": 200,
}


def load_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                cfg.update(json.load(f))
        except Exception:
            pass
    return cfg


def save_config(cfg):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"Config save error: {e}")


# ══════════════════════════════════════════════════════════════════════════
#  MODEL DOWNLOADER
# ══════════════════════════════════════════════════════════════════════════

class ModelDownloader:
    """Download model files with progress callback."""

    def __init__(self, progress_cb=None):
        self.progress_cb = progress_cb

    def _download(self, url, dest):
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        if os.path.exists(dest):
            return True
        self._report(f"Downloading {os.path.basename(dest)}...")
        try:
            r = requests.get(url, stream=True, timeout=120)
            r.raise_for_status()
            total = int(r.headers.get("content-length", 0))
            done = 0
            with open(dest + ".tmp", "wb") as f:
                for chunk in r.iter_content(8192):
                    f.write(chunk)
                    done += len(chunk)
                    if total and self.progress_cb:
                        pct = int(done / total * 100)
                        self._report(f"Downloading {os.path.basename(dest)}: {pct}%")
            os.rename(dest + ".tmp", dest)
            return True
        except Exception as e:
            if os.path.exists(dest + ".tmp"):
                os.remove(dest + ".tmp")
            raise RuntimeError(f"Download failed for {url}: {e}")

    def _report(self, msg):
        if self.progress_cb:
            self.progress_cb(msg)

    def ensure_models(self):
        """Download all required model files. Returns (parakeet_dir, silero_path)."""
        parakeet_dir = os.path.join(MODELS_DIR, "parakeet-tdt")
        silero_dir = os.path.join(MODELS_DIR, "silero-vad")
        os.makedirs(parakeet_dir, exist_ok=True)
        os.makedirs(silero_dir, exist_ok=True)

        # Download Parakeet-TDT
        for fname, url in PARAKEET_TDT_URLS.items():
            dest = os.path.join(parakeet_dir, fname)
            self._download(url, dest)

        # Rename model.onnx to model.int8.onnx for compatibility
        model_src = os.path.join(parakeet_dir, "model.onnx")
        model_dst = os.path.join(parakeet_dir, "model.int8.onnx")
        if os.path.exists(model_src) and not os.path.exists(model_dst):
            os.rename(model_src, model_dst)

        # Download Silero VAD
        for fname, url in SILERO_VAD_URLS.items():
            dest = os.path.join(silero_dir, fname)
            self._download(url, dest)

        return parakeet_dir, os.path.join(silero_dir, "silero_vad.onnx")


# ══════════════════════════════════════════════════════════════════════════
#  SHERPA-ONNX ENGINE
# ══════════════════════════════════════════════════════════════════════════

class TranscriptionEngine:
    """Wraps sherpa-onnx offline recognizer + Silero VAD."""

    def __init__(self, parakeet_dir, silero_path, provider="auto", threads=4):
        import sherpa_onnx

        self.sherpa = sherpa_onnx
        self.provider = provider
        self.threads = threads
        self._create_recognizer(parakeet_dir)

        # VAD
        self.vad = sherpa_onnx.VoiceActivityDetector(
            sherpa_onnx.VadModelConfig(
                model=silero_path,
                threshold=0.5,
                min_silence_duration=0.3,
                min_speech_duration=0.25,
                max_speech_duration=30.0,
                buffer_size_in_seconds=60,
            ),
            buffer_size_in_seconds=60,
        )

    def _create_recognizer(self, parakeet_dir):
        provider = self.provider
        if provider == "auto":
            try:
                # Test CUDA
                test_cfg = self.sherpa.OfflineRecognizerConfig(
                    model_config=self.sherpa.OfflineModelConfig(
                        nemo_enc_dec_tdt_model=os.path.join(parakeet_dir, "model.int8.onnx"),
                        tokens=os.path.join(parakeet_dir, "tokens.txt"),
                        num_threads=self.threads,
                        provider="cuda",
                    ),
                )
                test_rec = self.sherpa.OfflineRecognizer(test_cfg)
                _ = test_rec
                provider = "cuda"
            except Exception:
                provider = "cpu"

        try:
            cfg = self.sherpa.OfflineRecognizerConfig(
                model_config=self.sherpa.OfflineModelConfig(
                    nemo_enc_dec_tdt_model=os.path.join(parakeet_dir, "model.int8.onnx"),
                    tokens=os.path.join(parakeet_dir, "tokens.txt"),
                    num_threads=self.threads,
                    provider=provider,
                ),
            )
            self.recognizer = self.sherpa.OfflineRecognizer(cfg)
            self.actual_provider = provider
        except Exception as e:
            if provider == "cuda":
                # Fallback to CPU
                cfg = self.sherpa.OfflineRecognizerConfig(
                    model_config=self.sherpa.OfflineModelConfig(
                        nemo_enc_dec_tdt_model=os.path.join(parakeet_dir, "model.int8.onnx"),
                        tokens=os.path.join(parakeet_dir, "tokens.txt"),
                        num_threads=self.threads,
                        provider="cpu",
                    ),
                )
                self.recognizer = self.sherpa.OfflineRecognizer(cfg)
                self.actual_provider = "cpu (fallback)"
            else:
                raise

    def transcribe(self, audio_float32):
        """Transcribe a float32 16kHz mono numpy array."""
        stream = self.recognizer.create_stream()
        stream.accept_waveform(16000, audio_float32.tolist())
        self.recognizer.decode_stream(stream)
        return stream.result.text.strip()

    def vad_reset(self):
        self.vad.flush()

    def vad_accept(self, audio_float32):
        """Feed audio to VAD. Returns list of speech segments (float32 arrays)."""
        self.vad.accept_waveform(audio_float32.tolist())
        segments = []
        while not self.vad.empty:
            seg = self.vad.front
            segments.append(np.array(seg.samples, dtype=np.float32))
            self.vad.pop()
        return segments


# ══════════════════════════════════════════════════════════════════════════
#  AUDIO CAPTURE THREAD
# ══════════════════════════════════════════════════════════════════════════

class AudioThread(QThread):
    audio_chunk = pyqtSignal(np.ndarray)
    error_signal = pyqtSignal(str)
    status_signal = pyqtSignal(str)

    def __init__(self, device_name, gain, vad_config, engine):
        super().__init__()
        self.device_name = device_name
        self.gain = gain
        self.vad_config = vad_config
        self.engine = engine
        self.running = False
        self.stream = None

    def run(self):
        import sounddevice as sd
        self.running = True
        self.status_signal.emit("Audio: Starting...")

        # Update VAD params
        self.engine.vad.config.threshold = self.vad_config.get("threshold", 0.5)
        self.engine.vad.config.min_silence_duration = self.vad_config.get("min_silence", 0.3)
        self.engine.vad.config.min_speech_duration = self.vad_config.get("min_speech", 0.25)
        self.engine.vad.config.max_speech_duration = self.vad_config.get("max_speech", 30.0)

        self.engine.vad_reset()

        device_index = None
        if self.device_name:
            devs = sd.query_devices()
            for i, d in enumerate(devs):
                if self.device_name in d["name"] and d["max_input_channels"] > 0:
                    device_index = i
                    break

        try:
            with sd.InputStream(
                samplerate=16000,
                channels=1,
                dtype="float32",
                blocksize=1600,
                device=device_index,
            ) as self.stream:
                self.status_signal.emit(
                    f"Audio: Recording ({self.engine.actual_provider})"
                )
                while self.running:
                    data, overflowed = self.stream.read(1600)
                    if not self.running:
                        break
                    chunk = data.flatten() * self.gain
                    segments = self.engine.vad_accept(chunk)
                    for seg in segments:
                        self.audio_chunk.emit(seg)

        except Exception as e:
            self.error_signal.emit(f"Audio error: {e}\n{traceback.format_exc()}")
        finally:
            self.status_signal.emit("Audio: Stopped")

    def stop(self):
        self.running = False
        self.wait(5000)


# ══════════════════════════════════════════════════════════════════════════
#  TRANSCRIPTION ENTRY WIDGET
# ══════════════════════════════════════════════════════════════════════════

class TranscriptionLabel(QWidget):
    """A single transcription line: timestamp + name + text."""

    def __init__(self, timestamp, name, text, parent=None):
        super().__init__(parent)
        self.timestamp = timestamp
        self.name = name
        self.text = text
        self.creation_time = time.time()
        self._brightness = 255
        self._time_color = QColor(180, 180, 180, 255)
        self._name_color = QColor(0, 204, 255, 255)
        self._text_color = QColor(230, 230, 230, 255)
        self._font_size = 28
        self._highlighted = False
        self._alarm_words = []
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, False)
        self.setAutoFillBackground(True)
        pal = self.palette()
        pal.setColor(QPalette.ColorRole.Window, QColor(30, 30, 30))
        self.setPalette(pal)

    def set_colors(self, name_color, name_brightness, base_text_color=QColor(230, 230, 230)):
        nc = QColor(name_color)
        nc.setAlpha(min(name_brightness, 255))
        self._name_color = nc
        self._text_color = base_text_color
        self.update()

    def set_brightness(self, b):
        b = max(0, min(255, int(b)))
        self._brightness = b
        # Dim timestamp
        self._time_color = QColor(180, 180, 180, b)
        # Dim name
        nc = QColor(self._name_color)
        nc.setAlpha(b)
        self._name_color = nc
        # Dim text
        self._text_color = QColor(
            (230 * b) // 255,
            (230 * b) // 255,
            (230 * b) // 255,
            255,
        )
        self.update()

    def set_font_size(self, size):
        self._font_size = size
        self.updateGeometry()
        self.update()

    def set_alarm_words(self, words):
        self._alarm_words = [w.lower() for w in words]
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        bg = QColor(30, 30, 30)
        painter.fillRect(self.rect(), bg)

        font = QFont("Segoe UI", self._font_size)
        font.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
        painter.setFont(font)
        fm = QFontMetrics(font)
        line_height = fm.height()
        y = fm.ascent() + 4

        # Timestamp
        ts_str = f"[{self.timestamp}] "
        painter.setPen(QPen(self._time_color))
        ts_width = fm.horizontalAdvance(ts_str)
        painter.drawText(4, y, ts_str)

        # Name
        name_str = f"{self.name}: "
        painter.setPen(QPen(self._name_color))
        name_width = fm.horizontalAdvance(name_str)
        painter.drawText(4 + ts_width, y, name_str)

        # Text
        text_x = 4 + ts_width + name_width
        text_str = self.text
        # Check alarm words for highlighting
        if self._alarm_words:
            words = text_str.split(" ")
            cx = text_x
            for word in words:
                is_alarm = word.lower().strip(".,;:!?") in self._alarm_words
                if is_alarm:
                    painter.setPen(QPen(QColor(255, 60, 60, self._brightness)))
                    painter.setFont(QFont("Segoe UI", self._font_size, QFont.Weight.Bold))
                    fm2 = QFontMetrics(painter.font())
                else:
                    painter.setPen(QPen(self._text_color))
                    painter.setFont(font)
                    fm2 = fm
                word_draw = word + " "
                painter.drawText(int(cx), y, word_draw)
                cx += fm2.horizontalAdvance(word_draw)
        else:
            painter.setPen(QPen(self._text_color))
            painter.drawText(text_x, y, text_str)

        painter.end()

    def sizeHint(self):
        font = QFont("Segoe UI", self._font_size)
        fm = QFontMetrics(font)
        text = f"[{self.timestamp}] {self.name}: {self.text}"
        w = fm.horizontalAdvance(text) + 12
        h = fm.height() + 8
        return QSize(w, h)

    def minimumSizeHint(self):
        return QSize(50, 20)


# ══════════════════════════════════════════════════════════════════════════
#  STAGE DISPLAY (transcription area)
# ══════════════════════════════════════════════════════════════════════════

class StageDisplay(QScrollArea):
    """Scrollable transcription display with dimming."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.setStyleSheet("QScrollArea { background: #1E1E1E; border: none; }")

        self.container = QWidget()
        self.container.setStyleSheet("background: #1E1E1E;")
        self.layout = QVBoxLayout(self.container)
        self.layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.layout.setSpacing(6)
        self.layout.setContentsMargins(4, 4, 4, 4)
        self.setWidget(self.container)

        self.entries = []  # List of TranscriptionLabel
        self._alarm_active = False
        self._alarm_until = 0
        self._alarm_red = 200

        # Config
        self.fade_delay = 5.0
        self.fade_time = 10.0
        self.target_brightness = 60
        self.name_color = QColor(0, 204, 255)
        self.name_brightness = 255
        self.font_size = 28
        self.spacing_px = self._mm_to_px(3.0)
        self.dim_old = True
        self.alarm_words = []

    def _mm_to_px(self, mm):
        screen = QApplication.primaryScreen()
        if screen:
            dpi = screen.logicalDotsPerInchY()
            return int(mm / 25.4 * dpi)
        return int(mm * 3.78)  # ~96dpi fallback

    def set_spacing_mm(self, mm):
        self.spacing_px = self._mm_to_px(mm)
        self.layout.setSpacing(self.spacing_px)
        for w in self.entries:
            w.updateGeometry()

    def add_entry(self, timestamp, name, text):
        label = TranscriptionLabel(timestamp, name, text)
        label.set_colors(self.name_color.name(), self.name_brightness)
        label.set_font_size(self.font_size)
        label.set_alarm_words(self.alarm_words)
        label.set_brightness(255)
        self.entries.append(label)
        self.layout.addWidget(label)
        # Scroll to bottom
        QTimer.singleShot(50, self._scroll_to_bottom)

        # Check alarm
        text_lower = text.lower()
        for aw in self.alarm_words:
            if aw.lower() in text_lower:
                self._trigger_alarm()
                break

        return label

    def _scroll_to_bottom(self):
        sb = self.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _trigger_alarm(self):
        self._alarm_active = True
        self._alarm_until = time.time() * 1000 + 3000  # default duration

    def clear_entries(self):
        for w in self.entries:
            self.layout.removeWidget(w)
            w.deleteLater()
        self.entries.clear()
        self._alarm_active = False

    def update_dimming(self):
        if not self.dim_old:
            return
        now = time.time()
        for entry in self.entries:
            elapsed = now - entry.creation_time
            if elapsed < self.fade_delay:
                b = 255
            elif self.fade_time <= 0:
                b = self.target_brightness
            else:
                progress = min(1.0, (elapsed - self.fade_delay) / self.fade_time)
                b = 255 - (255 - self.target_brightness) * progress
            entry.set_brightness(b)

    def update_alarm_blink(self):
        now = time.time() * 1000
        if not self._alarm_active:
            return False
        if now > self._alarm_until:
            self._alarm_active = False
            self.container.setStyleSheet("background: #1E1E1E;")
            return False
        # Blink
        interval = 300
        phase = int(now / interval) % 2
        if phase:
            red = self._alarm_red
            self.container.setStyleSheet(f"background: rgb({red}, 0, 0);")
        else:
            self.container.setStyleSheet("background: #1E1E1E;")
        return True  # still active

    def apply_config(self, cfg):
        self.name_color = QColor(cfg.get("name_color", "#00CCFF"))
        self.name_brightness = cfg.get("name_brightness", 255)
        self.font_size = cfg.get("font_size", 28)
        self.spacing_px = self._mm_to_px(cfg.get("spacing_mm", 3.0))
        self.layout.setSpacing(self.spacing_px)
        self.fade_delay = cfg.get("fade_delay", 5.0)
        self.fade_time = cfg.get("fade_time", 10.0)
        self.target_brightness = cfg.get("target_brightness", 60)
        self.dim_old = cfg.get("dim_old", True)
        self.alarm_words = cfg.get("alarm_words", [])
        self._alarm_red = cfg.get("alarm_red", 200)
        self._alarm_until = now = time.time() * 1000 + cfg.get("blink_duration", 3000)
        # Update existing entries
        for entry in self.entries:
            entry.set_colors(self.name_color.name(), self.name_brightness)
            entry.set_font_size(self.font_size)
            entry.set_alarm_words(self.alarm_words)


# ══════════════════════════════════════════════════════════════════════════
#  SETUP DIALOG
# ══════════════════════════════════════════════════════════════════════════

class SetupDialog(QDialog):
    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.cfg = dict(cfg)
        self.setWindowTitle("Setup")
        self.setMinimumSize(520, 600)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        # ── Audio ─────────────────────────────────────
        audio_group = QGroupBox("Audio")
        audio_layout = QFormLayout(audio_group)

        import sounddevice as sd
        devices = sd.query_devices()
        input_devices = [d["name"] for d in devices if d["max_input_channels"] > 0]

        self.device_combo = QComboBox()
        self.device_combo.addItems(input_devices)
        current_dev = self.cfg.get("input_device")
        if current_dev:
            idx = self.device_combo.findText(current_dev, Qt.MatchFlag.MatchContains)
            if idx >= 0:
                self.device_combo.setCurrentIndex(idx)
        audio_layout.addRow("Input Device:", self.device_combo)

        self.gain_spin = QDoubleSpinBox()
        self.gain_spin.setRange(0.1, 10.0)
        self.gain_spin.setSingleStep(0.1)
        self.gain_spin.setValue(self.cfg.get("input_gain", 1.0))
        audio_layout.addRow("Input Gain:", self.gain_spin)

        self.vad_thresh = QDoubleSpinBox()
        self.vad_thresh.setRange(0.0, 1.0)
        self.vad_thresh.setSingleStep(0.05)
        self.vad_thresh.setDecimals(2)
        self.vad_thresh.setValue(self.cfg.get("vad_threshold", 0.5))
        audio_layout.addRow("VAD Threshold:", self.vad_thresh)

        self.vad_min_silence = QDoubleSpinBox()
        self.vad_min_silence.setRange(0.05, 5.0)
        self.vad_min_silence.setSingleStep(0.05)
        self.vad_min_silence.setDecimals(2)
        self.vad_min_silence.setValue(self.cfg.get("vad_min_silence", 0.3))
        audio_layout.addRow("Min Silence (s):", self.vad_min_silence)

        self.vad_min_speech = QDoubleSpinBox()
        self.vad_min_speech.setRange(0.05, 5.0)
        self.vad_min_speech.setSingleStep(0.05)
        self.vad_min_speech.setDecimals(2)
        self.vad_min_speech.setValue(self.cfg.get("vad_min_speech", 0.25))
        audio_layout.addRow("Min Speech (s):", self.vad_min_speech)

        self.vad_max_speech = QDoubleSpinBox()
        self.vad_max_speech.setRange(1.0, 60.0)
        self.vad_max_speech.setSingleStep(1.0)
        self.vad_max_speech.setDecimals(1)
        self.vad_max_speech.setValue(self.cfg.get("vad_max_speech", 30.0))
        audio_layout.addRow("Max Speech (s):", self.vad_max_speech)

        layout.addWidget(audio_group)

        # ── Display ───────────────────────────────────
        disp_group = QGroupBox("Anzeige")
        disp_layout = QFormLayout(disp_group)

        self.name_edit = QLineEdit(self.cfg.get("speaker_name", "Sprecher"))
        disp_layout.addRow("Name:", self.name_edit)

        self.font_size_spin = QSpinBox()
        self.font_size_spin.setRange(8, 120)
        self.font_size_spin.setValue(self.cfg.get("font_size", 28))
        disp_layout.addRow("Font Size:", self.font_size_spin)

        self.spacing_spin = QDoubleSpinBox()
        self.spacing_spin.setRange(0.0, 50.0)
        self.spacing_spin.setSingleStep(0.5)
        self.spacing_spin.setValue(self.cfg.get("spacing_mm", 3.0))
        disp_layout.addRow("Abstand (mm):", self.spacing_spin)

        self.name_color_btn = QPushButton()
        self._name_color = QColor(self.cfg.get("name_color", "#00CCFF"))
        self.name_color_btn.setStyleSheet(
            f"background-color: {self._name_color.name()};"
        )
        self.name_color_btn.clicked.connect(self._pick_name_color)
        disp_layout.addRow("Name-Farbe:", self.name_color_btn)

        self.name_brightness_spin = QSpinBox()
        self.name_brightness_spin.setRange(0, 255)
        self.name_brightness_spin.setValue(self.cfg.get("name_brightness", 255))
        disp_layout.addRow("Name-Helligkeit:", self.name_brightness_spin)

        self.dim_check = QCheckBox("Ältere Zeilen dimmen")
        self.dim_check.setChecked(self.cfg.get("dim_old", True))
        disp_layout.addRow(self.dim_check)

        self.fade_delay_spin = QDoubleSpinBox()
        self.fade_delay_spin.setRange(0.0, 60.0)
        self.fade_delay_spin.setSingleStep(0.5)
        self.fade_delay_spin.setValue(self.cfg.get("fade_delay", 5.0))
        disp_layout.addRow("Fade-Delay (s):", self.fade_delay_spin)

        self.fade_time_spin = QDoubleSpinBox()
        self.fade_time_spin.setRange(1.0, 999.0)
        self.fade_time_spin.setSingleStep(1.0)
        self.fade_time_spin.setValue(self.cfg.get("fade_time", 10.0))
        disp_layout.addRow("Fade-Zeit (s):", self.fade_time_spin)

        self.target_bright_spin = QSpinBox()
        self.target_bright_spin.setRange(0, 255)
        self.target_bright_spin.setValue(self.cfg.get("target_brightness", 60))
        disp_layout.addRow("Zielhelligkeit:", self.target_bright_spin)

        self.update_combo = QComboBox()
        self.update_combo.addItems(["250", "500", "1000"])
        interval = self.cfg.get("update_interval", 500)
        idx = self.update_combo.findText(str(interval))
        if idx >= 0:
            self.update_combo.setCurrentIndex(idx)
        disp_layout.addRow("Updateintervall (ms):", self.update_combo)

        layout.addWidget(disp_group)

        # ── Recognition ───────────────────────────────
        rec_group = QGroupBox("Erkennung")
        rec_layout = QFormLayout(rec_group)

        self.provider_combo = QComboBox()
        self.provider_combo.addItems(["auto", "cuda", "cpu"])
        prov = self.cfg.get("provider", "auto")
        idx = self.provider_combo.findText(prov)
        if idx >= 0:
            self.provider_combo.setCurrentIndex(idx)
        rec_layout.addRow("Provider:", self.provider_combo)

        self.threads_spin = QSpinBox()
        self.threads_spin.setRange(1, 32)
        self.threads_spin.setValue(self.cfg.get("threads", 4))
        rec_layout.addRow("Threads:", self.threads_spin)

        layout.addWidget(rec_group)

        # ── Alarm ──────────────────────────────────────
        alarm_group = QGroupBox("Alarm")
        alarm_layout = QFormLayout(alarm_group)

        self.alarm_list = QListWidget()
        for w in self.cfg.get("alarm_words", []):
            self.alarm_list.addItem(w)
        alarm_layout.addRow("Alarmwörter:", self.alarm_list)

        btn_row = QHBoxLayout()
        add_btn = QPushButton("Hinzufügen")
        add_btn.clicked.connect(self._add_alarm_word)
        rem_btn = QPushButton("Entfernen")
        rem_btn.clicked.connect(self._rem_alarm_word)
        btn_row.addWidget(add_btn)
        btn_row.addWidget(rem_btn)
        alarm_layout.addRow(btn_row)

        self.blink_duration = QSpinBox()
        self.blink_duration.setRange(500, 30000)
        self.blink_duration.setSingleStep(100)
        self.blink_duration.setValue(self.cfg.get("blink_duration", 3000))
        self.blink_duration.setSuffix(" ms")
        alarm_layout.addRow("Blink-Dauer:", self.blink_duration)

        self.blink_interval = QSpinBox()
        self.blink_interval.setRange(50, 2000)
        self.blink_interval.setSingleStep(50)
        self.blink_interval.setValue(self.cfg.get("blink_interval", 300))
        self.blink_interval.setSuffix(" ms")
        alarm_layout.addRow("Blink-Intervall:", self.blink_interval)

        self.alarm_red_spin = QSpinBox()
        self.alarm_red_spin.setRange(0, 255)
        self.alarm_red_spin.setValue(self.cfg.get("alarm_red", 200))
        alarm_layout.addRow("Rot-Intensität:", self.alarm_red_spin)

        layout.addWidget(alarm_group)

        # ── Buttons ───────────────────────────────────
        btn_layout = QHBoxLayout()
        ok_btn = QPushButton("OK")
        ok_btn.clicked.connect(self._accept)
        cancel_btn = QPushButton("Abbrechen")
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(ok_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)

    def _pick_name_color(self):
        c = QColorDialog.getColor(self._name_color, self, "Name-Farbe wählen")
        if c.isValid():
            self._name_color = c
            self.name_color_btn.setStyleSheet(
                f"background-color: {c.name()};"
            )

    def _add_alarm_word(self):
        word, ok = QInputDialog.getText(self, "Alarmwort", "Wort:")
        if ok and word.strip():
            self.alarm_list.addItem(word.strip())

    def _rem_alarm_word(self):
        items = self.alarm_list.selectedItems()
        for item in items:
            self.alarm_list.takeItem(self.alarm_list.row(item))

    def _accept(self):
        self.cfg["input_device"] = self.device_combo.currentText() or None
        self.cfg["input_gain"] = self.gain_spin.value()
        self.cfg["vad_threshold"] = self.vad_thresh.value()
        self.cfg["vad_min_silence"] = self.vad_min_silence.value()
        self.cfg["vad_min_speech"] = self.vad_min_speech.value()
        self.cfg["vad_max_speech"] = self.vad_max_speech.value()
        self.cfg["speaker_name"] = self.name_edit.text()
        self.cfg["font_size"] = self.font_size_spin.value()
        self.cfg["spacing_mm"] = self.spacing_spin.value()
        self.cfg["name_color"] = self._name_color.name()
        self.cfg["name_brightness"] = self.name_brightness_spin.value()
        self.cfg["dim_old"] = self.dim_check.isChecked()
        self.cfg["fade_delay"] = self.fade_delay_spin.value()
        self.cfg["fade_time"] = self.fade_time_spin.value()
        self.cfg["target_brightness"] = self.target_bright_spin.value()
        self.cfg["update_interval"] = int(self.update_combo.currentText())
        self.cfg["provider"] = self.provider_combo.currentText()
        self.cfg["threads"] = self.threads_spin.value()
        self.cfg["alarm_words"] = [
            self.alarm_list.item(i).text()
            for i in range(self.alarm_list.count())
        ]
        self.cfg["blink_duration"] = self.blink_duration.value()
        self.cfg["blink_interval"] = self.blink_interval.value()
        self.cfg["alarm_red"] = self.alarm_red_spin.value()
        self.accept()

    def get_config(self):
        return self.cfg


# ══════════════════════════════════════════════════════════════════════════
#  MAIN WINDOW
# ══════════════════════════════════════════════════════════════════════════

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.cfg = load_config()
        self.engine = None
        self.audio_thread = None
        self.is_running = False
        self._needs_restart = False
        self._transcription_queue = queue.Queue()
        self._init_ui()
        self._init_timers()

    def _init_ui(self):
        self.setWindowTitle("Stage Transcriber")
        self.setMinimumSize(800, 400)
        self.setStyleSheet("QMainWindow { background: #1E1E1E; }")

        # ── Central widget ───────────────────────────
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # ── Button bar ──────────────────────────────
        btn_bar = QWidget()
        btn_bar.setStyleSheet("background: #2D2D2D;")
        btn_bar.setFixedHeight(48)
        btn_layout = QHBoxLayout(btn_bar)
        btn_layout.setContentsMargins(8, 4, 8, 4)

        self.start_btn = QPushButton("▶ START")
        self.start_btn.setStyleSheet(
            "QPushButton { background: #2E7D32; color: white; font-weight: bold; "
            "font-size: 14px; padding: 6px 20px; border-radius: 4px; }"
            "QPushButton:hover { background: #388E3C; }"
            "QPushButton:disabled { background: #555; color: #999; }"
        )
        self.start_btn.clicked.connect(self._on_start)

        self.stop_btn = QPushButton("■ STOP")
        self.stop_btn.setStyleSheet(
            "QPushButton { background: #C62828; color: white; font-weight: bold; "
            "font-size: 14px; padding: 6px 20px; border-radius: 4px; }"
            "QPushButton:hover { background: #D32F2F; }"
            "QPushButton:disabled { background: #555; color: #999; }"
        )
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self._on_stop)

        btn_layout.addWidget(self.start_btn)
        btn_layout.addWidget(self.stop_btn)
        btn_layout.addStretch()

        self.clear_btn = QPushButton("🗑 Clear")
        self.clear_btn.setStyleSheet(
            "QPushButton { background: #424242; color: white; font-size: 13px; "
            "padding: 6px 14px; border-radius: 4px; }"
            "QPushButton:hover { background: #616161; }"
        )
        self.clear_btn.clicked.connect(self._on_clear)

        self.setup_btn = QPushButton("⚙ Setup")
        self.setup_btn.setStyleSheet(
            "QPushButton { background: #424242; color: white; font-size: 13px; "
            "padding: 6px 14px; border-radius: 4px; }"
            "QPushButton:hover { background: #616161; }"
        )
        self.setup_btn.clicked.connect(self._on_setup)

        btn_layout.addWidget(self.clear_btn)
        btn_layout.addWidget(self.setup_btn)

        main_layout.addWidget(btn_bar)

        # ── Stage display ────────────────────────────
        self.stage = StageDisplay()
        self.stage.apply_config(self.cfg)
        main_layout.addWidget(self.stage, 1)

        # ── Status bar ──────────────────────────────
        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.status.setStyleSheet("QStatusBar { background: #2D2D2D; color: #AAA; }")
        self.status.showMessage("Bereit — Drücke START")

    def _init_timers(self):
        # Dimming timer
        interval = self.cfg.get("update_interval", 500)
        self.dim_timer = QTimer(self)
        self.dim_timer.timeout.connect(self._update_dimming)
        self.dim_timer.start(interval)

        # Blink timer
        self.blink_timer = QTimer(self)
        self.blink_timer.timeout.connect(self._update_alarm)
        self.blink_timer.start(100)

        # Transcription queue drain
        self.queue_timer = QTimer(self)
        self.queue_timer.timeout.connect(self._drain_queue)
        self.queue_timer.start(50)

    def _drain_queue(self):
        while not self._transcription_queue.empty():
            try:
                ts, name, text = self._transcription_queue.get_nowait()
                self.stage.add_entry(ts, name, text)
            except queue.Empty:
                break

    def _update_dimming(self):
        self.stage.update_dimming()

    def _update_alarm(self):
        self.stage.update_alarm_blink()

    # ── START / STOP ────────────────────────────────
    def _on_start(self):
        if self.is_running:
            return
        self._do_start()

    def _do_start(self):
        try:
            # Download models if needed
            self.status.showMessage("Prüfe Modelle...")
            QApplication.processEvents()

            dl = ModelDownloader(progress_cb=lambda msg: (
                self.status.showMessage(msg),
                QApplication.processEvents(),
            ))

            parakeet_dir, silero_path = dl.ensure_models()
            self.status.showMessage("Initialisiere Engine...")
            QApplication.processEvents()

            self.engine = TranscriptionEngine(
                parakeet_dir, silero_path,
                provider=self.cfg.get("provider", "auto"),
                threads=self.cfg.get("threads", 4),
            )

            self.status.showMessage(f"Engine: {self.engine.actual_provider} — Starte Audio...")
            QApplication.processEvents()

            vad_config = {
                "threshold": self.cfg.get("vad_threshold", 0.5),
                "min_silence": self.cfg.get("vad_min_silence", 0.3),
                "min_speech": self.cfg.get("vad_min_speech", 0.25),
                "max_speech": self.cfg.get("vad_max_speech", 30.0),
            }

            self.audio_thread = AudioThread(
                device_name=self.cfg.get("input_device"),
                gain=self.cfg.get("input_gain", 1.0),
                vad_config=vad_config,
                engine=self.engine,
            )
            self.audio_thread.audio_chunk.connect(self._on_audio_chunk)
            self.audio_thread.error_signal.connect(self._on_error)
            self.audio_thread.status_signal.connect(
                lambda msg: self.status.showMessage(msg)
            )
            self.audio_thread.start()

            self.is_running = True
            self.start_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)
            self.status.showMessage(
                f"Aufnahme aktiv — {self.engine.actual_provider}"
            )
        except Exception as e:
            tb = traceback.format_exc()
            self._show_error(f"Fehler beim Starten:\n{e}\n\n{tb}")

    def _on_stop(self):
        if not self.is_running:
            return
        self.is_running = False
        if self.audio_thread:
            self.audio_thread.stop()
            self.audio_thread = None
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.status.showMessage("Gestoppt")

    # ── Audio processing ────────────────────────────
    @pyqtSlot(np.ndarray)
    def _on_audio_chunk(self, audio_data):
        if not self.engine:
            return
        try:
            text = self.engine.transcribe(audio_data)
            if text:
                now = time.strftime("%H:%M:%S")
                name = self.cfg.get("speaker_name", "Sprecher")
                self._transcription_queue.put((now, name, text))
        except Exception as e:
            self._show_error(f"Transkriptionsfehler: {e}")

    @pyqtSlot(str)
    def _on_error(self, msg):
        self._show_error(msg)
        self._on_stop()

    # ── CLEAR ───────────────────────────────────────
    def _on_clear(self):
        self.stage.clear_entries()

    # ── SETUP ──────────────────────────────────────
    def _on_setup(self):
        was_running = self.is_running
        if was_running:
            self._on_stop()

        dlg = SetupDialog(self.cfg, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.cfg = dlg.get_config()
            save_config(self.cfg)
            self.stage.apply_config(self.cfg)
            # Update dim timer interval
            interval = self.cfg.get("update_interval", 500)
            self.dim_timer.setInterval(interval)
            self.status.showMessage("Konfiguration gespeichert")

        if was_running:
            self._do_start()

    # ── Error popup ─────────────────────────────────
    def _show_error(self, msg):
        # Log traceback
        print(msg, file=sys.stderr)
        QMessageBox.critical(self, "Fehler", msg)

    # ── Auto-restart on config change ───────────────
    def restart_if_needed(self):
        if self.is_running:
            self._on_stop()
            self._do_start()

    def closeEvent(self, event):
        self._on_stop()
        event.accept()


# ══════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════

def main():
    # Auto-CD already done at module level
    app = QApplication(sys.argv)
    app.setStyle("Fusion")

    # Dark palette
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor(30, 30, 30))
    palette.setColor(QPalette.ColorRole.WindowText, QColor(220, 220, 220))
    palette.setColor(QPalette.ColorRole.Base, QColor(25, 25, 25))
    palette.setColor(QPalette.ColorRole.AlternateBase, QColor(40, 40, 40))
    palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(50, 50, 50))
    palette.setColor(QPalette.ColorRole.ToolTipText, QColor(220, 220, 220))
    palette.setColor(QPalette.ColorRole.Text, QColor(220, 220, 220))
    palette.setColor(QPalette.ColorRole.Button, QColor(50, 50, 50))
    palette.setColor(QPalette.ColorRole.ButtonText, QColor(220, 220, 220))
    palette.setColor(QPalette.ColorRole.BrightText, QColor(255, 50, 50))
    palette.setColor(QPalette.ColorRole.Highlight, QColor(0, 120, 215))
    palette.setColor(QPalette.ColorRole.HighlightedText, QColor(255, 255, 255))
    app.setPalette(palette)

    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()