@echo off
REM Build stage_transcriber.exe with PyInstaller
cd /d "%~dp0"
python -m PyInstaller stage_transcriber.spec --clean --noconfirm
if %ERRORLEVEL% neq 0 (
    echo BUILD FAILED
    pause
    exit /b 1
)
echo.
echo BUILD SUCCESSFUL
echo Output: dist\stage_transcriber\stage_transcriber.exe
pause