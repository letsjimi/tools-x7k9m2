@echo off
chcp 65001 > nul
echo ==========================================
echo  DeFeedbackV1.1 - Windows Build Script
echo ==========================================
echo.

REM Pruefe ob JUCE vorhanden ist
if not exist "JUCE\CMakeLists.txt" (
    echo JUCE nicht gefunden. Lade JUCE...
    git clone https://github.com/juce-framework/JUCE.git JUCE
    if errorlevel 1 (
        echo FEHLER: Konnte JUCE nicht klonen!
        pause
        exit /b 1
    )
)

REM Erstelle Build-Verzeichnis
echo Erstelle Build-Verzeichnis...
if not exist build mkdir build

REM Konfiguriere mit CMake (Visual Studio 2022)
echo.
echo Konfiguriere Projekt...
cmake -B build -G "Visual Studio 17 2022" -A x64 -DJUCE_PATH=JUCE
if errorlevel 1 (
    echo FEHLER: CMake Konfiguration fehlgeschlagen!
    pause
    exit /b 1
)

REM Baue Release-Version
echo.
echo Baue Release-Version...
cmake --build build --config Release
if errorlevel 1 (
    echo FEHLER: Build fehlgeschlagen!
    pause
    exit /b 1
)

echo.
echo ==========================================
echo  Build erfolgreich!
echo ==========================================
echo.
echo VST3 Plugin befindet sich in:
echo build\vst3-feedback-plugin_artefacts\Release\vst3-feedback-plugin.vst3
echo.
echo Zum Installieren kopiere den Ordner nach:
echo %%LOCALAPPDATA%%\Programs\Common\VST3\
echo.
pause
