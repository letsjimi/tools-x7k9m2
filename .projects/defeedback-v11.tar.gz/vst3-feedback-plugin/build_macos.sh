#!/bin/bash

echo "=========================================="
echo " DeFeedbackV1.1 - macOS Build Script"
echo "=========================================="
echo ""

# Prüfe ob JUCE vorhanden ist
if [ ! -f "JUCE/CMakeLists.txt" ]; then
    echo "JUCE nicht gefunden. Lade JUCE..."
    git clone https://github.com/juce-framework/JUCE.git JUCE
    if [ $? -ne 0 ]; then
        echo "FEHLER: Konnte JUCE nicht klonen!"
        exit 1
    fi
fi

# Erstelle Build-Verzeichnis
echo "Erstelle Build-Verzeichnis..."
mkdir -p build

# Konfiguriere mit CMake
echo ""
echo "Konfiguriere Projekt..."
cmake -B build -G "Unix Makefiles" -DJUCE_PATH=JUCE
if [ $? -ne 0 ]; then
    echo "FEHLER: CMake Konfiguration fehlgeschlagen!"
    echo ""
    echo "Stelle sicher dass CMake installiert ist:"
    echo "  brew install cmake"
    exit 1
fi

# Baue Release-Version
echo ""
echo "Baue Release-Version..."
cmake --build build --config Release -j$(sysctl -n hw.ncpu)
if [ $? -ne 0 ]; then
    echo "FEHLER: Build fehlgeschlagen!"
    exit 1
fi

echo ""
echo "=========================================="
echo " Build erfolgreich!"
echo "=========================================="
echo ""
echo "VST3 Plugin befindet sich in:"
echo "  build/vst3-feedback-plugin_artefacts/Release/vst3-feedback-plugin.vst3"
echo ""
echo "Zum Installieren kopiere nach:"
echo "  ~/Library/Audio/Plug-Ins/VST3/"
echo ""
