#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"

//==============================================================================
/**
 * Editor for the Feedback Suppressor plugin.
 *
 * Layout:
 *  ┌──────────────────────────────────────────┐
 *  │  [Mode ▼]        [Engine ▼]              │
 *  │                                          │
 *  │  Strength     ═══════○═══════            │
 *  │  Max Notches  ═══════○═══════            │
 *  │  Notch Q      ═══════○═══════            │
 *  │  Release Time ═══════○═══════            │
 *  │  Sensitivity  ═══════○═══════            │
 *  │                                          │
 *  │  ─── Noise Engine ───                    │
 *  │  Noise Amount ═══════○═══════            │
 *  │  Dereverb Amt ═══════○═══════            │
 *  │                                          │
 *  │  Output Trim  ═══════○═══════            │
 *  │                                          │
 *  │  Active Notches: ████░░░░ (4/8)          │
 *  └──────────────────────────────────────────┘
 */
class FeedbackSuppressorEditor : public juce::AudioProcessorEditor,
                                 private juce::AudioProcessorValueTreeState::Listener
{
public:
    explicit FeedbackSuppressorEditor(FeedbackSuppressorProcessor&);
    ~FeedbackSuppressorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    //==============================================================================
    void parameterChanged(const juce::String& parameterID, float newValue) override;

    //==============================================================================
    // Attachments (link sliders/combos to APVTS)
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachStrength_;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachMaxNotches_;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachNotchQ_;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachReleaseTime_;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachSensitivity_;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> attachMode_;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> attachEngine_;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachNoiseAmount_;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachDereverbAmount_;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachOutputTrim_;

    //==============================================================================
    // Controls
    juce::Slider sliderStrength;
    juce::Slider sliderMaxNotches;
    juce::Slider sliderNotchQ;
    juce::Slider sliderReleaseTime;
    juce::Slider sliderSensitivity;
    juce::Slider sliderNoiseAmount;
    juce::Slider sliderDereverbAmount;
    juce::Slider sliderOutputTrim;

    juce::ComboBox comboMode;
    juce::ComboBox comboEngine;

    juce::Label labelStrength      { {}, "Strength" };
    juce::Label labelMaxNotches    { {}, "Max Notches" };
    juce::Label labelNotchQ        { {}, "Notch Q" };
    juce::Label labelReleaseTime   { {}, "Release Time" };
    juce::Label labelSensitivity   { {}, "Sensitivity" };
    juce::Label labelNoiseAmount   { {}, "Noise Amount" };
    juce::Label labelDereverbAmount{ {}, "Dereverb Amount" };
    juce::Label labelOutputTrim   { {}, "Output Trim" };
    juce::Label labelMode          { {}, "Mode" };
    juce::Label labelEngine        { {}, "Engine" };
    juce::Label labelNotchCount    { {}, "Active Notches: 0" };

    //==============================================================================
    // Colors
    static constexpr juce::uint32 kBgDark    = 0xff1a1a2e;
    static constexpr juce::uint32 kBgMedium  = 0xff16213e;
    static constexpr juce::uint32 kAccent    = 0xff0f3460;
    static constexpr juce::uint32 kHighlight = 0xffe94560;
    static constexpr juce::uint32 kTextLight = 0xffe0e0e0;

    FeedbackSuppressorProcessor& processor_;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(FeedbackSuppressorEditor)
};