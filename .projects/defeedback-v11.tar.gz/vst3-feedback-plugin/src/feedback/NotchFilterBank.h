#pragma once

#include <cstddef>
#include <vector>
#include <array>

namespace feedback {

/**
 * Adaptive notch filter bank for feedback suppression.
 *
 * Each notch is a second-order IIR band-reject filter (biquad).
 * Notches are created dynamically when feedback is detected and
 * released over time via the ReleaseManager.
 *
 * For stereo processing, each channel maintains independent
 * filter state (z1, z2) while sharing coefficients.
 */
class NotchFilterBank {
public:
    static constexpr size_t kMaxNotches = 16;
    static constexpr size_t kMaxChannels = 2;

    struct Notch {
        float frequency = 0.0f;   // Center frequency (Hz)
        float bandwidth = 10.0f;  // -3dB bandwidth (Hz), derived from Q
        float gainDb     = -24.0f; // Notch depth (dB, negative)
        float Q          = 10.0f;  // Quality factor

        // Biquad coefficients
        float b0 = 1.0f, b1 = 0.0f, b2 = 0.0f;
        float a0 = 1.0f, a1 = 0.0f, a2 = 0.0f;

        // Per-channel state (Direct Form II Transposed)
        std::array<std::array<float, 2>, kMaxChannels> state = {};  // [channel][z1, z2] → flat
        float z1[kMaxChannels] = {};
        float z2[kMaxChannels] = {};

        bool active = false;
        float age   = 0.0f;  // Blocks since activation
    };

    struct Config {
        float sampleRate    = 48000.0f;
        size_t maxNotches   = 8;
        float defaultQ      = 10.0f;    // Default Q for new notches
        float defaultDepth  = -24.0f;   // Default depth in dB
    };

    explicit NotchFilterBank();
    explicit NotchFilterBank(const Config& cfg);
    ~NotchFilterBank() = default;

    void configure(const Config& cfg);

    /** Process a single sample for the given channel through all active notches. */
    float processSample(float sample, size_t channel = 0);

    /** Process a block of samples in-place for the given channel. */
    void processBlock(float* samples, size_t numSamples, size_t channel = 0);

    /**
     * Add or update a notch at the given frequency.
     * If a notch near this freq already exists, it is refreshed.
     * Returns the notch index, or size_t(-1) if bank is full.
     */
    size_t addNotch(float frequency, float Q = 0.0f, float depthDb = 0.0f);

    /** Deactivate a notch by index. */
    void removeNotch(size_t index);

    /** Age all notches by one block; fade and deactivate those past release. */
    void ageNotches(float releaseTimeBlocks);

    /** Reset all notches and state. */
    void reset();

    /** Get current notch state (read-only). */
    const std::array<Notch, kMaxNotches>& notches() const { return notches_; }

    /** Get the number of active notches. */
    size_t activeCount() const;

private:
    /** Recalculate biquad coefficients for a notch. */
    void updateCoefficients(Notch& notch);

    Config config_;
    std::array<Notch, kMaxNotches> notches_;
};

} // namespace feedback