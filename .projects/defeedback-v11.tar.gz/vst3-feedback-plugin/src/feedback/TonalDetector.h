#pragma once
#include <vector>
#include <array>
#include <cstddef>
#include <cstdint>

namespace feedback {

/**
 * Goertzel-based tonal detector for feedback frequency identification.
 *
 * Operates on fixed-size blocks with no lookahead. Computes magnitude
 * at specific candidate frequencies using the Goertzel algorithm,
 * then evaluates peakiness, growth rate, and stability to determine
 * whether a feedback tone is present.
 */
class TonalDetector {
public:
    static constexpr size_t kMaxCandidateFreqs = 64;
    static constexpr size_t kHistoryDepth       = 8;

    struct Result {
        float  frequency    = 0.0f;  // Detected feedback frequency (Hz)
        float  magnitude    = 0.0f;  // Goertzel magnitude at that freq
        float  peakiness    = 0.0f;  // Ratio of peak to surrounding energy [0..1]
        float  growth       = 0.0f;  // Growth rate of the peak over recent blocks
        float  stability    = 0.0f;  // Stability score (how consistently present)
        bool   detected      = false; // True if this frequency is classified as feedback
    };

    struct Config {
        float  sampleRate          = 48000.0f;
        size_t blockSize           = 256;
        size_t fftSize             = 512;    // Goertzel window size (≤ blockSize × 2)
        float  minFreq             = 80.0f;   // Minimum candidate frequency
        float  maxFreq             = 16000.0f;
        size_t numCandidateFreqs   = 48;      // How many Goertzel bins to evaluate
        float  peakinessThreshold  = 0.35f;
        float  growthThreshold      = 1.6f;
        float  stabilityThreshold   = 0.55f;
        float  sensitivity          = 0.5f;   // 0..1, shifts thresholds
    };

    explicit TonalDetector();
    explicit TonalDetector(const Config& cfg);
    ~TonalDetector() = default;

    /** Re-initialize with new config. */
    void configure(const Config& cfg);

    /**
     * Process one block of mono samples.
     * `samples` must contain exactly `config.blockSize` elements.
     * Returns results for all detected feedback tones.
     */
    std::vector<Result> process(const float* samples, size_t numSamples);

    /** Get the current config. */
    const Config& config() const noexcept { return config_; }

private:
    /** Recalculate Goertzel coefficients for all candidate bins. */
    void updateCoefficients();

    /** Run Goertzel on a window of samples for a single bin index. */
    float goertzelMagnitude(const float* data, size_t length, size_t binIndex) const;

    /** Compute peakiness: ratio of peak magnitude to local spectral energy. */
    float computePeakiness(size_t peakIdx, const std::vector<float>& magnitudes) const;

    /** Update growth and stability history for a candidate. */
    void updateHistory(size_t idx, float magnitude);

    Config config_;

    // Goertzel coefficients per candidate bin
    std::vector<float> coeff_;       // cos(2πk/N)
    std::vector<float> coeff2_;      // 2·coeff
    std::vector<float> freqs_;       // Actual frequency per bin

    // Per-bin history (ring buffer of magnitudes)
    std::vector<std::array<float, kHistoryDepth>> history_;
    std::vector<size_t> histWrite_;
    std::vector<float> prevMag_;

    // Reusable window buffer
    std::vector<float> window_;
};

} // namespace feedback