#pragma once
#include <cstddef>
#include <array>

namespace feedback {

/**
 * Manages the gradual release (fade-out) of notch filters.
 *
 * When a feedback tone disappears, we don't immediately remove the notch.
 * Instead, the ReleaseManager tracks how long the notch has been "unconfirmed"
 * and gradually reduces its depth before finally deactivating it.
 */
class ReleaseManager {
public:
    struct Config {
        float releaseTimeMs    = 2000.0f;  // Time before notch starts fading
        float fadeTimeMs        = 1000.0f;  // Duration of the fade-out
        float sampleRate        = 48000.0f;
        size_t blockSize        = 256;
    };

    explicit ReleaseManager();
    explicit ReleaseManager(const Config& cfg);
    ~ReleaseManager() = default;

    void configure(const Config& cfg);

    /**
     * Confirm that a notch at `frequency` is still receiving feedback.
     * Resets its unconfirmed counter.
     */
    void confirm(float frequency, float tolerance = 0.0f);

    /**
     * Process one block: advance all notch ages, compute fade factors,
     * and mark notches that should be removed.
     * Returns the number of blocks since last confirmation for each notch.
     */
    void advance();

    /**
     * Get the fade factor [0..1] for a notch at `frequency`.
     * 1.0 = fully active, 0.0 = fully faded out.
     */
    float fadeFactor(float frequency) const;

    /** Should the notch at `frequency` be completely removed? */
    bool shouldRemove(float frequency) const;

    /** Reset all state. */
    void reset();

private:
    struct NotchState {
        float frequency     = 0.0f;
        float blocksUnconfirmed = 0.0f;
        bool  active         = false;
    };

    static constexpr size_t kMaxSlots = 16;
    std::array<NotchState, kMaxSlots> slots_{};

    Config config_;
    float releaseBlocks_ = 0.0f;
    float fadeBlocks_    = 0.0f;
};

} // namespace feedback