#include "FeedbackCore.h"
#include <algorithm>
#include <cmath>

namespace feedback {

// ─────────────────────────────────────────────────────────────────────────────
// Construction / Configuration
// ─────────────────────────────────────────────────────────────────────────────

FeedbackCore::FeedbackCore()
{
    configure(Config{});
}

FeedbackCore::FeedbackCore(const Config& cfg)
{
    configure(cfg);
}

void FeedbackCore::configure(const Config& cfg)
{
    config_ = cfg;

    detector_.configure(detectorConfigForMode(config_.mode));
    notchBank_.configure(notchConfigForMode(config_.mode));
    releaseMgr_.configure(releaseConfigForMode(config_.mode));

    monoBuffer_.resize(config_.blockSize, 0.0f);
}

// ─────────────────────────────────────────────────────────────────────────────
// Processing — mono analysis, stereo notch filtering
// ─────────────────────────────────────────────────────────────────────────────

void FeedbackCore::process(float* left, float* right, size_t numSamples)
{
    // Create mono analysis signal (L+R)/2
    monoBuffer_.resize(numSamples);
    for (size_t i = 0; i < numSamples; ++i) {
        monoBuffer_[i] = 0.5f * (left[i] + right[i]);
    }

    // Analyze mono and update notches
    analyzeAndUpdate(monoBuffer_.data(), numSamples);

    // Apply notches to both channels with independent filter state
    // Channel 0 = left, Channel 1 = right
    notchBank_.processBlock(left, numSamples, 0);
    notchBank_.processBlock(right, numSamples, 1);
}

void FeedbackCore::analyzeAndUpdate(const float* mono, size_t numSamples)
{
    // Detect feedback tones
    auto results = detector_.process(mono, numSamples);

    // Scale detection results by strength
    const float strength = config_.strength;

    // Confirm or add notches for detected feedback
    for (const auto& r : results) {
        if (r.detected) {
            // Confirm with release manager
            releaseMgr_.confirm(r.frequency);

            // Compute notch depth based on strength and detected severity
            float depth = -6.0f - 30.0f * strength;  // -6dB to -36dB
            float Q = config_.notchQ;

            // Higher peakiness → tighter notch
            if (r.peakiness > 0.7f) {
                Q *= 1.5f;
            }

            // Add or refresh the notch
            size_t idx = notchBank_.addNotch(r.frequency, Q, depth);
            if (idx == size_t(-1)) {
                // Bank full — remove oldest notch
                float oldestAge = -1.0f;
                size_t oldestIdx = 0;
                const auto& notches = notchBank_.notches();
                for (size_t i = 0; i < config_.maxNotches && i < NotchFilterBank::kMaxNotches; ++i) {
                    if (notches[i].active && notches[i].age > oldestAge) {
                        oldestAge = notches[i].age;
                        oldestIdx = i;
                    }
                }
                notchBank_.removeNotch(oldestIdx);
                notchBank_.addNotch(r.frequency, Q, depth);
            }
        }
    }

    // Advance release manager
    releaseMgr_.advance();

    // Check for notches that should be removed (faded out completely)
    const auto& notches = notchBank_.notches();
    for (size_t i = 0; i < config_.maxNotches && i < NotchFilterBank::kMaxNotches; ++i) {
        if (notches[i].active && releaseMgr_.shouldRemove(notches[i].frequency)) {
            notchBank_.removeNotch(i);
        }
    }

    // Age notches — triggers fade-out for notches past release time
    float releaseBlocks = config_.releaseTimeMs * config_.sampleRate
                        / (1000.0f * static_cast<float>(config_.blockSize));
    notchBank_.ageNotches(releaseBlocks);
}

void FeedbackCore::reset()
{
    detector_.configure(detectorConfigForMode(config_.mode));
    notchBank_.reset();
    releaseMgr_.reset();
    std::fill(monoBuffer_.begin(), monoBuffer_.end(), 0.0f);
}

size_t FeedbackCore::activeNotchCount() const
{
    return notchBank_.activeCount();
}

// ─────────────────────────────────────────────────────────────────────────────
// Mode-specific configurations
// ─────────────────────────────────────────────────────────────────────────────

TonalDetector::Config FeedbackCore::detectorConfigForMode(OperationMode mode) const
{
    TonalDetector::Config cfg;
    cfg.sampleRate = config_.sampleRate;
    cfg.blockSize  = config_.blockSize;
    cfg.sensitivity = config_.sensitivity;

    switch (mode) {
        case OperationMode::Ultra:
            cfg.fftSize            = 512;
            cfg.numCandidateFreqs  = 48;
            cfg.peakinessThreshold = 0.35f;
            cfg.growthThreshold    = 1.6f;
            cfg.stabilityThreshold = 0.55f;
            break;
        case OperationMode::Balanced:
            cfg.fftSize            = 1024;
            cfg.numCandidateFreqs  = 64;
            cfg.peakinessThreshold = 0.30f;
            cfg.growthThreshold    = 1.4f;
            cfg.stabilityThreshold = 0.50f;
            break;
        case OperationMode::Quality:
            cfg.fftSize            = 2048;
            cfg.numCandidateFreqs  = 96;
            cfg.peakinessThreshold = 0.25f;
            cfg.growthThreshold    = 1.3f;
            cfg.stabilityThreshold = 0.45f;
            break;
    }
    return cfg;
}

NotchFilterBank::Config FeedbackCore::notchConfigForMode(OperationMode mode) const
{
    NotchFilterBank::Config cfg;
    cfg.sampleRate   = config_.sampleRate;
    cfg.maxNotches   = config_.maxNotches;
    cfg.defaultQ     = config_.notchQ;
    cfg.defaultDepth  = -24.0f;

    switch (mode) {
        case OperationMode::Ultra:
            cfg.defaultDepth = -18.0f;  // Less aggressive in live mode for safety
            break;
        case OperationMode::Balanced:
            cfg.defaultDepth = -24.0f;
            break;
        case OperationMode::Quality:
            cfg.defaultDepth = -30.0f;  // Can be more aggressive in quality mode
            break;
    }
    return cfg;
}

ReleaseManager::Config FeedbackCore::releaseConfigForMode(OperationMode mode) const
{
    ReleaseManager::Config cfg;
    cfg.sampleRate     = config_.sampleRate;
    cfg.blockSize      = config_.blockSize;
    cfg.releaseTimeMs  = config_.releaseTimeMs;

    switch (mode) {
        case OperationMode::Ultra:
            cfg.releaseTimeMs = config_.releaseTimeMs * 0.75f;  // Faster release for live
            cfg.fadeTimeMs    = 500.0f;
            break;
        case OperationMode::Balanced:
            cfg.releaseTimeMs = config_.releaseTimeMs;
            cfg.fadeTimeMs    = 1000.0f;
            break;
        case OperationMode::Quality:
            cfg.releaseTimeMs = config_.releaseTimeMs * 1.5f;  // Slower release for quality
            cfg.fadeTimeMs    = 1500.0f;
            break;
    }
    return cfg;
}

} // namespace feedback