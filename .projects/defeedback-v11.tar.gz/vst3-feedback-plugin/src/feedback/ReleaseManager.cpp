#include "ReleaseManager.h"
#include <cmath>
#include <algorithm>

namespace feedback {

// ─────────────────────────────────────────────────────────────────────────────
// Construction / Configuration
// ─────────────────────────────────────────────────────────────────────────────

ReleaseManager::ReleaseManager()
{
    configure(Config{});
}

ReleaseManager::ReleaseManager(const Config& cfg)
{
    configure(cfg);
}

void ReleaseManager::configure(const Config& cfg)
{
    config_ = cfg;
    releaseBlocks_ = config_.releaseTimeMs * config_.sampleRate / (1000.0f * static_cast<float>(config_.blockSize));
    fadeBlocks_    = config_.fadeTimeMs * config_.sampleRate / (1000.0f * static_cast<float>(config_.blockSize));
    reset();
}

// ─────────────────────────────────────────────────────────────────────────────
// Operations
// ─────────────────────────────────────────────────────────────────────────────

void ReleaseManager::confirm(float frequency, float tolerance)
{
    if (tolerance <= 0.0f) tolerance = frequency * 0.01f;

    for (auto& s : slots_) {
        if (s.active && std::fabs(s.frequency - frequency) < tolerance) {
            s.blocksUnconfirmed = 0.0f;
            return;
        }
    }

    // Not found — register a new slot
    for (auto& s : slots_) {
        if (!s.active) {
            s.frequency = frequency;
            s.blocksUnconfirmed = 0.0f;
            s.active = true;
            return;
        }
    }
}

void ReleaseManager::advance()
{
    for (auto& s : slots_) {
        if (!s.active) continue;
        s.blocksUnconfirmed += 1.0f;
    }
}

float ReleaseManager::fadeFactor(float frequency) const
{
    float tolerance = frequency * 0.01f;

    for (const auto& s : slots_) {
        if (s.active && std::fabs(s.frequency - frequency) < tolerance) {
            if (s.blocksUnconfirmed < releaseBlocks_) {
                return 1.0f;  // Still in hold period
            }
            const float fadeProgress = (s.blocksUnconfirmed - releaseBlocks_) / fadeBlocks_;
            return std::max(1.0f - fadeProgress, 0.0f);
        }
    }
    return 1.0f;  // Unknown frequency → fully active
}

bool ReleaseManager::shouldRemove(float frequency) const
{
    float tolerance = frequency * 0.01f;

    for (const auto& s : slots_) {
        if (s.active && std::fabs(s.frequency - frequency) < tolerance) {
            return s.blocksUnconfirmed > (releaseBlocks_ + fadeBlocks_);
        }
    }
    return false;
}

void ReleaseManager::reset()
{
    for (auto& s : slots_) {
        s.active = false;
        s.frequency = 0.0f;
        s.blocksUnconfirmed = 0.0f;
    }
}

} // namespace feedback