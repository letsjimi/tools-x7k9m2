#include "TonalDetector.h"
#include <cmath>
#include <algorithm>
#include <numeric>

namespace feedback {

static constexpr float kPi  = 3.14159265358979323846f;
static constexpr float kPi2 = 6.28318530717958647692f;

// ─────────────────────────────────────────────────────────────────────────────
// Construction / Configuration
// ─────────────────────────────────────────────────────────────────────────────

TonalDetector::TonalDetector()
{
    configure(Config{});
}

TonalDetector::TonalDetector(const Config& cfg)
{
    configure(cfg);
}

void TonalDetector::configure(const Config& cfg)
{
    config_ = cfg;

    const size_t N = config_.fftSize;
    const size_t numBins = config_.numCandidateFreqs;
    const float sr = config_.sampleRate;
    const float bw = (config_.maxFreq - config_.minFreq);

    coeff_.resize(numBins);
    coeff2_.resize(numBins);
    freqs_.resize(numBins);
    history_.resize(numBins);
    histWrite_.resize(numBins, 0);
    prevMag_.resize(numBins, 0.0f);

    // Generate logarithmically-spaced candidate frequencies
    for (size_t i = 0; i < numBins; ++i) {
        const float frac = static_cast<float>(i) / static_cast<float>(numBins - 1);
        const float freq = config_.minFreq * std::pow(config_.maxFreq / config_.minFreq, frac);
        freqs_[i] = freq;

        // Goertzel coefficient: k = freq * N / sr
        const float k = freq * static_cast<float>(N) / sr;
        const float c = std::cos(kPi2 * k / static_cast<float>(N));
        coeff_[i]  = c;
        coeff2_[i] = 2.0f * c;

        history_[i].fill(0.0f);
        histWrite_[i] = 0;
    }

    window_.resize(N, 0.0f);
}

// ─────────────────────────────────────────────────────────────────────────────
// Main processing
// ─────────────────────────────────────────────────────────────────────────────

std::vector<TonalDetector::Result> TonalDetector::process(const float* samples, size_t numSamples)
{
    const size_t N = config_.fftSize;
    const size_t numBins = config_.numCandidateFreqs;

    // Build analysis window: zero-pad if block < fftSize
    std::fill(window_.begin(), window_.end(), 0.0f);
    const size_t copyLen = std::min(numSamples, N);
    std::copy(samples, samples + copyLen, window_.begin());

    // Apply Hann window
    for (size_t i = 0; i < N; ++i) {
        const float w = 0.5f * (1.0f - std::cos(kPi2 * static_cast<float>(i) / static_cast<float>(N - 1)));
        window_[i] *= w;
    }

    // Compute Goertzel magnitudes for all candidate bins
    std::vector<float> magnitudes(numBins);
    for (size_t i = 0; i < numBins; ++i) {
        magnitudes[i] = goertzelMagnitude(window_.data(), N, i);
    }

    // Compute total spectral energy (for peakiness normalization)
    float totalEnergy = 0.0f;
    for (float m : magnitudes) totalEnergy += m;
    totalEnergy = std::max(totalEnergy, 1e-10f);

    // Adaptive thresholds based on sensitivity
    const float sens = config_.sensitivity;
    const float peakinessThresh = config_.peakinessThreshold * (1.0f - 0.5f * sens);
    const float growthThresh    = config_.growthThreshold    * (1.0f - 0.4f * sens);
    const float stabilityThresh = config_.stabilityThreshold * (1.0f - 0.3f * sens);

    // Evaluate each bin for feedback characteristics
    std::vector<Result> results;

    for (size_t i = 0; i < numBins; ++i) {
        Result r;
        r.frequency = freqs_[i];
        r.magnitude = magnitudes[i];
        r.peakiness = computePeakiness(i, magnitudes);

        // Growth: ratio of current magnitude to previous
        const float prev = std::max(prevMag_[i], 1e-10f);
        r.growth = magnitudes[i] / prev;

        // Update history
        updateHistory(i, magnitudes[i]);
        prevMag_[i] = magnitudes[i];

        // Stability: fraction of history entries above a noise floor
        size_t above = 0;
        const float floor = totalEnergy * 0.02f;
        for (float h : history_[i]) {
            if (h > floor) ++above;
        }
        r.stability = static_cast<float>(above) / static_cast<float>(kHistoryDepth);

        // Detection decision: all three metrics must exceed thresholds
        r.detected = (r.peakiness > peakinessThresh)
                  && (r.growth    > growthThresh)
                  && (r.stability > stabilityThresh);

        if (r.detected) {
            results.push_back(r);
        }
    }

    return results;
}

// ─────────────────────────────────────────────────────────────────────────────
// Goertzel magnitude
// ─────────────────────────────────────────────────────────────────────────────

float TonalDetector::goertzelMagnitude(const float* data, size_t length, size_t binIndex) const
{
    // Standard Goertzel algorithm
    const float c2 = coeff2_[binIndex];
    float s0 = 0.0f, s1 = 0.0f, s2 = 0.0f;

    for (size_t n = 0; n < length; ++n) {
        s0 = data[n] + c2 * s1 - s2;
        s2 = s1;
        s1 = s0;
    }

    // Magnitude squared
    const float power = s1 * s1 + s2 * s2 - c2 * s1 * s2;
    return std::sqrt(std::max(power, 0.0f));
}

// ─────────────────────────────────────────────────────────────────────────────
// Peakiness computation
// ─────────────────────────────────────────────────────────────────────────────

float TonalDetector::computePeakiness(size_t peakIdx, const std::vector<float>& magnitudes) const
{
    const size_t N = magnitudes.size();
    if (N < 3) return 0.0f;

    const float peak = magnitudes[peakIdx];

    // Local neighborhood: ±3 bins (wrapping)
    float localSum = 0.0f;
    size_t localCount = 0;
    for (size_t offset = 1; offset <= 3; ++offset) {
        size_t lo = (peakIdx >= offset) ? peakIdx - offset : 0;
        size_t hi = std::min(peakIdx + offset, N - 1);
        localSum += magnitudes[lo] + magnitudes[hi];
        localCount += 2;
    }

    const float localAvg = localSum / static_cast<float>(localCount);
    if (localAvg < 1e-10f) return (peak > 1e-6f) ? 1.0f : 0.0f;

    return peak / (peak + localAvg);  // Range [0..1]
}

// ─────────────────────────────────────────────────────────────────────────────
// History update
// ─────────────────────────────────────────────────────────────────────────────

void TonalDetector::updateHistory(size_t idx, float magnitude)
{
    history_[idx][histWrite_[idx] % kHistoryDepth] = magnitude;
    ++histWrite_[idx];
}

} // namespace feedback