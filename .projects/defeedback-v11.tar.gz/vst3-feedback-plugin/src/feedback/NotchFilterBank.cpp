#include "NotchFilterBank.h"
#include <cmath>
#include <algorithm>

namespace feedback {

static constexpr float kPi  = 3.14159265358979323846f;
static constexpr float kPi2 = 6.28318530717958647692f;

// ─────────────────────────────────────────────────────────────────────────────
// Construction / Configuration
// ─────────────────────────────────────────────────────────────────────────────

NotchFilterBank::NotchFilterBank()
{
    configure(Config{});
}

NotchFilterBank::NotchFilterBank(const Config& cfg)
{
    configure(cfg);
}

void NotchFilterBank::configure(const Config& cfg)
{
    config_ = cfg;
    reset();
}

// ─────────────────────────────────────────────────────────────────────────────
// Processing
// ─────────────────────────────────────────────────────────────────────────────

float NotchFilterBank::processSample(float sample, size_t channel)
{
    if (channel >= kMaxChannels) channel = 0;
    float y = sample;
    for (size_t i = 0; i < config_.maxNotches && i < kMaxNotches; ++i) {
        auto& n = notches_[i];
        if (!n.active) continue;

        // Direct Form II Transposed biquad (per-channel state)
        const float out = n.b0 * y + n.z1[channel];
        n.z1[channel] = n.b1 * y - n.a1 * out + n.z2[channel];
        n.z2[channel] = n.b2 * y - n.a2 * out;
        y = out;
    }
    return y;
}

void NotchFilterBank::processBlock(float* samples, size_t numSamples, size_t channel)
{
    for (size_t s = 0; s < numSamples; ++s) {
        samples[s] = processSample(samples[s], channel);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Notch management
// ─────────────────────────────────────────────────────────────────────────────

size_t NotchFilterBank::addNotch(float frequency, float Q, float depthDb)
{
    // Use defaults if not specified
    if (Q <= 0.0f) Q = config_.defaultQ;
    if (depthDb >= 0.0f) depthDb = config_.defaultDepth;

    // Check if a notch near this frequency already exists (within 1%)
    const float tolerance = frequency * 0.01f;
    for (size_t i = 0; i < config_.maxNotches && i < kMaxNotches; ++i) {
        if (notches_[i].active && std::fabs(notches_[i].frequency - frequency) < tolerance) {
            // Refresh existing notch
            notches_[i].Q = Q;
            notches_[i].gainDb = depthDb;
            notches_[i].age = 0.0f;
            updateCoefficients(notches_[i]);
            return i;
        }
    }

    // Find an inactive slot
    for (size_t i = 0; i < config_.maxNotches && i < kMaxNotches; ++i) {
        if (!notches_[i].active) {
            notches_[i].frequency = frequency;
            notches_[i].Q = Q;
            notches_[i].gainDb = depthDb;
            notches_[i].bandwidth = frequency / Q;
            notches_[i].age = 0.0f;
            // Clear per-channel state
            for (size_t ch = 0; ch < kMaxChannels; ++ch) {
                notches_[i].z1[ch] = 0.0f;
                notches_[i].z2[ch] = 0.0f;
            }
            notches_[i].active = true;
            updateCoefficients(notches_[i]);
            return i;
        }
    }

    // Bank full
    return size_t(-1);
}

void NotchFilterBank::removeNotch(size_t index)
{
    if (index < kMaxNotches) {
        notches_[index].active = false;
        for (size_t ch = 0; ch < kMaxChannels; ++ch) {
            notches_[index].z1[ch] = 0.0f;
            notches_[index].z2[ch] = 0.0f;
        }
    }
}

void NotchFilterBank::ageNotches(float releaseTimeBlocks)
{
    if (releaseTimeBlocks <= 0.0f) return;

    for (size_t i = 0; i < config_.maxNotches && i < kMaxNotches; ++i) {
        auto& n = notches_[i];
        if (!n.active) continue;

        n.age += 1.0f;

        if (n.age > releaseTimeBlocks) {
            // Fade out: progressively reduce notch depth
            const float overAge = n.age - releaseTimeBlocks;
            const float fadeBlocks = releaseTimeBlocks * 0.5f;  // Fade over half the release time
            const float fade = 1.0f - std::min(overAge / fadeBlocks, 1.0f);

            if (fade <= 0.0f) {
                n.active = false;
                for (size_t ch = 0; ch < kMaxChannels; ++ch) {
                    n.z1[ch] = 0.0f;
                    n.z2[ch] = 0.0f;
                }
            } else {
                // Shallow the notch as it fades
                n.gainDb = config_.defaultDepth * fade;
                updateCoefficients(n);
            }
        }
    }
}

void NotchFilterBank::reset()
{
    for (auto& n : notches_) {
        n.active = false;
        n.frequency = 0.0f;
        n.age = 0.0f;
        for (size_t ch = 0; ch < kMaxChannels; ++ch) {
            n.z1[ch] = 0.0f;
            n.z2[ch] = 0.0f;
        }
    }
}

size_t NotchFilterBank::activeCount() const
{
    size_t count = 0;
    for (size_t i = 0; i < config_.maxNotches && i < kMaxNotches; ++i) {
        if (notches_[i].active) ++count;
    }
    return count;
}

// ─────────────────────────────────────────────────────────────────────────────
// Biquad coefficient calculation (notch filter — peaking EQ with negative gain)
// ─────────────────────────────────────────────────────────────────────────────

void NotchFilterBank::updateCoefficients(Notch& n)
{
    const float sr = config_.sampleRate;
    const float f0 = std::max(n.frequency, 20.0f);
    const float Q  = std::max(n.Q, 0.1f);
    const float A  = std::pow(10.0f, n.gainDb / 40.0f);  // Amplitude from dB

    const float w0 = kPi2 * f0 / sr;
    const float cosW0 = std::cos(w0);
    const float sinW0 = std::sin(w0);
    const float alpha = sinW0 / (2.0f * Q);

    // Peaking EQ (negative gain → notch)
    const float sqrtA = std::sqrt(A);
    const float a0inv = 1.0f / (1.0f + alpha / A);

    n.b0 = (1.0f + alpha * A) * a0inv;
    n.b1 = (-2.0f * cosW0) * a0inv;
    n.b2 = (1.0f - alpha * A) * a0inv;
    n.a1 = (-2.0f * cosW0) * a0inv;
    n.a2 = (1.0f - alpha / A) * a0inv;
}

} // namespace feedback