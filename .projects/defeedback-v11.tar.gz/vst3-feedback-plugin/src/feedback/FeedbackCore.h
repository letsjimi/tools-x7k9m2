#pragma once

#include "TonalDetector.h"
#include "NotchFilterBank.h"
#include "ReleaseManager.h"
#include <vector>
#include <cstddef>

namespace feedback {

/**
 * Operating mode of the plugin.
 * Each mode adjusts internal parameters for the appropriate latency/quality tradeoff.
 */
enum class OperationMode {
    Ultra   = 0,   // 0 lookahead, maximum stability, live performance
    Balanced = 1,  // Moderate enhancement allowed
    Quality  = 2   // Complex engines + small lookahead for speech mode OK
};

/**
 * Core feedback suppression engine.
 *
 * Coordinates tonal detection, notch filtering, and release management.
 * Processes audio in blocks with zero lookahead (Ultra mode).
 * Mono analysis, stereo processing with independent per-channel filter state.
 */
class FeedbackCore {
public:
    struct Config {
        float sampleRate        = 48000.0f;
        size_t blockSize        = 256;
        OperationMode mode      = OperationMode::Ultra;
        float strength          = 0.5f;    // 0..1 — overall suppression aggressiveness
        size_t maxNotches       = 8;
        float notchQ            = 10.0f;
        float releaseTimeMs     = 2000.0f;
        float sensitivity       = 0.5f;    // 0..1 — detection sensitivity
    };

    explicit FeedbackCore();
    explicit FeedbackCore(const Config& cfg);
    ~FeedbackCore() = default;

    void configure(const Config& cfg);

    /**
     * Process a stereo block.
     * `left` and `right` are modified in-place.
     * Analysis is performed on the mono mix; notches are applied to both channels
     * with independent filter state per channel.
     */
    void process(float* left, float* right, size_t numSamples);

    /** Reset all state (e.g. on transport start). */
    void reset();

    /** Get current config. */
    const Config& config() const noexcept { return config_; }

    /** Get number of currently active notches. */
    size_t activeNotchCount() const;

private:
    /**
     * Analyze mono signal and manage notch lifecycle.
     */
    void analyzeAndUpdate(const float* mono, size_t numSamples);

    Config config_;
    TonalDetector   detector_;
    NotchFilterBank notchBank_;
    ReleaseManager  releaseMgr_;

    std::vector<float> monoBuffer_;

    // Per-mode detector configurations
    TonalDetector::Config detectorConfigForMode(OperationMode mode) const;
    NotchFilterBank::Config notchConfigForMode(OperationMode mode) const;
    ReleaseManager::Config releaseConfigForMode(OperationMode mode) const;
};

} // namespace feedback