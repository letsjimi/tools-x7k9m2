#include "PluginEditor.h"

//==============================================================================
// Construction / Destruction
//==============================================================================

FeedbackSuppressorEditor::FeedbackSuppressorEditor(FeedbackSuppressorProcessor& p)
    : AudioProcessorEditor(&p), processor_(p)
{
    // ── Slider setup ─────────────────────────────────────────────────────────
    auto setupSlider = [this](juce::Slider& s, const juce::String& name) {
        s.setSliderStyle(juce::Slider::LinearHorizontal);
        s.setTextBoxStyle(juce::Slider::TextBoxRight, false, 60, 20);
        s.setName(name);
        addAndMakeVisible(s);
    };

    setupSlider(sliderStrength,       "Strength");
    setupSlider(sliderMaxNotches,    "Max Notches");
    setupSlider(sliderNotchQ,         "Notch Q");
    setupSlider(sliderReleaseTime,   "Release Time");
    setupSlider(sliderSensitivity,    "Sensitivity");
    setupSlider(sliderNoiseAmount,   "Noise Amount");
    setupSlider(sliderDereverbAmount,"Dereverb Amount");
    setupSlider(sliderOutputTrim,     "Output Trim");

    // Max Notches should be integer
    sliderMaxNotches.setSliderStyle(juce::Slider::LinearHorizontal);
    sliderMaxNotches.setTextBoxStyle(juce::Slider::TextBoxRight, false, 60, 20);

    // Output Trim in dB
    sliderOutputTrim.setTextValueSuffix(" dB");

    // Release Time in seconds
    sliderReleaseTime.setTextValueSuffix(" s");

    // ── ComboBoxes ───────────────────────────────────────────────────────────
    comboMode.addItem("Ultra / Live", 1);
    comboMode.addItem("Balanced",     2);
    comboMode.addItem("Quality",      3);
    addAndMakeVisible(comboMode);

    comboEngine.addItem("Off",            1);
    comboEngine.addItem("WebRTC ANS",    2);
    comboEngine.addItem("RNNoise",       3);
    comboEngine.addItem("DeepFilterNet",  4);
    comboEngine.addItem("SpeexDSP",      5);
    addAndMakeVisible(comboEngine);

    // ── Labels ───────────────────────────────────────────────────────────────
    auto setupLabel = [this](juce::Label& l) {
        l.setColour(juce::Label::textColourId, juce::Colour(kTextLight));
        l.setJustificationType(juce::Justification::centredRight);
        addAndMakeVisible(l);
    };

    setupLabel(labelStrength);
    setupLabel(labelMaxNotches);
    setupLabel(labelNotchQ);
    setupLabel(labelReleaseTime);
    setupLabel(labelSensitivity);
    setupLabel(labelNoiseAmount);
    setupLabel(labelDereverbAmount);
    setupLabel(labelOutputTrim);
    setupLabel(labelMode);
    setupLabel(labelEngine);

    labelNotchCount.setColour(juce::Label::textColourId, juce::Colour(kHighlight));
    labelNotchCount.setJustificationType(juce::Justification::centred);
    addAndMakeVisible(labelNotchCount);

    // ── APVTS Attachments ────────────────────────────────────────────────────
    using PID = FeedbackSuppressorProcessor;
    attachStrength_       = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        processor_.getAPVTS(), PID::kParamStrength, sliderStrength);
    attachMaxNotches_     = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        processor_.getAPVTS(), PID::kParamMaxNotches, sliderMaxNotches);
    attachNotchQ_         = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        processor_.getAPVTS(), PID::kParamNotchQ, sliderNotchQ);
    attachReleaseTime_    = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        processor_.getAPVTS(), PID::kParamReleaseTime, sliderReleaseTime);
    attachSensitivity_    = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        processor_.getAPVTS(), PID::kParamSensitivity, sliderSensitivity);
    attachMode_           = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(
        processor_.getAPVTS(), PID::kParamMode, comboMode);
    attachEngine_         = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(
        processor_.getAPVTS(), PID::kParamEngine, comboEngine);
    attachNoiseAmount_    = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        processor_.getAPVTS(), PID::kParamNoiseAmount, sliderNoiseAmount);
    attachDereverbAmount_ = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        processor_.getAPVTS(), PID::kParamDereverbAmount, sliderDereverbAmount);
    attachOutputTrim_     = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        processor_.getAPVTS(), PID::kParamOutputTrim, sliderOutputTrim);

    // ── Size ────────────────────────────────────────────────────────────────
    setSize(420, 520);
}

FeedbackSuppressorEditor::~FeedbackSuppressorEditor()
{
}

//==============================================================================
// Paint
//==============================================================================

void FeedbackSuppressorEditor::paint(juce::Graphics& g)
{
    // Background
    g.fillAll(juce::Colour(kBgDark));

    // Title
    g.setColour(juce::Colour(kHighlight));
    g.setFont(juce::FontOptions{}.withPointHeight(18.0f).withStyle("bold"));
    g.drawText("Feedback Suppressor", getLocalBounds().removeFromTop(30),
               juce::Justification::centred, true);

    // Section divider for Noise Engine
    auto bounds = getLocalBounds();
    g.setColour(juce::Colour(kAccent));
    g.drawHorizontalLine(310, 10, getWidth() - 10);
    g.setColour(juce::Colour(kTextLight));
    g.setFont(juce::FontOptions{}.withPointHeight(11.0f));
    g.drawText("Noise Engine", juce::Rectangle<int>(10, 305, 120, 16),
               juce::Justification::centredLeft, true);
}

//==============================================================================
// Layout
//==============================================================================

void FeedbackSuppressorEditor::resized()
{
    auto bounds = getLocalBounds();

    // Title area
    bounds.removeFromTop(35);

    // Mode & Engine row
    auto topRow = bounds.removeFromTop(30);
    labelMode.setBounds(topRow.removeFromLeft(50));
    comboMode.setBounds(topRow.removeFromLeft(120).reduced(2));
    topRow.removeFromLeft(10);
    labelEngine.setBounds(topRow.removeFromLeft(55));
    comboEngine.setBounds(topRow.removeFromLeft(130).reduced(2));

    bounds.removeFromTop(8);

    // Slider layout helper
    auto addSliderRow = [&](juce::Label& label, juce::Slider& slider, int height = 28) {
        auto row = bounds.removeFromTop(height);
        label.setBounds(row.removeFromLeft(110));
        slider.setBounds(row.reduced(4));
        bounds.removeFromTop(4);
    };

    addSliderRow(labelStrength,    sliderStrength);
    addSliderRow(labelMaxNotches,  sliderMaxNotches);
    addSliderRow(labelNotchQ,      sliderNotchQ);
    addSliderRow(labelReleaseTime, sliderReleaseTime);
    addSliderRow(labelSensitivity, sliderSensitivity);

    // Noise engine section
    bounds.removeFromTop(20);

    addSliderRow(labelNoiseAmount,    sliderNoiseAmount);
    addSliderRow(labelDereverbAmount, sliderDereverbAmount);

    addSliderRow(labelOutputTrim, sliderOutputTrim);

    // Active notches indicator
    bounds.removeFromTop(8);
    labelNotchCount.setBounds(bounds.removeFromTop(24));

    // Update notch count display
    int active = static_cast<int>(processor_.getActiveNotchCount());
    labelNotchCount.setText(
        juce::String("Active Notches: ") + juce::String(active),
        juce::dontSendNotification);
}

//==============================================================================
// Parameter change callback
//==============================================================================

void FeedbackSuppressorEditor::parameterChanged(const juce::String& parameterID, float)
{
    // Refresh notch count on any parameter change
    if (parameterID == FeedbackSuppressorProcessor::kParamStrength ||
        parameterID == FeedbackSuppressorProcessor::kParamSensitivity ||
        parameterID == FeedbackSuppressorProcessor::kParamMaxNotches)
    {
        int active = static_cast<int>(processor_.getActiveNotchCount());
        labelNotchCount.setText(
            juce::String("Active Notches: ") + juce::String(active),
            juce::dontSendNotification);
    }
}