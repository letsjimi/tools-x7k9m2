#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
// Parameter layout
//==============================================================================

juce::AudioProcessorValueTreeState::ParameterLayout
FeedbackSuppressorProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // Strength: 0..1
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        kParamStrength, "Strength",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.5f));

    // Max Notches: 1..16
    params.push_back(std::make_unique<juce::AudioParameterInt>(
        kParamMaxNotches, "Max Notches", 1, 16, 8));

    // Notch Q: 1..50
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        kParamNotchQ, "Notch Q",
        juce::NormalisableRange<float>(1.0f, 50.0f, 0.1f, 0.3f), 10.0f));

    // Release Time: 0.5..10 seconds
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        kParamReleaseTime, "Release Time",
        juce::NormalisableRange<float>(0.5f, 10.0f, 0.1f, 0.4f), 2.0f));

    // Sensitivity: 0..1
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        kParamSensitivity, "Sensitivity",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.5f));

    // Mode: Ultra=0, Balanced=1, Quality=2
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        kParamMode, "Mode",
        juce::StringArray("Ultra / Live", "Balanced", "Quality"), 0));

    // Engine: Off=0, WebRTC=1, RNNoise=2, DeepFilterNet=3, SpeexDSP=4
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        kParamEngine, "Engine",
        juce::StringArray("Off", "WebRTC ANS", "RNNoise", "DeepFilterNet", "SpeexDSP"), 0));

    // Noise Amount: 0..1
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        kParamNoiseAmount, "Noise Amount",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.5f));

    // Dereverb Amount: 0..1
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        kParamDereverbAmount, "Dereverb Amount",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.0f));

    // Output Trim: -12..+12 dB
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        kParamOutputTrim, "Output Trim",
        juce::NormalisableRange<float>(-12.0f, 12.0f, 0.1f, 0.4f), 0.0f));

    return { params.begin(), params.end() };
}

//==============================================================================
// Construction / Destruction
//==============================================================================

FeedbackSuppressorProcessor::FeedbackSuppressorProcessor()
    : AudioProcessor(BusesProperties()
        .withInput("Input",  juce::AudioChannelSet::stereo(), true)
        .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "Parameters", createParameterLayout()),
      feedbackCore_()
{
    // Cache atomic parameter pointers for lock-free access
    paramStrength       = dynamic_cast<std::atomic<float>*>(apvts.getRawParameterValue(kParamStrength));
    paramMaxNotches     = dynamic_cast<std::atomic<float>*>(apvts.getRawParameterValue(kParamMaxNotches));
    paramNotchQ         = dynamic_cast<std::atomic<float>*>(apvts.getRawParameterValue(kParamNotchQ));
    paramReleaseTime    = dynamic_cast<std::atomic<float>*>(apvts.getRawParameterValue(kParamReleaseTime));
    paramSensitivity    = dynamic_cast<std::atomic<float>*>(apvts.getRawParameterValue(kParamSensitivity));
    paramMode            = dynamic_cast<std::atomic<float>*>(apvts.getRawParameterValue(kParamMode));
    paramEngine          = dynamic_cast<std::atomic<float>*>(apvts.getRawParameterValue(kParamEngine));
    paramNoiseAmount    = dynamic_cast<std::atomic<float>*>(apvts.getRawParameterValue(kParamNoiseAmount));
    paramDereverbAmount = dynamic_cast<std::atomic<float>*>(apvts.getRawParameterValue(kParamDereverbAmount));
    paramOutputTrim      = dynamic_cast<std::atomic<float>*>(apvts.getRawParameterValue(kParamOutputTrim));

    noiseEngine_ = engines::EngineFactory::create(engines::EngineType::Off);
}

FeedbackSuppressorProcessor::~FeedbackSuppressorProcessor()
{
}

//==============================================================================
// Prepare / Release
//==============================================================================

void FeedbackSuppressorProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    currentSampleRate_  = sampleRate;
    currentBlockSize_   = samplesPerBlock;

    feedback::FeedbackCore::Config cfg;
    cfg.sampleRate    = static_cast<float>(sampleRate);
    cfg.blockSize     = static_cast<size_t>(samplesPerBlock);
    cfg.mode          = getCurrentMode();
    cfg.strength      = paramStrength->load();
    cfg.maxNotches    = static_cast<size_t>(paramMaxNotches->load());
    cfg.notchQ        = paramNotchQ->load();
    cfg.releaseTimeMs = paramReleaseTime->load() * 1000.0f;
    cfg.sensitivity   = paramSensitivity->load();
    feedbackCore_.configure(cfg);

    if (noiseEngine_) {
        noiseEngine_->initialize(sampleRate, samplesPerBlock);
    }
}

void FeedbackSuppressorProcessor::releaseResources()
{
    feedbackCore_.reset();
    if (noiseEngine_) noiseEngine_->reset();
}

//==============================================================================
// Processing
//==============================================================================

bool FeedbackSuppressorProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    // Support mono and stereo
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono() &&
        layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;

    return true;
}

void FeedbackSuppressorProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    const int numChannels = buffer.getNumChannels();
    const int numSamples  = buffer.getNumSamples();

    if (numSamples == 0) return;

    // Update parameters
    updateParameters();

    // Apply noise/dereverb engine first (if enabled)
    if (noiseEngine_ && noiseEngine_->isReady()) {
        float* channelData = buffer.getWritePointer(0);
        noiseEngine_->process(channelData, static_cast<size_t>(numSamples * numChannels), numChannels);
    }

    // Feedback suppression
    if (numChannels >= 2) {
        float* left  = buffer.getWritePointer(0);
        float* right = buffer.getWritePointer(1);
        feedbackCore_.process(left, right, static_cast<size_t>(numSamples));
    } else if (numChannels == 1) {
        // Mono: use same buffer for both "channels"
        float* mono = buffer.getWritePointer(0);
        feedbackCore_.process(mono, mono, static_cast<size_t>(numSamples));
    }

    // Output trim
    const float trimDb = paramOutputTrim->load();
    if (std::abs(trimDb) > 0.01f) {
        const float gain = juce::Decibels::decibelsToGain(trimDb);
        buffer.applyGain(gain);
    }
}

void FeedbackSuppressorProcessor::processBlock(juce::AudioBuffer<double>&, juce::MidiBuffer&)
{
    // Double-precision not supported; use float path
    jassertfalse;
}

//==============================================================================
// Parameter updates
//==============================================================================

void FeedbackSuppressorProcessor::updateParameters()
{
    // Check if engine changed
    updateEngine();

    // Update feedback core config
    feedback::FeedbackCore::Config cfg = feedbackCore_.config();
    cfg.strength      = paramStrength->load();
    cfg.maxNotches    = static_cast<size_t>(std::round(paramMaxNotches->load()));
    cfg.notchQ        = paramNotchQ->load();
    cfg.releaseTimeMs = paramReleaseTime->load() * 1000.0f;
    cfg.sensitivity   = paramSensitivity->load();
    cfg.mode          = getCurrentMode();
    feedbackCore_.configure(cfg);

    // Update noise engine parameters
    if (noiseEngine_) {
        noiseEngine_->setNoiseAmount(paramNoiseAmount->load());
        noiseEngine_->setDereverbAmount(paramDereverbAmount->load());
    }
}

void FeedbackSuppressorProcessor::updateEngine()
{
    const int engineIdx = static_cast<int>(std::round(paramEngine->load()));
    const auto newType = static_cast<engines::EngineType>(engineIdx);

    if (newType != currentEngineType_) {
        currentEngineType_ = newType;
        noiseEngine_ = engines::EngineFactory::create(newType);

        if (noiseEngine_) {
            noiseEngine_->initialize(currentSampleRate_, currentBlockSize_);
            noiseEngine_->setNoiseAmount(paramNoiseAmount->load());
            noiseEngine_->setDereverbAmount(paramDereverbAmount->load());
        }
    }
}

feedback::OperationMode FeedbackSuppressorProcessor::getCurrentMode() const
{
    const int modeIdx = static_cast<int>(std::round(paramMode->load()));
    switch (modeIdx) {
        case 0:  return feedback::OperationMode::Ultra;
        case 1:  return feedback::OperationMode::Balanced;
        case 2:  return feedback::OperationMode::Quality;
        default: return feedback::OperationMode::Ultra;
    }
}

size_t FeedbackSuppressorProcessor::getActiveNotchCount() const
{
    return feedbackCore_.activeNotchCount();
}

//==============================================================================
// State save/load
//==============================================================================

void FeedbackSuppressorProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void FeedbackSuppressorProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, sizeInBytes));
    if (xml && xml->hasTagName(apvts.state.getType().toString())) {
        auto state = juce::ValueTree::fromXml(*xml);
        apvts.replaceState(state);
    }
}

//==============================================================================
// Editor
//==============================================================================

juce::AudioProcessorEditor* FeedbackSuppressorProcessor::createEditor()
{
    return new FeedbackSuppressorEditor(*this);
}