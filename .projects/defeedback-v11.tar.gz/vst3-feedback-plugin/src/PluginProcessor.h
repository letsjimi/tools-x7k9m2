#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>

#include "feedback/FeedbackCore.h"
#include "engines/INoiseEngine.h"
#include "engines/EngineFactory.h"

#include <memory>

//==============================================================================
/**
 * VST3 Feedback Suppression Plugin for Live Vocals.
 *
 * Features:
 *  - Zero-latency feedback detection and notch filtering (Goertzel-based)
 *  - Adaptive notch filter bank with release management
 *  - Optional noise/dereverb engines (WebRTC, RNNoise, DeepFilterNet, SpeexDSP)
 *  - Three operating modes: Ultra, Balanced, Quality
 *  - Full parameter automation via AudioProcessorValueTreeState
 */
class FeedbackSuppressorProcessor : public juce::AudioProcessor {
public:
    //==============================================================================
    // Parameter IDs
    static constexpr const char* kParamStrength       = "strength";
    static constexpr const char* kParamMaxNotches     = "maxNotches";
    static constexpr const char* kParamNotchQ         = "notchQ";
    static constexpr const char* kParamReleaseTime    = "releaseTime";
    static constexpr const char* kParamSensitivity    = "sensitivity";
    static constexpr const char* kParamMode            = "mode";
    static constexpr const char* kParamEngine          = "engine";
    static constexpr const char* kParamNoiseAmount     = "noiseAmount";
    static constexpr const char* kParamDereverbAmount  = "dereverbAmount";
    static constexpr const char* kParamOutputTrim      = "outputTrim";

    //==============================================================================
    FeedbackSuppressorProcessor();
    ~FeedbackSuppressorProcessor() override;

    //==============================================================================
    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;

    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    void processBlock(juce::AudioBuffer<double>&, juce::MidiBuffer&) override;

    //==============================================================================
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    //==============================================================================
    const juce::String getName() const override { return "Feedback Suppressor"; }

    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    //==============================================================================
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return "Default"; }
    void changeProgramName(int, const juce::String&) override {}

    //==============================================================================
    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    //==============================================================================
    juce::AudioProcessorValueTreeState& getAPVTS() { return apvts; }
    const juce::AudioProcessorValueTreeState& getAPVTS() const { return apvts; }

    /** Get current number of active feedback notches. */
    size_t getActiveNotchCount() const;

    /** Get current operating mode. */
    feedback::OperationMode getCurrentMode() const;

private:
    //==============================================================================
    juce::AudioProcessorValueTreeState apvts;

    // Core processing
    feedback::FeedbackCore feedbackCore_;
    std::unique_ptr<engines::INoiseEngine> noiseEngine_;
    engines::EngineType currentEngineType_ = engines::EngineType::Off;

    // Parameters (cached from APVTS for lock-free access in processBlock)
    std::atomic<float>* paramStrength     = nullptr;
    std::atomic<float>* paramMaxNotches   = nullptr;
    std::atomic<float>* paramNotchQ       = nullptr;
    std::atomic<float>* paramReleaseTime  = nullptr;
    std::atomic<float>* paramSensitivity   = nullptr;
    std::atomic<float>* paramMode          = nullptr;
    std::atomic<float>* paramEngine        = nullptr;
    std::atomic<float>* paramNoiseAmount  = nullptr;
    std::atomic<float>* paramDereverbAmount = nullptr;
    std::atomic<float>* paramOutputTrim    = nullptr;

    double currentSampleRate_ = 48000.0;
    int currentBlockSize_     = 256;

    /** Read parameters from APVTS and update engine state. */
    void updateParameters();

    /** Recreate the noise engine if the engine selection changed. */
    void updateEngine();

    /** Create the parameter layout for APVTS. */
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(FeedbackSuppressorProcessor)
};