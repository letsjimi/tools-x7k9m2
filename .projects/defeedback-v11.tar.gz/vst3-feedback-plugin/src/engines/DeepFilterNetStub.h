#pragma once

#include "INoiseEngine.h"

namespace engines {

/**
 * DeepFilterNet engine stub.
 *
 * DeepFilterNet is a deep-learning-based noise suppression and dereverberation
 * library. Uses a DNN with low latency (~5ms lookahead).
 * Real integration would link against libdeep_filter.
 */
class DeepFilterNetStub final : public INoiseEngine {
public:
    DeepFilterNetStub() = default;
    ~DeepFilterNetStub() override = default;

    bool initialize(double sampleRate, int blockSize) override;
    void process(float* samples, size_t numSamples, int numChannels) override;
    void reset() override;
    const char* name() const override { return "DeepFilterNet (stub)"; }
    int lookaheadSamples() const override { return lookahead_; }
    void setNoiseAmount(float amount) override { noiseAmount_ = amount; }
    void setDereverbAmount(float amount) override { dereverbAmount_ = amount; }
    bool isReady() const override { return initialized_; }

private:
    static constexpr int kLookahead = 240;  // ~5ms @ 48kHz

    bool   initialized_    = false;
    double sampleRate_     = 48000.0;
    int    blockSize_      = 256;
    int    lookahead_      = kLookahead;
    float  noiseAmount_   = 0.5f;
    float  dereverbAmount_ = 0.0f;
};

} // namespace engines