#pragma once

#include <cstddef>
#include <cstdint>

namespace engines {

/**
 * Interface for noise reduction / dereverb processing engines.
 *
 * Implementations may wrap external libraries (WebRTC, RNNoise, etc.)
 * or provide pass-through stubs. The factory always returns a valid
 * object; if an engine is unavailable, a BypassEngine is returned.
 */
class INoiseEngine {
public:
    virtual ~INoiseEngine() = default;

    /** Initialize the engine for the given sample rate and block size. */
    virtual bool initialize(double sampleRate, int blockSize) = 0;

    /**
     * Process a block of audio in-place.
     * `samples` contains `numSamples` frames.
     * If stereo, channels are interleaved: L R L R …
     * `numChannels` indicates 1 (mono) or 2 (stereo).
     */
    virtual void process(float* samples, size_t numSamples, int numChannels) = 0;

    /** Reset internal state (e.g. on transport start). */
    virtual void reset() = 0;

    /** Get the engine's display name. */
    virtual const char* name() const = 0;

    /** Whether this engine requires lookahead (affects latency). */
    virtual int lookaheadSamples() const = 0;

    /** Set noise suppression amount [0..1]. */
    virtual void setNoiseAmount(float amount) = 0;

    /** Set dereverb amount [0..1]. */
    virtual void setDereverbAmount(float amount) = 0;

    /** Whether the engine is properly initialized and functional. */
    virtual bool isReady() const = 0;
};

} // namespace engines