#pragma once

#include "INoiseEngine.h"
#include <vector>

namespace engines {

/**
 * RNNoise engine stub.
 *
 * RNNoise is a neural-network-based noise suppression library by Mozilla/xiph.
 * Uses a GRU model (~500KB) trained on noise data.
 * Real integration would link against librnnoise.
 */
class RNNoiseStub final : public INoiseEngine {
public:
    RNNoiseStub() = default;
    ~RNNoiseStub() override = default;

    bool initialize(double sampleRate, int blockSize) override;
    void process(float* samples, size_t numSamples, int numChannels) override;
    void reset() override;
    const char* name() const override { return "RNNoise (stub)"; }
    int lookaheadSamples() const override { return 0; }
    void setNoiseAmount(float amount) override { noiseAmount_ = amount; }
    void setDereverbAmount(float amount) override { dereverbAmount_ = amount; }
    bool isReady() const override { return initialized_; }

private:
    static constexpr size_t kFrameSize = 480;  // RNNoise uses 10ms @ 48kHz

    bool   initialized_    = false;
    double sampleRate_     = 48000.0;
    int    blockSize_      = 256;
    float  noiseAmount_   = 0.5f;
    float  dereverbAmount_ = 0.0f;

    // Stub residual buffer for frame-size adaptation
    std::vector<float> residual_;
};

} // namespace engines