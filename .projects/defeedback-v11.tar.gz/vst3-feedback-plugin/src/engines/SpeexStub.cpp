#include "SpeexStub.h"
#include <cstring>
#include <cmath>

namespace engines {

bool SpeexStub::initialize(double sampleRate, int blockSize)
{
    // SpeexDSP supports 8/16/32/48 kHz
    if (sampleRate != 8000.0 && sampleRate != 16000.0 &&
        sampleRate != 32000.0 && sampleRate != 48000.0 && sampleRate != 96000.0) {
        initialized_ = false;
        return false;
    }

    sampleRate_  = sampleRate;
    blockSize_   = blockSize;
    initialized_ = true;

    // Real implementation:
    //   state_ = speex_preprocess_state_init(blockSize, static_cast<int>(sampleRate));
    //   int ns_level = static_cast<int>(noiseAmount_ * 10);  // 0..10
    //   speex_preprocess_ctl(state_, SPEEX_PREPROCESS_SET_NOISE_SUPPRESS, &ns_level);

    return true;
}

void SpeexStub::process(float* samples, size_t numSamples, int numChannels)
{
    if (!initialized_) return;

    // SpeexDSP processes mono; for stereo we'd process each channel independently.
    // Stub: pass through unchanged.
    // Real implementation:
    //   spx_int16_t buf[blockSize_];
    //   for each channel:
    //     float → int16 → speex_preprocess_run(state_, buf) → float

    (void)samples;
    (void)numSamples;
    (void)numChannels;
}

void SpeexStub::reset()
{
    // Real: speex_preprocess_state_destroy(state_);
    //       state_ = speex_preprocess_state_init(blockSize_, sampleRate_);
}

} // namespace engines