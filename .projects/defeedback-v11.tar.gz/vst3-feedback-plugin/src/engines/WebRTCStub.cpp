#include "WebRTCStub.h"
#include <algorithm>
#include <cstring>

namespace engines {

bool WebRTCStub::initialize(double sampleRate, int blockSize)
{
    // WebRTC APM supports 8/16/32/48 kHz
    if (sampleRate != 8000.0 && sampleRate != 16000.0 &&
        sampleRate != 32000.0 && sampleRate != 48000.0 && sampleRate != 96000.0) {
        initialized_ = false;
        return false;
    }

    sampleRate_  = sampleRate;
    blockSize_   = blockSize;
    initialized_ = true;

    // In a real implementation, this would call:
    // webrtc::AudioProcessing::Create()
    // apm->Initialize()
    // apm->noise_suppression()->Enable(true)
    // apm->echo_cancellation()->Enable(true)
    // etc.

    return true;
}

void WebRTCStub::process(float* samples, size_t numSamples, int numChannels)
{
    if (!initialized_) return;

    // Stub: pass through unchanged
    // Real implementation would:
    //   webrtc::AudioFrame frame;
    //   frame.num_channels_ = numChannels;
    //   frame.samples_per_channel_ = numSamples / numChannels;
    //   memcpy(frame.data_, samples, ...);
    //   apm_->ProcessReverseStream(&frame);  // for AEC
    //   apm_->ProcessStream(&frame);          // for NS + AGC
    //   memcpy(samples, frame.data_, ...);

    (void)samples;
    (void)numSamples;
    (void)numChannels;
}

void WebRTCStub::reset()
{
    // In real implementation: apm_->Initialize();
}

} // namespace engines