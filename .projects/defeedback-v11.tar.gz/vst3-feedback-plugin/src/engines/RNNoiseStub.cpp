#include "RNNoiseStub.h"
#include <cmath>
#include <cstring>

namespace engines {

bool RNNoiseStub::initialize(double sampleRate, int blockSize)
{
    // RNNoise only supports 48kHz
    if (fabs(sampleRate - 48000.0) > 0.1) {
        initialized_ = false;
        return false;
    }

    sampleRate_  = sampleRate;
    blockSize_   = blockSize;
    initialized_ = true;

    // Real implementation:
    //   state_ = rnnoise_create(nullptr);  // Uses built-in model
    //   rnnoise_init(state_);

    return true;
}

void RNNoiseStub::process(float* samples, size_t numSamples, int numChannels)
{
    if (!initialized_) return;

    // RNNoise processes in 480-sample frames at 48kHz.
    // In a real implementation we'd need frame-size adaptation.
    // Stub: pass through unchanged.

    // Real implementation outline:
    //   for each 480-sample frame:
    //     rnnoise_process_frame(state_, output, input);
    //   with overlap-save for arbitrary block sizes

    (void)samples;
    (void)numSamples;
    (void)numChannels;
}

void RNNoiseStub::reset()
{
    // Real: rnnoise_destroy(state_); state_ = rnnoise_create(nullptr);
    residual_.clear();
}

} // namespace engines