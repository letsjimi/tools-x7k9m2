#pragma once

#include "INoiseEngine.h"

namespace engines {

/**
 * WebRTC Audio Processing stub.
 *
 * Provides the interface for WebRTC's AEC/ANS/APM pipeline.
 * The real implementation would link against libwebrtc_audio_processing.
 * This stub passes audio through unchanged.
 */
class WebRTCStub final : public INoiseEngine {
public:
    WebRTCStub() = default;
    ~WebRTCStub() override = default;

    bool initialize(double sampleRate, int blockSize) override;
    void process(float* samples, size_t numSamples, int numChannels) override;
    void reset() override;
    const char* name() const override { return "WebRTC ANS (stub)"; }
    int lookaheadSamples() const override { return 0; }
    void setNoiseAmount(float amount) override { noiseAmount_ = amount; }
    void setDereverbAmount(float amount) override { dereverbAmount_ = amount; }
    bool isReady() const override { return initialized_; }

private:
    bool  initialized_    = false;
    double sampleRate_   = 48000.0;
    int   blockSize_     = 256;
    float noiseAmount_   = 0.5f;
    float dereverbAmount_ = 0.0f;
};

} // namespace engines