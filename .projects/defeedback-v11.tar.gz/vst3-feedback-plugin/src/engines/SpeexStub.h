#pragma once

#include "INoiseEngine.h"

namespace engines {

/**
 * SpeexDSP noise suppression stub.
 *
 * SpeexDSP provides a lightweight noise suppression preprocessor
 * based on minimum mean-square error log-spectral amplitude estimator.
 * Real integration would link against libspeexdsp.
 */
class SpeexStub final : public INoiseEngine {
public:
    SpeexStub() = default;
    ~SpeexStub() override = default;

    bool initialize(double sampleRate, int blockSize) override;
    void process(float* samples, size_t numSamples, int numChannels) override;
    void reset() override;
    const char* name() const override { return "SpeexDSP (stub)"; }
    int lookaheadSamples() const override { return 0; }
    void setNoiseAmount(float amount) override { noiseAmount_ = amount; }
    void setDereverbAmount(float amount) override { dereverbAmount_ = amount; }
    bool isReady() const override { return initialized_; }

private:
    bool   initialized_    = false;
    double sampleRate_     = 48000.0;
    int    blockSize_      = 256;
    float  noiseAmount_   = 0.5f;
    float  dereverbAmount_ = 0.0f;
};

} // namespace engines