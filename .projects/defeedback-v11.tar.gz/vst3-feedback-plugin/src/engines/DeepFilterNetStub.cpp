#include "DeepFilterNetStub.h"
#include <cmath>
#include <cstring>

namespace engines {

bool DeepFilterNetStub::initialize(double sampleRate, int blockSize)
{
    // DeepFilterNet supports 48kHz
    if (fabs(sampleRate - 48000.0) > 0.1 && fabs(sampleRate - 96000.0) > 0.1) {
        initialized_ = false;
        return false;
    }

    sampleRate_  = sampleRate;
    blockSize_   = blockSize;
    lookahead_   = static_cast<int>(kLookahead * (sampleRate / 48000.0));
    initialized_ = true;

    // Real implementation:
    //   auto df_state = df_create(/*model_path=*/nullptr, /*epoch=*/0);
    //   df_state->set_noise_threshold(noiseAmount_);
    //   df_state->set_dereverb(dereverbAmount_ > 0.0f);

    return true;
}

void DeepFilterNetStub::process(float* samples, size_t numSamples, int numChannels)
{
    if (!initialized_) return;

    // DeepFilterNet uses a DNN encoder-decoder with ~5ms lookahead.
    // Stub: pass through unchanged.
    // Real implementation:
    //   df_process_frame(df_state, output, input, numSamples);
    // With proper frame-size handling and overlap-add.

    (void)samples;
    (void)numSamples;
    (void)numChannels;
}

void DeepFilterNetStub::reset()
{
    // Real: df_destroy(df_state); df_state = df_create(nullptr, 0);
}

} // namespace engines