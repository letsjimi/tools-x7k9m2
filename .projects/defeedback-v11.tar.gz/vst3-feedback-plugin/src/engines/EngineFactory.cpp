#include "EngineFactory.h"
#include "WebRTCStub.h"
#include "RNNoiseStub.h"
#include "DeepFilterNetStub.h"
#include "SpeexStub.h"
#include <algorithm>

namespace engines {

// ─────────────────────────────────────────────────────────────────────────────
// Bypass engine (pass-through)
// ─────────────────────────────────────────────────────────────────────────────

class BypassEngine final : public INoiseEngine {
public:
    bool initialize(double, int) override { return true; }
    void process(float*, size_t, int) override {} // Pass-through: do nothing
    void reset() override {}
    const char* name() const override { return "Bypass"; }
    int lookaheadSamples() const override { return 0; }
    void setNoiseAmount(float) override {}
    void setDereverbAmount(float) override {}
    bool isReady() const override { return true; }
};

// ─────────────────────────────────────────────────────────────────────────────
// Factory methods
// ─────────────────────────────────────────────────────────────────────────────

std::unique_ptr<INoiseEngine> EngineFactory::create(EngineType type)
{
    switch (type) {
        case EngineType::Off:
            return std::make_unique<BypassEngine>();

        case EngineType::WebRTC:
            return std::make_unique<WebRTCStub>();

        case EngineType::RNNoise:
            return std::make_unique<RNNoiseStub>();

        case EngineType::DeepFilterNet:
            return std::make_unique<DeepFilterNetStub>();

        case EngineType::SpeexDSP:
            return std::make_unique<SpeexStub>();

        default:
            return std::make_unique<BypassEngine>();
    }
}

const char* EngineFactory::engineName(EngineType type)
{
    switch (type) {
        case EngineType::Off:          return "Off";
        case EngineType::WebRTC:       return "WebRTC ANS";
        case EngineType::RNNoise:      return "RNNoise";
        case EngineType::DeepFilterNet: return "DeepFilterNet";
        case EngineType::SpeexDSP:     return "SpeexDSP";
        default:                       return "Unknown";
    }
}

std::vector<EngineType> EngineFactory::availableEngines()
{
    return {
        EngineType::Off,
        EngineType::WebRTC,
        EngineType::RNNoise,
        EngineType::DeepFilterNet,
        EngineType::SpeexDSP
    };
}

} // namespace engines