#pragma once

#include "INoiseEngine.h"
#include <memory>
#include <string>
#include <vector>

namespace engines {

/**
 * Engine type identifiers.
 * Used by the UI dropdown and factory to select the engine.
 */
enum class EngineType {
    Off          = 0,
    WebRTC       = 1,
    RNNoise      = 2,
    DeepFilterNet = 3,
    SpeexDSP     = 4
};

/**
 * Factory for creating noise/dereverb engine instances.
 *
 * If the requested engine is unavailable (missing library, etc.),
 * returns a BypassEngine that passes audio through unchanged.
 */
class EngineFactory {
public:
    /**
     * Create an engine instance of the given type.
     * Returns a bypass engine if the requested type is unavailable.
     */
    static std::unique_ptr<INoiseEngine> create(EngineType type);

    /**
     * Get the display name for an engine type.
     * Useful for populating UI dropdowns.
     */
    static const char* engineName(EngineType type);

    /**
     * Get all available engine types.
     * The first entry is always "Off".
     */
    static std::vector<EngineType> availableEngines();
};

} // namespace engines