# VST3 Feedback Suppressor Plugin

**Live vocal feedback suppression with zero-latency notch filtering.**

A JUCE-based VST3 audio plugin that detects and suppresses acoustic feedback
(howl/whistling) in real time. Designed for live vocal performance with
aggressive feedback rejection and minimal signal degradation.

---

## Architecture

```
┌──────────────────────────────────────────────────────┐
│                    Audio Input (Stereo)               │
│                         │                             │
│                    ┌────┴────┐                        │
│                    │ Mono Mix │                        │
│                    └────┬────┘                        │
│                         │                             │
│              ┌──────────┴──────────┐                 │
│              │   FeedbackCore      │                 │
│              │  ┌───────────────┐  │                 │
│              │  │ TonalDetector │  │ ← Goertzel FFT  │
│              │  └───────┬───────┘  │                 │
│              │          │           │                 │
│              │  ┌───────┴───────┐  │                 │
│              │  │NotchFilterBank│  │ ← Biquad notches│
│              │  └───────┬───────┘  │                 │
│              │          │           │                 │
│              │  ┌───────┴───────┐  │                 │
│              │  │ReleaseManager│  │ → Notch fade-out│
│              │  └──────────────┘  │                 │
│              └─────────┬─────────┘                 │
│                        │                             │
│              ┌─────────┴─────────┐                 │
│              │  Noise Engine (opt)│                 │
│              │  WebRTC/RNNoise/   │                 │
│              │  DeepFilter/Speex  │                 │
│              └─────────┬─────────┘                 │
│                        │                             │
│                   Output Trim                        │
│                        │                             │
│                Audio Output (Stereo)                 │
└──────────────────────────────────────────────────────┘
```

## Feedback Detection Algorithm

The core uses a **Goertzel-based tonal detector** (no FFT needed) that evaluates
three metrics for each candidate frequency:

1. **Peakiness** — Ratio of peak magnitude to local spectral energy. Narrow
   feedback tones have high peakiness.
2. **Growth** — Ratio of current magnitude to previous block's magnitude.
   Feedback grows exponentially; this catches it early.
3. **Stability** — Fraction of recent blocks where the tone exceeded the noise
   floor. True feedback is persistent, not transient.

A frequency is classified as feedback only when all three metrics exceed
adaptive thresholds (controlled by the **Sensitivity** parameter).

## Operating Modes

| Mode | Lookahead | FFT Size | Notch Depth | Use Case |
|------|-----------|----------|-------------|----------|
| **Ultra / Live** | 0 | 512 | -18 dB | Stage, live monitoring |
| **Balanced** | 0 | 1024 | -24 dB | Rehearsal, broadcast |
| **Quality** | 0* | 2048 | -30 dB | Studio, post-production |

\* Quality mode allows the optional noise engine to use small lookahead (e.g.
DeepFilterNet's ~5ms), but the feedback suppression itself remains zero-lookahead.

## Parameters

| Parameter | Range | Default | Description |
|-----------|-------|---------|-------------|
| Strength | 0–1 | 0.5 | Overall suppression aggressiveness |
| Max Notches | 1–16 | 8 | Maximum simultaneous notch filters |
| Notch Q | 1–50 | 10 | Quality factor for notch filters (higher = narrower) |
| Release Time | 0.5–10s | 2s | Time before a notch begins to fade |
| Sensitivity | 0–1 | 0.5 | Detection sensitivity (higher = catches fainter feedback) |
| Mode | Ultra/Balanced/Quality | Ultra | Operating mode |
| Engine | Off/WebRTC/RNNoise/DeepFilter/Speex | Off | Noise reduction engine |
| Noise Amount | 0–1 | 0.5 | Noise suppression intensity |
| Dereverb Amount | 0–1 | 0 | Dereverberation intensity |
| Output Trim | ±12 dB | 0 | Output gain |

## Noise Engine Stubs

The engine architecture uses the **Factory pattern** with `INoiseEngine` interface.
Currently all engines are **stubs** (pass-through) that provide the full API for
future integration:

- **WebRTC ANS** — Would link against `libwebrtc_audio_processing`
- **RNNoise** — Would link against `librnnoise` (10ms frames @ 48kHz)
- **DeepFilterNet** — Would link against `libdeep_filter` (~5ms lookahead)
- **SpeexDSP** — Would link against `libspeexdsp`

To integrate a real engine, replace the stub implementation while keeping the
same `INoiseEngine` interface. The factory will instantiate the real engine
when its library is available.

## Building

```bash
# Clone with JUCE submodule
git clone --recursive https://github.com/your-repo/vst3-feedback-plugin.git
cd vst3-feedback-plugin

# Build
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release

# The VST3 binary will be at:
# build/VST3FeedbackPlugin_artefacts/Release/VST3/Feedback Suppressor.vst3
```

### Requirements

- CMake 3.16+
- C++17 compiler (GCC 9+, Clang 10+, MSVC 2019+)
- JUCE (included as submodule)

### Sample Rates

Tested at 48kHz and 96kHz. The Goertzel detector and biquad filters are
sample-rate aware and adapt coefficients automatically.

## Signal Flow

1. **Input** → Mono mix for analysis
2. **Noise Engine** (optional, pre-feedback) → Reduces broadband noise
3. **FeedbackCore**:
   - TonalDetector analyzes mono signal for feedback tones
   - NotchFilterBank applies biquad notch filters at detected frequencies
   - ReleaseManager controls notch lifecycle (creation, hold, fade, removal)
4. **Output Trim** → Final gain staging
5. **Output**

## License

MIT