# DeFeedback V2.1 — Live-Vocal Feedback Suppression VST3

Production-ready JUCE VST3 audio plugin for real-time feedback suppression, de-reverb, and de-noise — optimized for live vocal use (church, conference, stage).

## Features

### Core: Feedback Suppression (0 Latency)
- **Goertzel-based detection** — per-bin magnitude analysis without FFT overhead
- **Adaptive notch filterbank** — up to 16 simultaneous 2nd-order IIR notch filters
- **Release mechanism** — exponential decay with configurable release time
- **Mono analysis, stereo processing** — analyzes mono downmix, applies notches to all channels

### De-Reverb
- Late-reverberation estimation via delayed envelope comparison
- Spectral gain suppression based on reverb-to-direct ratio
- Amount control from subtle to aggressive

### De-Noise (4 Switchable Engines)
| Engine | Method | Character |
|--------|--------|-----------|
| **WebRTC** | Spectral gate + noise floor tracking | Fast, stable |
| **RNNoise** | Bark-band Wiener filtering | Musical, natural |
| **DeepFilterNet** | Multi-resolution spectral subtraction | Deep, aggressive |
| **SpeexDSP** | Multi-band spectral subtraction | Balanced, proven |

Automatic fallback chain: WebRTC → SpeexDSP → RNNoise → DeepFilterNet

### Three Operating Modes
- **Ultra** — Max stability, fastest reaction (tighter notches, lower threshold)
- **Balanced** — Standard for church/speech (default)
- **Quality** — Stronger enhancement, still live-safe (wider notches, slower release)

## Parameters

| Parameter | Range | Default | Description |
|-----------|-------|---------|-------------|
| Mode | Ultra/Balanced/Quality | Balanced | Operating mode |
| Strength | 0–1 | 0.7 | Overall suppression depth |
| Max Notches | 1–16 | 8 | Maximum concurrent notch filters |
| Notch Q | 1–100 | 22 | Notch filter sharpness |
| Release | 0.1–10s | 1.5s | Notch release time |
| Sensitivity | 0–1 | 0.6 | Feedback detection sensitivity |
| Noise Engine | Dropdown | WebRTC | NR engine selection |
| Noise Amount | 0–1 | 0.5 | Noise suppression depth |
| Dereverb Amount | 0–1 | 0 | Dereverb suppression depth |
| Output Trim | ±12 dB | 0 | Output gain trim |

## Build

### Prerequisites
- CMake ≥ 3.22
- C++17 compiler (MSVC 2019+, GCC 9+, Clang 11+)
- JUCE 7.x (clone from https://github.com/juce-framework/JUCE)

### Steps

```bash
# 1. Clone JUCE (if not already available)
git clone https://github.com/juce-framework/JUCE.git ../JUCE

# 2. Configure
cmake -B build -DJUCE_PATH=/path/to/JUCE

# 3. Build
cmake --build build --config Release -j$(nproc)

# 4. Find VST3 at:
#    build/DeFeedbackV2_artefacts/Release/VST3/DeFeedback V2.1.vst3
```

### Cross-Platform
- **Windows**: Opens VS project or builds with Ninja/MSVC
- **macOS**: Builds .vst3 bundle in `~/Library/Audio/Plug-Ins/VST3/`
- **Linux**: Builds .vst3 — copy to `~/.vst3/` or `/usr/lib/vst3/`

## Architecture

```
Source/
├── DeFeedbackConstants.h       # Enums, param IDs, mode configs
├── PluginProcessor.h/.cpp      # JUCE AudioProcessor + APVTS
├── PluginEditor.h              # Editor forward declaration
├── DSP/
│   ├── GoertzelDetector        # Per-frequency Goertzel analysis
│   ├── AdaptiveNotchFilter     # 2nd-order IIR band-reject
│   ├── FeedbackSuppressor      # Detector + notch bank orchestrator
│   ├── DereverbProcessor      # Late-reverb suppression
│   └── DenoiseProcessor       # Engine delegation
├── Engines/
│   ├── NoiseEngine             # Abstract interface
│   ├── EngineFactory           # Factory + fallback chain
│   ├── WebRTCEngine            # WebRTC ANS-style
│   ├── RNNoiseEngine           # Bark-band Wiener
│   ├── DeepFilterNetEngine     # Multi-resolution spectral
│   └── SpeexDSPEngine          # Multi-band spectral subtraction
└── UI/
    ├── DeFeedbackEditor        # Main plugin GUI
    ├── ModeSelector            # 3-way mode toggle
    ├── EngineSelector          # Engine dropdown
    └── ParameterSlider         # Slider + label component
```

## Signal Flow

```
Input → Feedback Suppression → De-Reverb → De-Noise → Output Trim → Output
         (Goertzel detect)     (envelope)   (engine)    (dB gain)
         (Adaptive notches)
```

## Design Decisions

- **Goertzel over FFT**: Zero-latency per-bin analysis. No FFT buffer → no added latency. Only evaluates candidate feedback frequencies (80 Hz–8 kHz), not the entire spectrum.
- **Mono analysis**: Feedback is a monaural phenomenon. Analyzing a mono downmix avoids stereo phase issues and halves detection cost.
- **Stereo processing**: Notches apply to all channels to maintain imaging.
- **Release ramp**: Exponential gain decay (not hard on/off) prevents audible clicks when notches release.
- **Engine factory with fallback**: If an external library (RNNoise, DeepFilterNet) isn't linked, falls back gracefully.

## License

Private / All rights reserved.