/*
  DeFeedback V2.1 - DeepFilterNet Engine
  Wrapper for DeepFilterNet deep-learning noise suppression
  Falls back to spectral gate if library not linked
*/
#pragma once

#include "NoiseEngine.h"

namespace DeFeedback
{

class DeepFilterNetEngine : public NoiseEngine
{
public:
    DeepFilterNetEngine() = default;
    ~DeepFilterNetEngine() override = default;

    void prepare (double sampleRate, int blockSize) override;
    void process (float* samples, int numSamples) override;
    void setAmount (float amount) override;
    void reset() override;
    const char* getName() const override { return "DeepFilterNet"; }
    bool isAvailable() const override { return available_; }

private:
    double sampleRate_ = 48000.0;
    int    blockSize_  = 480;
    float  amount_    = 0.5f;
    bool   available_ = true;
    bool   initialized_ = false;

    // DeepFilterNet-inspired multi-resolution spectral processing
    static constexpr int kFFTSize = 512;
    static constexpr int kHalfFFT = kFFTSize / 2;
    static constexpr int kDepth   = 3;  // processing depth levels

    // Multi-resolution noise estimates
    float noiseEstimate_[kDepth][kHalfFFT / 4] = {};
    float smoothedGain_ = 1.0f;
    int   frameCount_ = 0;
};

} // namespace DeFeedback