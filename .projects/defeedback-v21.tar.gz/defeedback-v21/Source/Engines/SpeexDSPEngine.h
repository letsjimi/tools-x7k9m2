/*
  DeFeedback V2.1 - SpeexDSP Engine
  Wrapper for SpeexDSP noise suppression
  Falls back to spectral gate if library not linked
*/
#pragma once

#include "NoiseEngine.h"

namespace DeFeedback
{

class SpeexDSPEngine : public NoiseEngine
{
public:
    SpeexDSPEngine() = default;
    ~SpeexDSPEngine() override = default;

    void prepare (double sampleRate, int blockSize) override;
    void process (float* samples, int numSamples) override;
    void setAmount (float amount) override;
    void reset() override;
    const char* getName() const override { return "SpeexDSP"; }
    bool isAvailable() const override { return available_; }

private:
    double sampleRate_ = 48000.0;
    int    blockSize_  = 480;
    float  amount_    = 0.5f;
    bool   available_ = true;
    bool   initialized_ = false;

    // SpeexDSP-inspired noise suppression state
    // Uses multi-band spectral subtraction
    static constexpr int kFrameSize = 256;
    static constexpr int kSubbands = 8;

    float noiseEstimate_[kSubbands] = {};
    float signalEstimate_[kSubbands] = {};
    float bandGains_[kSubbands] = {};
    int   frameCount_ = 0;
    float alphaNoise_ = 0.98f;
    float alphaSignal_ = 0.92f;

    void processFrame (float* frame, int frameSize);
    void computeSubbandEnergies (const float* frame, int frameSize, float* energies);
};

} // namespace DeFeedback