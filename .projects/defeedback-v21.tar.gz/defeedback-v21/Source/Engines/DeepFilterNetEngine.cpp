/*
  DeFeedback V2.1 - DeepFilterNet Engine Implementation
  Multi-resolution deep-filter-inspired noise suppression
*/
#include "DeepFilterNetEngine.h"
#include <cmath>
#include <cstring>
#include <algorithm>

namespace DeFeedback
{

void DeepFilterNetEngine::prepare (double sampleRate, int blockSize)
{
    sampleRate_ = sampleRate;
    blockSize_  = blockSize;
    reset();
}

void DeepFilterNetEngine::process (float* samples, int numSamples)
{
    if (!initialized_)
        initialized_ = true;

    int pos = 0;
    while (pos + kFFTSize <= numSamples)
    {
        float blockEnergy = 0.0f;
        for (int i = 0; i < kFFTSize; ++i)
            blockEnergy += samples[pos + i] * samples[pos + i];
        blockEnergy /= kFFTSize;

        // Multi-resolution noise estimation at kDepth levels
        for (int d = 0; d < kDepth; ++d)
        {
            float alpha_d = 0.95f + d * 0.01f; // slower adaptation at higher depth
            int subBins = kHalfFFT / 4;

            // Simplified: use single energy metric per sub-block
            float subEnergy = blockEnergy;
            float& ne = noiseEstimate_[d][0];

            if (frameCount_ < 20)
                ne = ne * 0.5f + subEnergy * 0.5f;
            else
                ne = std::min (ne, ne * alpha_d + subEnergy * (1.0f - alpha_d));
        }

        // Combine depth estimates into single gain
        float combinedNoise = 0.0f;
        for (int d = 0; d < kDepth; ++d)
            combinedNoise += noiseEstimate_[d][0];
        combinedNoise /= kDepth;

        float gain = 1.0f;
        if (combinedNoise > 1e-10f)
        {
            float snr = blockEnergy / combinedNoise;
            float threshold = 1.0f + amount_ * 5.0f;
            gain = (snr - threshold * 0.5f) / snr;
            gain = std::clamp (std::sqrt (std::max (gain, 0.001f)), 0.05f, 1.0f);
        }

        // Heavy smoothing to avoid artifacts
        smoothedGain_ = 0.97f * smoothedGain_ + 0.03f * gain;

        for (int i = 0; i < kFFTSize; ++i)
            samples[pos + i] *= smoothedGain_;

        pos += kFFTSize / 2;
        frameCount_++;
    }
}

void DeepFilterNetEngine::setAmount (float amount)
{
    amount_ = std::clamp (amount, 0.0f, 1.0f);
}

void DeepFilterNetEngine::reset()
{
    std::memset (noiseEstimate_, 0, sizeof (noiseEstimate_));
    smoothedGain_ = 1.0f;
    frameCount_ = 0;
    initialized_ = true;
}

} // namespace DeFeedback