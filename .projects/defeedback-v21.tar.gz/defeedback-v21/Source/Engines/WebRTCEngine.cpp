/*
  DeFeedback V2.1 - WebRTC Engine Implementation
  Spectral-gate noise suppression inspired by WebRTC ANS
*/
#include "WebRTCEngine.h"
#include <cmath>
#include <algorithm>
#include <cstring>

namespace DeFeedback
{

void WebRTCEngine::prepare (double sampleRate, int blockSize)
{
    sampleRate_ = sampleRate;
    blockSize_  = blockSize;
    initWebRTCState();
}

void WebRTCEngine::initWebRTCState()
{
    std::memset (noiseEstimate_, 0, sizeof (noiseEstimate_));
    std::memset (prevBins_, 0, sizeof (prevBins_));
    updateCount_ = 0;
    initialized_ = true;
}

void WebRTCEngine::process (float* samples, int numSamples)
{
    if (!initialized_ || !available_)
        return;

    // Process in kFFTSize blocks with overlap
    // Simplified spectral gate: estimate noise floor, suppress below threshold
    int pos = 0;
    while (pos + kFFTSize <= numSamples)
    {
        // Window + FFT (simplified: use magnitude estimation via Goertzel-like approach)
        // For production: would use real FFT. Here: simplified spectral gate on time-domain
        float blockEnergy = 0.0f;
        for (int i = 0; i < kFFTSize; ++i)
            blockEnergy += samples[pos + i] * samples[pos + i];
        blockEnergy /= kFFTSize;

        // Noise floor estimation (minimum statistics over ~50 frames)
        if (updateCount_ < 50)
        {
            noiseEstimate_[0] = noiseEstimate_[0] * alpha_ + blockEnergy * (1.0f - alpha_);
            updateCount_++;
        }
        else
        {
            // Update noise estimate only if current is lower (noise floor tracking)
            float candidate = noiseEstimate_[0] * alpha_ + blockEnergy * (1.0f - alpha_);
            if (candidate < noiseEstimate_[0] * 1.5f)
                noiseEstimate_[0] = candidate;
        }

        // Spectral subtraction gain
        float noiseFloor = noiseEstimate_[0] * (1.0f + amount_ * 3.0f); // amount scales aggressiveness
        float gain = 1.0f;
        if (blockEnergy < noiseFloor && noiseFloor > 1e-10f)
        {
            gain = std::sqrt (blockEnergy / noiseFloor);
            gain = std::max (gain, 0.01f); // floor to avoid complete silence
        }

        // Apply gain with smoothing
        float prevGain = prevBins_[0];
        float smoothGain = beta_ * prevGain + (1.0f - beta_) * gain;
        prevBins_[0] = smoothGain;

        for (int i = 0; i < kFFTSize; ++i)
            samples[pos + i] *= smoothGain;

        pos += kFFTSize / 2; // 50% overlap
    }
}

void WebRTCEngine::setAmount (float amount)
{
    amount_ = std::clamp (amount, 0.0f, 1.0f);
    // More aggressive with higher amount
    alpha_ = 0.98f - amount_ * 0.08f;
}

void WebRTCEngine::reset()
{
    initWebRTCState();
}

} // namespace DeFeedback