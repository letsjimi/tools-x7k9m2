/*
  DeFeedback V2.1 - Engine Factory
  Creates noise-reduction engines with fallback chain
*/
#pragma once

#include "NoiseEngine.h"
#include "DeFeedbackConstants.h"
#include <memory>

namespace DeFeedback
{

class EngineFactory
{
public:
    // Create engine by type, with automatic fallback if unavailable
    static std::unique_ptr<NoiseEngine> create (EngineType type);

    // Create with fallback chain: try preferred, then fallback to next available
    static std::unique_ptr<NoiseEngine> createWithFallback (EngineType preferred);

    // Fallback order: WebRTC → SpeexDSP → RNNoise → DeepFilterNet
    static constexpr EngineType fallbackOrder[] = {
        EngineType::WebRTC,
        EngineType::SpeexDSP,
        EngineType::RNNoise,
        EngineType::DeepFilterNet
    };

    static const char* engineName (EngineType type);
};

} // namespace DeFeedback