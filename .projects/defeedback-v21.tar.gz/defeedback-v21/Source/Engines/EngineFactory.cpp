/*
  DeFeedback V2.1 - Engine Factory Implementation
*/
#include "EngineFactory.h"
#include "WebRTCEngine.h"
#include "RNNoiseEngine.h"
#include "DeepFilterNetEngine.h"
#include "SpeexDSPEngine.h"

namespace DeFeedback
{

std::unique_ptr<NoiseEngine> EngineFactory::create (EngineType type)
{
    switch (type)
    {
        case EngineType::WebRTC:
        {
            auto engine = std::make_unique<WebRTCEngine>();
            if (engine->isAvailable())
                return engine;
            break;
        }
        case EngineType::RNNoise:
        {
            auto engine = std::make_unique<RNNoiseEngine>();
            if (engine->isAvailable())
                return engine;
            break;
        }
        case EngineType::DeepFilterNet:
        {
            auto engine = std::make_unique<DeepFilterNetEngine>();
            if (engine->isAvailable())
                return engine;
            break;
        }
        case EngineType::SpeexDSP:
        {
            auto engine = std::make_unique<SpeexDSPEngine>();
            if (engine->isAvailable())
                return engine;
            break;
        }
    }
    return nullptr;
}

std::unique_ptr<NoiseEngine> EngineFactory::createWithFallback (EngineType preferred)
{
    // Try preferred first
    auto engine = create (preferred);
    if (engine)
        return engine;

    // Fallback chain
    for (auto fallback : fallbackOrder)
    {
        if (fallback == preferred) continue;
        engine = create (fallback);
        if (engine)
            return engine;
    }

    // Last resort: WebRTC (always available as built-in)
    return create (EngineType::WebRTC);
}

const char* EngineFactory::engineName (EngineType type)
{
    switch (type)
    {
        case EngineType::WebRTC:       return "WebRTC ANS";
        case EngineType::RNNoise:      return "RNNoise";
        case EngineType::DeepFilterNet: return "DeepFilterNet";
        case EngineType::SpeexDSP:     return "SpeexDSP";
    }
    return "Unknown";
}

} // namespace DeFeedback