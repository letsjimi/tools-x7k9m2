/*
  DeFeedback V2.1 - WebRTC Noise Suppression Engine
  Wraps the WebRTC ANS (Adaptive Noise Suppression) algorithm
*/
#pragma once

#include "NoiseEngine.h"

namespace DeFeedback
{

class WebRTCEngine : public NoiseEngine
{
public:
    WebRTCEngine() = default;
    ~WebRTCEngine() override = default;

    void prepare (double sampleRate, int blockSize) override;
    void process (float* samples, int numSamples) override;
    void setAmount (float amount) override;
    void reset() override;
    const char* getName() const override { return "WebRTC ANS"; }
    bool isAvailable() const override { return available_; }

private:
    // WebRTC ANS state - we implement the core algorithm inline
    // since we can't link the full WebRTC library easily
    void initWebRTCState();
    float processWebRTC (float input);

    double sampleRate_ = 48000.0;
    int    blockSize_  = 480;
    float  amount_    = 0.5f;
    bool   available_ = true;
    bool   initialized_ = false;

    // Simplified spectral-gate noise estimator
    // WebRTC ANS uses a noise floor estimator + spectral subtraction
    static constexpr int kFFTSize = 256;
    static constexpr int kHalfFFT = kFFTSize / 2;

    float noiseEstimate_[kHalfFFT] = {};
    float prevBins_[kHalfFFT] = {};
    float alpha_ = 0.95f;     // noise estimate smoothing
    float beta_  = 0.8f;      // signal smoothing
    int   updateCount_ = 0;
};

} // namespace DeFeedback