/*
  DeFeedback V2.1 - Noise Reduction Engine Interface
  All engines implement this interface
*/
#pragma once

#include <cstddef>

namespace DeFeedback
{

class NoiseEngine
{
public:
    virtual ~NoiseEngine() = default;

    virtual void prepare (double sampleRate, int blockSize) = 0;
    virtual void process (float* samples, int numSamples) = 0;
    virtual void setAmount (float amount) = 0;  // 0..1
    virtual void reset() = 0;
    virtual const char* getName() const = 0;
    virtual bool isAvailable() const = 0;       // runtime check
};

} // namespace DeFeedback