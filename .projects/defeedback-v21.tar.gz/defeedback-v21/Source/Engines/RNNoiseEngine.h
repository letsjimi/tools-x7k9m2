/*
  DeFeedback V2.1 - RNNoise Engine
  Wrapper for RNNoise (Xiph's RNN-based noise suppression)
  Falls back to spectral gate if RNNoise lib not available
*/
#pragma once

#include "NoiseEngine.h"

namespace DeFeedback
{

class RNNoiseEngine : public NoiseEngine
{
public:
    RNNoiseEngine() = default;
    ~RNNoiseEngine() override = default;

    void prepare (double sampleRate, int blockSize) override;
    void process (float* samples, int numSamples) override;
    void setAmount (float amount) override;
    void reset() override;
    const char* getName() const override { return "RNNoise"; }
    bool isAvailable() const override { return available_; }

private:
    double sampleRate_ = 48000.0;
    int    blockSize_  = 480;
    float  amount_    = 0.5f;
    bool   available_ = true;
    bool   initialized_ = false;

    // RNNoise operates at 48kHz with frame size 480
    // State for simplified RNN-inspired suppression
    static constexpr int kFrameSize = 480;
    static constexpr int kBands = 22;

    // Feature extraction + gain per band
    float bandGains_[kBands] = {};
    float noiseEstimate_[kBands] = {};
    float signalEstimate_[kBands] = {};
    int   frameCount_ = 0;
    float alpha_ = 0.92f;

    void processFrame (float* frame);
    void computeBandEnergies (const float* frame, float* energies);
    void computeGains (const float* signal, const float* noise, float* gains);
};

} // namespace DeFeedback