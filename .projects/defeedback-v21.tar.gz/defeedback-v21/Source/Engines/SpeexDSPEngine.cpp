/*
  DeFeedback V2.1 - SpeexDSP Engine Implementation
  Multi-band spectral subtraction noise suppression
*/
#include "SpeexDSPEngine.h"
#include <cmath>
#include <cstring>
#include <algorithm>

namespace DeFeedback
{

void SpeexDSPEngine::prepare (double sampleRate, int blockSize)
{
    sampleRate_ = sampleRate;
    blockSize_  = blockSize;
    reset();
}

void SpeexDSPEngine::process (float* samples, int numSamples)
{
    if (!initialized_)
        initialized_ = true;

    int pos = 0;
    while (pos + kFrameSize <= numSamples)
    {
        processFrame (samples + pos, kFrameSize);
        pos += kFrameSize / 2;
    }
}

void SpeexDSPEngine::processFrame (float* frame, int frameSize)
{
    float energies[kSubbands];
    computeSubbandEnergies (frame, frameSize, energies);

    // Update noise and signal estimates
    for (int b = 0; b < kSubbands; ++b)
    {
        if (frameCount_ < 10)
        {
            noiseEstimate_[b] = noiseEstimate_[b] * 0.7f + energies[b] * 0.3f;
        }
        else
        {
            // Noise estimate: only increase during low signal activity
            if (energies[b] < noiseEstimate_[b] * 1.5f)
                noiseEstimate_[b] = alphaNoise_ * noiseEstimate_[b] + (1.0f - alphaNoise_) * energies[b];
            else
                noiseEstimate_[b] *= 1.001f; // slow backoff
        }

        signalEstimate_[b] = alphaSignal_ * signalEstimate_[b] + (1.0f - alphaSignal_) * energies[b];
    }

    // Compute Wiener gains per subband
    float overallGain = 0.0f;
    float totalWeight = 0.0f;
    for (int b = 0; b < kSubbands; ++b)
    {
        float snr = signalEstimate_[b] / std::max (noiseEstimate_[b], 1e-10f);
        float threshold = 1.0f + amount_ * 3.0f;

        float gain;
        if (snr < threshold)
            gain = std::sqrt (snr / threshold);
        else
            gain = 1.0f;

        gain = std::clamp (gain, 0.05f, 1.0f);
        bandGains_[b] = 0.9f * bandGains_[b] + 0.1f * gain;

        overallGain += bandGains_[b];
        totalWeight += 1.0f;
    }

    if (totalWeight > 0.0f)
        overallGain /= totalWeight;

    // Apply simplified per-subband gain via time-domain envelope
    for (int i = 0; i < frameSize; ++i)
        frame[i] *= overallGain;

    frameCount_++;
}

void SpeexDSPEngine::computeSubbandEnergies (const float* frame, int frameSize, float* energies)
{
    // Divide frame into kSubbands equal sections and compute energy
    int samplesPerBand = frameSize / kSubbands;
    for (int b = 0; b < kSubbands; ++b)
    {
        float e = 0.0f;
        int start = b * samplesPerBand;
        for (int i = 0; i < samplesPerBand; ++i)
            e += frame[start + i] * frame[start + i];
        energies[b] = e / static_cast<float> (samplesPerBand);
    }
}

void SpeexDSPEngine::setAmount (float amount)
{
    amount_ = std::clamp (amount, 0.0f, 1.0f);
}

void SpeexDSPEngine::reset()
{
    std::fill (noiseEstimate_, noiseEstimate_ + kSubbands, 0.0f);
    std::fill (signalEstimate_, signalEstimate_ + kSubbands, 0.0f);
    std::fill (bandGains_, bandGains_ + kSubbands, 1.0f);
    frameCount_ = 0;
    initialized_ = true;
}

} // namespace DeFeedback