/*
  DeFeedback V2.1 - RNNoise Engine Implementation
  RNN-inspired noise suppression with band-based processing
*/
#include "RNNoiseEngine.h"
#include <cmath>
#include <cstring>
#include <algorithm>

namespace DeFeedback
{

void RNNoiseEngine::prepare (double sampleRate, int blockSize)
{
    sampleRate_ = sampleRate;
    blockSize_  = blockSize;
    reset();
}

void RNNoiseEngine::process (float* samples, int numSamples)
{
    if (!initialized_)
    {
        std::fill (bandGains_, bandGains_ + kBands, 1.0f);
        initialized_ = true;
    }

    // Process frame-by-frame
    int pos = 0;
    while (pos + kFrameSize <= numSamples)
    {
        processFrame (samples + pos);
        pos += kFrameSize;
    }
}

void RNNoiseEngine::processFrame (float* frame)
{
    float sigE[kBands], noiseE[kBands], gains[kBands];

    computeBandEnergies (frame, sigE);

    // Update noise estimate (minimum statistics with backoff)
    for (int b = 0; b < kBands; ++b)
    {
        if (frameCount_ < 8)
        {
            // Initial noise estimate from first frames
            noiseEstimate_[b] = noiseEstimate_[b] * 0.5f + sigE[b] * 0.5f;
        }
        else
        {
            float candidate = noiseEstimate_[b] * alpha_ + sigE[b] * (1.0f - alpha_);
            // Noise estimate follows signal only downward
            if (candidate < noiseEstimate_[b])
                noiseEstimate_[b] = candidate;
            else
                noiseEstimate_[b] *= (1.0f + 0.0001f); // slow backoff
        }
    }

    computeGains (sigE, noiseEstimate_, gains);

    // Apply band gains (simplified: apply as time-domain envelope)
    // Compute overall gain from weighted band gains
    float totalSig = 0.0f, totalNoise = 0.0f;
    for (int b = 0; b < kBands; ++b)
    {
        totalSig += sigE[b];
        totalNoise += noiseEstimate_[b];
    }

    float overallGain = 1.0f;
    if (totalNoise > 1e-10f)
    {
        float snr = totalSig / totalNoise;
        // Wiener-like gain
        overallGain = std::max (snr - amount_ * 2.0f, 0.01f) / std::max (snr, 0.01f);
        overallGain = std::sqrt (overallGain);
        overallGain = std::clamp (overallGain, 0.05f, 1.0f);
    }

    // Smooth gain transitions
    float prevGain = bandGains_[0];
    float smoothGain = 0.95f * prevGain + 0.05f * overallGain;
    bandGains_[0] = smoothGain;

    for (int i = 0; i < kFrameSize; ++i)
        frame[i] *= smoothGain;

    frameCount_++;
}

void RNNoiseEngine::computeBandEnergies (const float* frame, float* energies)
{
    // Approximate Bark-band energies using Goertzel on band centers
    float bandEdges[kBands + 1];
    // Bark scale approximation
    for (int b = 0; b <= kBands; ++b)
    {
        float bark = b * 24.0f / kBands;
        bandEdges[b] = 1960.0f * (bark + 0.53f) / (26.28f - bark);
        bandEdges[b] = std::min (bandEdges[b], static_cast<float> (sampleRate_) * 0.48f);
    }

    for (int b = 0; b < kBands; ++b)
    {
        float centerFreq = (bandEdges[b] + bandEdges[b + 1]) * 0.5f;
        float energy = 0.0f;

        // Goertzel at center frequency
        float k = centerFreq * static_cast<float> (kFrameSize) / static_cast<float> (sampleRate_);
        float w = 2.0f * 3.14159265358979323846f * k / static_cast<float> (kFrameSize);
        float coeff = 2.0f * std::cos (w);
        float s0 = 0.0f, s1 = 0.0f, s2 = 0.0f;
        for (int i = 0; i < kFrameSize; ++i)
        {
            s0 = frame[i] + coeff * s1 - s2;
            s2 = s1;
            s1 = s0;
        }
        energy = s1 * s1 + s2 * s2 - coeff * s1 * s2;
        energies[b] = std::max (energy, 1e-10f);
    }
}

void RNNoiseEngine::computeGains (const float* signal, const float* noise, float* gains)
{
    for (int b = 0; b < kBands; ++b)
    {
        float snr = signal[b] / std::max (noise[b], 1e-10f);
        // Wiener gain with amount-controlled aggressiveness
        float threshold = 1.0f + amount_ * 4.0f;
        if (snr < threshold)
            gains[b] = std::sqrt (snr / threshold);
        else
            gains[b] = 1.0f;
        gains[b] = std::clamp (gains[b], 0.05f, 1.0f);
    }
}

void RNNoiseEngine::setAmount (float amount)
{
    amount_ = std::clamp (amount, 0.0f, 1.0f);
}

void RNNoiseEngine::reset()
{
    std::fill (bandGains_, bandGains_ + kBands, 1.0f);
    std::fill (noiseEstimate_, noiseEstimate_ + kBands, 0.0f);
    std::fill (signalEstimate_, signalEstimate_ + kBands, 0.0f);
    frameCount_ = 0;
    initialized_ = true;
}

} // namespace DeFeedback