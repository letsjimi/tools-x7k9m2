/*
  DeFeedback V2.1 - Parameter IDs and Constants
  Production VST3 Audio Plugin for Live-Vocal Feedback Suppression
*/
#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

namespace DeFeedback
{
    // Operation modes
    enum class Mode
    {
        Ultra = 0,
        Balanced = 1,
        Quality = 2
    };

    // Noise-reduction engine types
    enum class EngineType
    {
        WebRTC = 0,
        RNNoise = 1,
        DeepFilterNet = 2,
        SpeexDSP = 3
    };

    // Parameter IDs
    namespace ParamIDs
    {
        static const juce::String mode           { "mode" };
        static const juce::String strength        { "strength" };
        static const juce::String maxNotches      { "maxNotches" };
        static const juce::String notchQ          { "notchQ" };
        static const juce::String release          { "release" };
        static const juce::String sensitivity     { "sensitivity" };
        static const juce::String noiseEngine      { "noiseEngine" };
        static const juce::String noiseAmount      { "noiseAmount" };
        static const juce::String dereverbAmount   { "dereverbAmount" };
        static const juce::String outputTrim       { "outputTrim" };
    }

    // Mode presets (thresholds, timing)
    struct ModeConfig
    {
        float feedbackThreshold;    // dB above reference to trigger
        float notchQDefault;
        int   maxNotchesDefault;
        float releaseDefault;       // seconds
        float sensitivityDefault;   // 0-1
        float goertzelBinWidth;      // Hz
        int   detectionHoldFrames;
        float notchAttackCoeff;
    };

    inline ModeConfig getModeConfig (Mode m)
    {
        switch (m)
        {
            case Mode::Ultra:
                return { 3.0f, 30.0f, 12, 0.8f, 0.75f, 15.0f, 2, 0.92f };
            case Mode::Balanced:
                return { 6.0f, 22.0f, 8,  1.5f, 0.60f, 20.0f, 4, 0.88f };
            case Mode::Quality:
                return { 9.0f, 15.0f, 6,  2.5f, 0.45f, 30.0f, 6, 0.82f };
        }
        return getModeConfig (Mode::Balanced);
    }

    // FFT / Goertzel frequency range for feedback detection
    constexpr float minFeedbackHz   = 80.0f;
    constexpr float maxFeedbackHz   = 8000.0f;
    constexpr int   defaultFFTSize  = 2048;

    // Latency target
    constexpr float targetLatencyMs = 4.0f;
}