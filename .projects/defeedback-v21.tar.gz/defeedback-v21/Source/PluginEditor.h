/*
  DeFeedback V2.1 - Plugin Editor Forward Declaration
*/
#pragma once

// This file exists so PluginProcessor.h can forward-declare the editor
// without including the full header (which would create circular deps)

namespace DeFeedback
{
class DeFeedbackEditor;
}