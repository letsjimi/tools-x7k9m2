/*
  DeFeedback V2.1 - Plugin Processor Implementation
*/
#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>

//==============================================================================
DeFeedbackV2Processor::DeFeedbackV2Processor()
    : AudioProcessor (BusesProperties()
        .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
        .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      vts (*this, nullptr, juce::Identifier ("DeFeedbackV2"),
           createParameterLayout())
{
}

juce::AudioProcessorValueTreeState::ParameterLayout
DeFeedbackV2Processor::createParameterLayout()
{
    using namespace DeFeedback::ParamIDs;
    using Float = juce::AudioProcessorValueTreeState::Parameter;
    using Choice = juce::AudioProcessorValueTreeState::Parameter;

    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // Mode: Ultra / Balanced / Quality
    params.push_back (std::make_unique<juce::AudioParameterChoice>
        (mode, "Mode", juce::StringArray { "Ultra", "Balanced", "Quality" }, 1));

    // Strength 0-1
    params.push_back (std::make_unique<juce::AudioParameterFloat>
        (strength, "Strength", juce::NormalisableRange<float> (0.0f, 1.0f, 0.01f), 0.7f));

    // Max Notches 1-16
    params.push_back (std::make_unique<juce::AudioParameterInt>
        (maxNotches, "Max Notches", 1, 16, 8));

    // Notch Q 1-100
    params.push_back (std::make_unique<juce::AudioParameterFloat>
        (notchQ, "Notch Q", juce::NormalisableRange<float> (1.0f, 100.0f, 0.1f), 22.0f));

    // Release 0.1-10s
    params.push_back (std::make_unique<juce::AudioParameterFloat>
        (release, "Release", juce::NormalisableRange<float> (0.1f, 10.0f, 0.01f), 1.5f));

    // Sensitivity 0-1
    params.push_back (std::make_unique<juce::AudioParameterFloat>
        (sensitivity, "Sensitivity", juce::NormalisableRange<float> (0.0f, 1.0f, 0.01f), 0.6f));

    // Noise Engine dropdown
    params.push_back (std::make_unique<juce::AudioParameterChoice>
        (noiseEngine, "Noise Engine",
         juce::StringArray { "WebRTC", "RNNoise", "DeepFilterNet", "SpeexDSP" }, 0));

    // Noise Amount 0-1
    params.push_back (std::make_unique<juce::AudioParameterFloat>
        (noiseAmount, "Noise Amount", juce::NormalisableRange<float> (0.0f, 1.0f, 0.01f), 0.5f));

    // Dereverb Amount 0-1
    params.push_back (std::make_unique<juce::AudioParameterFloat>
        (dereverbAmount, "Dereverb Amount", juce::NormalisableRange<float> (0.0f, 1.0f, 0.01f), 0.0f));

    // Output Trim -12 to +12 dB
    params.push_back (std::make_unique<juce::AudioParameterFloat>
        (outputTrim, "Output Trim", juce::NormalisableRange<float> (-12.0f, 12.0f, 0.1f), 0.0f));

    return { params.begin(), params.end() };
}

//==============================================================================
void DeFeedbackV2Processor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    int numChannels = std::max (getTotalNumInputChannels(), getTotalNumOutputChannels());

    feedbackSuppressor_.prepare (sampleRate, samplesPerBlock, numChannels);
    dereverbProcessor_.prepare (sampleRate, samplesPerBlock, numChannels);
    denoiseProcessor_.prepare (sampleRate, samplesPerBlock);

    updateParameters();
}

void DeFeedbackV2Processor::releaseResources()
{
}

void DeFeedbackV2Processor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    // Update parameters each block (lightweight)
    updateParameters();

    int numChannels = buffer.getNumChannels();
    int numSamples  = buffer.getNumSamples();

    if (numChannels == 0 || numSamples == 0)
        return;

    // Get raw channel pointers
    std::vector<float*> channelPtrs (numChannels);
    for (int ch = 0; ch < numChannels; ++ch)
        channelPtrs[ch] = buffer.getWritePointer (ch);

    // --- 1. Feedback Suppression (core, 0 latency) ---
    feedbackSuppressor_.processBlock (channelPtrs.data(), numChannels, numSamples);

    // --- 2. De-Reverb ---
    dereverbProcessor_.processBlock (channelPtrs.data(), numChannels, numSamples);

    // --- 3. De-Noise ---
    denoiseProcessor_.processBlock (channelPtrs.data(), numChannels, numSamples);

    // --- 4. Output Trim ---
    float trimDb = vts.getRawParameterValue (DeFeedback::ParamIDs::outputTrim)->load();
    if (std::abs (trimDb) > 0.05f)
    {
        float gainLin = std::pow (10.0f, trimDb / 20.0f);
        for (int ch = 0; ch < numChannels; ++ch)
            juce::FloatVectorOperations::multiply (channelPtrs[ch], gainLin, numSamples);
    }
}

//==============================================================================
void DeFeedbackV2Processor::updateParameters()
{
    using namespace DeFeedback;

    // Mode
    int modeIdx = static_cast<int> (*vts.getRawParameterValue (ParamIDs::mode));
    auto mode = static_cast<Mode> (modeIdx);
    feedbackSuppressor_.setMode (mode);
    dereverbProcessor_.setMode (mode);

    // Strength
    feedbackSuppressor_.setStrength (vts.getRawParameterValue (ParamIDs::strength)->load());

    // Max Notches
    feedbackSuppressor_.setMaxNotches (static_cast<int> (*vts.getRawParameterValue (ParamIDs::maxNotches)));

    // Notch Q
    feedbackSuppressor_.setNotchQ (vts.getRawParameterValue (ParamIDs::notchQ)->load());

    // Release
    feedbackSuppressor_.setRelease (vts.getRawParameterValue (ParamIDs::release)->load());

    // Sensitivity
    feedbackSuppressor_.setSensitivity (vts.getRawParameterValue (ParamIDs::sensitivity)->load());

    // Noise Engine
    int engineIdx = static_cast<int> (*vts.getRawParameterValue (ParamIDs::noiseEngine));
    auto engineType = static_cast<EngineType> (engineIdx);
    if (denoiseProcessor_.getCurrentEngineType() != engineType)
        denoiseProcessor_.setEngine (engineType);

    // Noise Amount
    denoiseProcessor_.setAmount (vts.getRawParameterValue (ParamIDs::noiseAmount)->load());

    // Dereverb Amount
    dereverbProcessor_.setAmount (vts.getRawParameterValue (ParamIDs::dereverbAmount)->load());
}

//==============================================================================
juce::AudioProcessorEditor* DeFeedbackV2Processor::createEditor()
{
    return new DeFeedback::DeFeedbackEditor (*this);
}

void DeFeedbackV2Processor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = vts.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);
}

void DeFeedbackV2Processor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState (getXmlFromBinary (data, sizeInBytes));
    if (xmlState)
    {
        auto state = juce::ValueTree::fromXml (*xmlState);
        if (state.isValid())
            vts.replaceState (state);
    }
}

//==============================================================================
int DeFeedbackV2Processor::getActiveNotchCount() const
{
    return feedbackSuppressor_.getActiveNotchCount();
}

std::vector<float> DeFeedbackV2Processor::getActiveNotchFrequencies() const
{
    return feedbackSuppressor_.getActiveNotchFrequencies();
}

DeFeedback::EngineType DeFeedbackV2Processor::getCurrentEngineType() const
{
    return denoiseProcessor_.getCurrentEngineType();
}

const char* DeFeedbackV2Processor::getCurrentEngineName() const
{
    return denoiseProcessor_.getEngineName();
}

//==============================================================================
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new DeFeedbackV2Processor();
}