/*
  DeFeedback V2.1 - Goertzel Feedback Detector
  Zero-latency per-bin magnitude detection for feedback frequencies
*/
#pragma once

#include <vector>
#include <array>
#include <cstddef>
#include "DeFeedbackConstants.h"

namespace DeFeedback
{

class GoertzelDetector
{
public:
    GoertzelDetector() = default;

    void prepare (double sampleRate, int blockSize);
    void setMode (Mode mode);
    void setSensitivity (float s);  // 0..1
    void setThreshold (float thresholdDb);

    // Process a mono block, returns detected feedback frequencies (Hz)
    struct DetectedTone
    {
        float frequency;
        float magnitudeDb;
        int   holdCount;       // frames the tone has been held
    };

    const std::vector<DetectedTone>& detect (const float* samples, int numSamples);

    void reset();

    int getMaxNotches() const noexcept { return maxNotches; }
    void setMaxNotches (int n) { maxNotches = std::min (n, 16); }

private:
    void computeGoertzelBins();
    float goertzelMag (const float* samples, int numSamples, float targetFreq) const;

    double sampleRate_  = 48000.0;
    int    blockSize_   = 480;
    Mode   mode_        = Mode::Balanced;
    float  sensitivity_ = 0.6f;
    float  thresholdDb_ = 6.0f;
    int    maxNotches   = 8;

    // Goertzel coefficients per candidate bin
    struct BinCoeffs
    {
        float coeff;          // 2 * cos(2πk/N)
        float freqHz;
    };
    std::vector<BinCoeffs> bins_;

    // Detection state
    std::vector<DetectedTone> currentDetections_;
    std::vector<DetectedTone> pendingDetections_;

    // Energy reference for adaptive threshold
    float runningAvgEnergy_ = 1e-10f;
    float alphaEnergy_      = 0.001f;

    // Hold counter for stability (avoid transients)
    int holdRequired_ = 4;
};

} // namespace DeFeedback