/*
  DeFeedback V2.1 - Dereverb Processor
  Removes room reverberation from live vocals
  Uses late-reverb estimation + spectral subtraction
*/
#pragma once

#include <vector>
#include "DeFeedbackConstants.h"

namespace DeFeedback
{

class DereverbProcessor
{
public:
    DereverbProcessor() = default;

    void prepare (double sampleRate, int blockSize, int numChannels);
    void setAmount (float amount);   // 0..1
    void setMode (Mode mode);

    void processBlock (float** channelData, int numChannels, int numSamples);
    void reset();

private:
    // Late-echo estimation via delayed envelope comparison
    // Reverb tail estimation
    static constexpr int kReverbDelayMs = 50;  // estimated early reflections gap
    int    reverbDelaySamples_ = 0;
    float  amount_   = 0.0f;
    Mode   mode_     = Mode::Balanced;
    double sampleRate_ = 48000.0;
    int    blockSize_  = 480;
    int    numChannels_ = 2;

    // Circular delay buffer for reverb estimation
    std::vector<std::vector<float>> delayBuffers_;
    int delayWritePos_ = 0;

    // Envelope followers
    float envelopeFast_  = 0.0f;
    float envelopeSlow_  = 0.0f;
    float alphaFast_      = 0.0f;
    float alphaSlow_      = 0.0f;

    // Spectral gain
    float currentGain_ = 1.0f;
    float alphaGain_   = 0.995f;  // very smooth transitions

    // Energy-based reverb detection
    float directEnergy_ = 0.0f;
    float reverbEnergy_ = 0.0f;
    float reverbRatio_  = 0.0f;
};

} // namespace DeFeedback