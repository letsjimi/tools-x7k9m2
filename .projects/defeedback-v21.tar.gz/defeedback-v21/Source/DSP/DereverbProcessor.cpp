/*
  DeFeedback V2.1 - Dereverb Processor Implementation
*/
#include "DereverbProcessor.h"
#include <cmath>
#include <algorithm>

namespace DeFeedback
{

void DereverbProcessor::prepare (double sampleRate, int blockSize, int numChannels)
{
    sampleRate_   = sampleRate;
    blockSize_    = blockSize;
    numChannels_  = numChannels;
    reverbDelaySamples_ = static_cast<int> (sampleRate * kReverbDelayMs / 1000.0);

    delayBuffers_.resize (numChannels);
    for (auto& buf : delayBuffers_)
        buf.resize (reverbDelaySamples_ + blockSize + 1, 0.0f);

    alphaFast_ = 1.0f - std::exp (-1.0f / (0.005f * static_cast<float> (sampleRate)));
    alphaSlow_ = 1.0f - std::exp (-1.0f / (0.050f * static_cast<float> (sampleRate)));

    reset();
}

void DereverbProcessor::setAmount (float amount)
{
    amount_ = std::clamp (amount, 0.0f, 1.0f);
}

void DereverbProcessor::setMode (Mode mode)
{
    mode_ = mode;
    switch (mode)
    {
        case Mode::Ultra:    alphaGain_ = 0.99f;  break;
        case Mode::Balanced: alphaGain_ = 0.995f; break;
        case Mode::Quality:  alphaGain_ = 0.998f; break;
    }
}

void DereverbProcessor::processBlock (float** channelData, int numChannels, int numSamples)
{
    if (amount_ < 0.01f)
        return;

    int delayBufSize = static_cast<int> (delayBuffers_[0].size());

    for (int ch = 0; ch < numChannels; ++ch)
    {
        for (int i = 0; i < numSamples; ++i)
        {
            float input = channelData[ch][i];
            float absInput = std::abs (input);

            // Fast envelope (direct signal tracker)
            envelopeFast_ += alphaFast_ * (absInput - envelopeFast_);

            // Read delayed signal for reverb estimation
            int readPos = (delayWritePos_ - reverbDelaySamples_ + delayBufSize) % delayBufSize;
            float delayed = delayBuffers_[ch][readPos];
            float absDelayed = std::abs (delayed);

            // Slow envelope (reverb tail tracker)
            envelopeSlow_ += alphaSlow_ * (absDelayed - envelopeSlow_);

            // Write current sample into delay buffer
            delayBuffers_[ch][delayWritePos_ % delayBufSize] = input;

            // Estimate reverb ratio
            directEnergy_ = envelopeFast_ * envelopeFast_;
            reverbEnergy_ = envelopeSlow_ * envelopeSlow_;
            reverbRatio_ = (directEnergy_ > 1e-10f) ? reverbEnergy_ / directEnergy_ : 0.0f;

            // Compute suppression gain
            float targetGain = 1.0f;
            float reverbThreshold = 0.1f;
            if (reverbRatio_ > reverbThreshold)
            {
                float excess = (reverbRatio_ - reverbThreshold) / (1.0f - reverbThreshold);
                float suppression = amount_ * excess * 0.8f;
                targetGain = 1.0f - suppression;
                targetGain = std::max (targetGain, 0.2f);
            }

            currentGain_ = alphaGain_ * currentGain_ + (1.0f - alphaGain_) * targetGain;

            // Apply: attenuate reverb tail when direct signal is low
            float directPresence = std::min (absInput / std::max (envelopeFast_, 1e-10f), 1.0f);
            float reverbGain = 1.0f - (1.0f - currentGain_) * (1.0f - directPresence);

            channelData[ch][i] = input * reverbGain;
        }
    }

    delayWritePos_ = (delayWritePos_ + numSamples) % delayBufSize;
}

void DereverbProcessor::reset()
{
    for (auto& buf : delayBuffers_)
        std::fill (buf.begin(), buf.end(), 0.0f);
    delayWritePos_ = 0;
    envelopeFast_ = 0.0f;
    envelopeSlow_ = 0.0f;
    currentGain_ = 1.0f;
    directEnergy_ = 0.0f;
    reverbEnergy_ = 0.0f;
    reverbRatio_ = 0.0f;
}

} // namespace DeFeedback