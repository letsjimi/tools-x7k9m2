/*
  DeFeedback V2.1 - Denoise Processor
  Delegates to the selected noise-reduction engine
*/
#pragma once

#include <memory>
#include "Engines/NoiseEngine.h"
#include "Engines/EngineFactory.h"
#include "DeFeedbackConstants.h"

namespace DeFeedback
{

class DenoiseProcessor
{
public:
    DenoiseProcessor() = default;

    void prepare (double sampleRate, int blockSize);
    void setEngine (EngineType type);
    void setAmount (float amount);   // 0..1

    // Process in-place on interleaved or per-channel buffers
    // We process mono (first channel) and apply gain to all
    void processBlock (float** channelData, int numChannels, int numSamples);
    void reset();

    EngineType getCurrentEngineType() const noexcept { return currentType_; }
    const char* getEngineName() const;

private:
    void switchEngine (EngineType type);

    std::unique_ptr<NoiseEngine> engine_;
    EngineType currentType_ = EngineType::WebRTC;
    double sampleRate_ = 48000.0;
    int    blockSize_  = 480;
    float  amount_     = 0.5f;
    bool   prepared_   = false;

    // Mono buffer for engine processing
    std::vector<float> monoBuffer_;
};

} // namespace DeFeedback