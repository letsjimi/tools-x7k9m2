/*
  DeFeedback V2.1 - Adaptive Notch Filter
  2nd-order IIR band-reject filter with configurable Q
*/
#pragma once

#include <cmath>
#include "DeFeedbackConstants.h"

namespace DeFeedback
{

class AdaptiveNotchFilter
{
public:
    AdaptiveNotchFilter() = default;

    void setFrequency (float freqHz);
    void setQ (float q);
    void prepare (double sampleRate);
    float processSample (float input);
    void reset();

    float getFrequency() const noexcept { return freqHz_; }
    bool  isActive()    const noexcept { return active_; }
    void  setActive (bool a) { active_ = a; }

    // Release ramp
    void startRelease (float releaseTimeSeconds);
    bool isReleasing() const noexcept { return releasing_; }
    bool isExpired()  const noexcept { return gain_ < 0.001f; }
    void advanceRelease (int numSamples);

private:
    void updateCoefficients();

    double sampleRate_ = 48000.0;
    float  freqHz_     = 1000.0f;
    float  q_          = 22.0f;
    bool   active_     = false;
    bool   releasing_  = false;

    // IIR coefficients (direct form II transposed)
    float b0_ = 1.0f, b1_ = 0.0f, b2_ = 1.0f;
    float a1_ = 0.0f, a2_ = 0.0f;

    // State
    float w1_ = 0.0f, w2_ = 0.0f;

    // Gain ramp for release
    float gain_            = 1.0f;
    float releaseCoeff_    = 0.0f;
    float releaseTarget_    = 0.999f;
};

} // namespace DeFeedback