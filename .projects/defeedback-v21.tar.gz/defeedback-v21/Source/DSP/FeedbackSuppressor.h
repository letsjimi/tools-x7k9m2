/*
  DeFeedback V2.1 - Feedback Suppressor
  Orchestrates Goertzel detection + adaptive notch filterbank + release
*/
#pragma once

#include <vector>
#include "GoertzelDetector.h"
#include "AdaptiveNotchFilter.h"
#include "DeFeedbackConstants.h"

namespace DeFeedback
{

class FeedbackSuppressor
{
public:
    FeedbackSuppressor() = default;

    void prepare (double sampleRate, int blockSize, int numChannels);
    void setMode (Mode mode);
    void setStrength (float strength);
    void setMaxNotches (int n);
    void setNotchQ (float q);
    void setRelease (float seconds);
    void setSensitivity (float s);

    void processBlock (float** channelData, int numChannels, int numSamples);
    void reset();

    int getActiveNotchCount() const;
    const std::vector<float> getActiveNotchFrequencies() const;

private:
    void updateNotches (const std::vector<GoertzelDetector::DetectedTone>& detections);
    void manageRelease (int numSamples);

    GoertzelDetector detector_;
    std::vector<AdaptiveNotchFilter> notches_;

    double sampleRate_  = 48000.0;
    int    blockSize_   = 480;
    int    numChannels_ = 2;
    Mode   mode_        = Mode::Balanced;
    float  strength_   = 0.7f;
    float  notchQ_     = 22.0f;
    float  releaseTime_ = 1.5f;
    int    maxNotches_  = 8;

    std::vector<float> monoBuffer_;
};

} // namespace DeFeedback