/*
  DeFeedback V2.1 - Denoise Processor Implementation
*/
#include "DenoiseProcessor.h"
#include <algorithm>

namespace DeFeedback
{

void DenoiseProcessor::prepare (double sampleRate, int blockSize)
{
    sampleRate_ = sampleRate;
    blockSize_  = blockSize;
    prepared_   = true;

    if (engine_)
        engine_->prepare (sampleRate, blockSize);

    monoBuffer_.resize (blockSize, 0.0f);
}

void DenoiseProcessor::setEngine (EngineType type)
{
    currentType_ = type;
    switchEngine (type);
}

void DenoiseProcessor::switchEngine (EngineType type)
{
    auto newEngine = EngineFactory::createWithFallback (type);
    if (newEngine)
    {
        engine_ = std::move (newEngine);
        if (prepared_)
            engine_->prepare (sampleRate_, blockSize_);
        engine_->setAmount (amount_);
    }
}

void DenoiseProcessor::setAmount (float amount)
{
    amount_ = std::clamp (amount, 0.0f, 1.0f);
    if (engine_)
        engine_->setAmount (amount_);
}

void DenoiseProcessor::processBlock (float** channelData, int numChannels, int numSamples)
{
    if (!engine_ || amount_ < 0.01f)
        return;

    // Process each channel through the noise engine
    for (int ch = 0; ch < numChannels; ++ch)
    {
        // Copy to mono buffer for processing
        monoBuffer_.resize (numSamples);
        std::copy (channelData[ch], channelData[ch] + numSamples, monoBuffer_.data());

        engine_->process (monoBuffer_.data(), numSamples);

        // Apply processed result
        std::copy (monoBuffer_.data(), monoBuffer_.data() + numSamples, channelData[ch]);
    }
}

void DenoiseProcessor::reset()
{
    if (engine_)
        engine_->reset();
    std::fill (monoBuffer_.begin(), monoBuffer_.end(), 0.0f);
}

const char* DenoiseProcessor::getEngineName() const
{
    if (engine_)
        return engine_->getName();
    return "None";
}

} // namespace DeFeedback