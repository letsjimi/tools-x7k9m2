/*
  DeFeedback V2.1 - Adaptive Notch Filter Implementation
*/
#include "AdaptiveNotchFilter.h"
#include <cmath>

namespace DeFeedback
{

void AdaptiveNotchFilter::prepare (double sampleRate)
{
    sampleRate_ = sampleRate;
    reset();
    updateCoefficients();
}

void AdaptiveNotchFilter::setFrequency (float freqHz)
{
    freqHz_ = std::clamp (freqHz, 20.0f, static_cast<float> (sampleRate_) * 0.48f);
    updateCoefficients();
}

void AdaptiveNotchFilter::setQ (float q)
{
    q_ = std::clamp (q, 1.0f, 100.0f);
    updateCoefficients();
}

void AdaptiveNotchFilter::updateCoefficients()
{
    // 2nd-order notch: H(z) = (1 - 2cos(w0)z^-1 + z^-2) / (1 - 2rcos(w0)z^-1 + r^2 z^-2)
    // r = 1 - bandwidth/(2*Q*sampleRate) approximation, but we use standard notch design
    float w0 = 2.0f * 3.14159265358979323846f * freqHz_ / static_cast<float> (sampleRate_);
    float cosW0 = std::cos (w0);
    float sinW0 = std::sin (w0);
    float alpha  = sinW0 / (2.0f * q_);

    float b0_coeff = 1.0f;
    float b1_coeff = -2.0f * cosW0;
    float b2_coeff = 1.0f;
    float a0_coeff = 1.0f + alpha;
    float a1_coeff = -2.0f * cosW0;
    float a2_coeff = 1.0f - alpha;

    // Normalize by a0
    b0_ = b0_coeff / a0_coeff;
    b1_ = b1_coeff / a0_coeff;
    b2_ = b2_coeff / a0_coeff;
    a1_ = a1_coeff / a0_coeff;
    a2_ = a2_coeff / a0_coeff;
}

float AdaptiveNotchFilter::processSample (float input)
{
    if (!active_ && !releasing_)
        return input;

    float effectiveGain = gain_;
    float dry = input;
    float w0 = input - a1_ * w1_ - a2_ * w2_;
    float wet = b0_ * w0 + b1_ * w1_ + b2_ * w2_;
    w2_ = w1_;
    w1_ = w0;

    // Crossfade: gain_=1 means full notch, gain_=0 means bypass
    return dry * (1.0f - effectiveGain) + wet * effectiveGain;
}

void AdaptiveNotchFilter::reset()
{
    w1_ = 0.0f;
    w2_ = 0.0f;
    gain_ = 1.0f;
    releasing_ = false;
}

void AdaptiveNotchFilter::startRelease (float releaseTimeSeconds)
{
    if (releaseTimeSeconds <= 0.0f)
    {
        gain_ = 0.0f;
        releasing_ = false;
        active_ = false;
        return;
    }

    releasing_ = true;
    // Calculate exponential decay coefficient
    // time constant: gain decays to ~0.001 over releaseTime
    float samplesToDecay = releaseTimeSeconds * static_cast<float> (sampleRate_);
    releaseCoeff_ = std::pow (0.001f, 1.0f / samplesToDecay);
}

void AdaptiveNotchFilter::advanceRelease (int numSamples)
{
    if (!releasing_)
        return;

    for (int i = 0; i < numSamples; ++i)
        gain_ *= releaseCoeff_;

    if (gain_ < 0.001f)
    {
        gain_ = 0.0f;
        releasing_ = false;
        active_ = false;
        w1_ = 0.0f;
        w2_ = 0.0f;
    }
}

} // namespace DeFeedback