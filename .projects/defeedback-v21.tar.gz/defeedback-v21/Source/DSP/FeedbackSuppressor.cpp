/*
  DeFeedback V2.1 - Feedback Suppressor Implementation
*/
#include "FeedbackSuppressor.h"
#include <algorithm>
#include <cmath>

namespace DeFeedback
{

void FeedbackSuppressor::prepare (double sampleRate, int blockSize, int numChannels)
{
    sampleRate_  = sampleRate;
    blockSize_   = blockSize;
    numChannels_ = numChannels;

    detector_.prepare (sampleRate, blockSize);
    detector_.setMode (mode_);
    detector_.setMaxNotches (maxNotches_);

    notches_.resize (16);
    for (auto& n : notches_)
        n.prepare (sampleRate);

    monoBuffer_.resize (blockSize, 0.0f);
    reset();
}

void FeedbackSuppressor::setMode (Mode mode)
{
    mode_ = mode;
    auto cfg = getModeConfig (mode);
    detector_.setMode (mode);
    notchQ_      = cfg.notchQDefault;
    releaseTime_  = cfg.releaseDefault;
    maxNotches_  = cfg.maxNotchesDefault;
    detector_.setMaxNotches (maxNotches_);
    for (auto& n : notches_)
        n.setQ (notchQ_);
}

void FeedbackSuppressor::setStrength (float strength)
{
    strength_ = std::clamp (strength, 0.0f, 1.0f);
    float effectiveQ = notchQ_ * (0.5f + strength_ * 1.5f);
    for (auto& n : notches_)
        n.setQ (effectiveQ);
}

void FeedbackSuppressor::setMaxNotches (int n)
{
    maxNotches_ = std::clamp (n, 1, 16);
    detector_.setMaxNotches (maxNotches_);
}

void FeedbackSuppressor::setNotchQ (float q)
{
    notchQ_ = std::clamp (q, 1.0f, 100.0f);
    for (auto& n : notches_)
        n.setQ (notchQ_);
}

void FeedbackSuppressor::setRelease (float seconds)
{
    releaseTime_ = std::max (seconds, 0.1f);
}

void FeedbackSuppressor::setSensitivity (float s)
{
    detector_.setSensitivity (s);
}

void FeedbackSuppressor::processBlock (float** channelData, int numChannels, int numSamples)
{
    // Mono downmix for analysis
    monoBuffer_.resize (numSamples, 0.0f);
    std::fill (monoBuffer_.begin(), monoBuffer_.end(), 0.0f);
    for (int ch = 0; ch < numChannels; ++ch)
        for (int i = 0; i < numSamples; ++i)
            monoBuffer_[i] += channelData[ch][i];
    float invCh = 1.0f / static_cast<float> (numChannels);
    for (int i = 0; i < numSamples; ++i)
        monoBuffer_[i] *= invCh;

    // Detect feedback frequencies (returns cached result)
    const auto& detections = detector_.detect (monoBuffer_.data(), numSamples);

    // Update notch filters
    updateNotches (detections);

    // Apply notch filters to all channels
    for (int ch = 0; ch < numChannels; ++ch)
    {
        for (auto& notch : notches_)
        {
            if (!notch.isActive() && !notch.isReleasing())
                continue;
            for (int i = 0; i < numSamples; ++i)
                channelData[ch][i] = notch.processSample (channelData[ch][i]);
        }
    }

    // Release management
    manageRelease (numSamples);
}

void FeedbackSuppressor::updateNotches (const std::vector<GoertzelDetector::DetectedTone>& detections)
{
    auto cfg = getModeConfig (mode_);
    float minFreqDist = cfg.goertzelBinWidth * 0.5f;

    std::vector<bool> detectionMatched (detections.size(), false);
    std::vector<bool> notchMatched (notches_.size(), false);

    // Match existing notches to current detections
    for (size_t d = 0; d < detections.size(); ++d)
    {
        for (size_t n = 0; n < notches_.size(); ++n)
        {
            if (!notches_[n].isActive() && !notches_[n].isReleasing())
                continue;
            if (std::abs (notches_[n].getFrequency() - detections[d].frequency) < minFreqDist)
            {
                notchMatched[n] = true;
                detectionMatched[d] = true;
                break;
            }
        }
    }

    // Release unmatched active notches
    for (size_t n = 0; n < notches_.size(); ++n)
    {
        if (notches_[n].isActive() && !notchMatched[n] && !notches_[n].isReleasing())
            notches_[n].startRelease (releaseTime_);
    }

    // Create new notches for unmatched detections
    for (size_t d = 0; d < detections.size(); ++d)
    {
        if (detectionMatched[d])
            continue;
        for (auto& notch : notches_)
        {
            if (!notch.isActive() && !notch.isReleasing())
            {
                notch.setFrequency (detections[d].frequency);
                notch.setQ (notchQ_);
                notch.setActive (true);
                notch.reset();
                break;
            }
        }
    }
}

void FeedbackSuppressor::manageRelease (int numSamples)
{
    for (auto& notch : notches_)
    {
        if (notch.isReleasing())
            notch.advanceRelease (numSamples);
    }
}

void FeedbackSuppressor::reset()
{
    for (auto& n : notches_)
    {
        n.setActive (false);
        n.reset();
    }
    detector_.reset();
}

int FeedbackSuppressor::getActiveNotchCount() const
{
    int count = 0;
    for (const auto& n : notches_)
        if (n.isActive() || n.isReleasing())
            ++count;
    return count;
}

const std::vector<float> FeedbackSuppressor::getActiveNotchFrequencies() const
{
    std::vector<float> freqs;
    for (const auto& n : notches_)
        if (n.isActive() || n.isReleasing())
            freqs.push_back (n.getFrequency());
    return freqs;
}

} // namespace DeFeedback