/*
  DeFeedback V2.1 - Goertzel Feedback Detector Implementation
  Zero-latency per-bin magnitude detection with hold-and-release logic
*/
#include "GoertzelDetector.h"
#include <cmath>
#include <algorithm>

namespace DeFeedback
{

void GoertzelDetector::prepare (double sampleRate, int blockSize)
{
    sampleRate_  = sampleRate;
    blockSize_   = blockSize;
    computeGoertzelBins();
    reset();
}

void GoertzelDetector::setMode (Mode mode)
{
    mode_ = mode;
    auto cfg = getModeConfig (mode);
    thresholdDb_ = cfg.feedbackThreshold;
    holdRequired_ = cfg.detectionHoldFrames;
    computeGoertzelBins();
}

void GoertzelDetector::setSensitivity (float s)
{
    sensitivity_ = std::clamp (s, 0.0f, 1.0f);
    thresholdDb_ = getModeConfig (mode_).feedbackThreshold * (1.0f - sensitivity_ * 0.6f);
}

void GoertzelDetector::setThreshold (float thresholdDb)
{
    thresholdDb_ = thresholdDb;
}

void GoertzelDetector::computeGoertzelBins()
{
    auto cfg = getModeConfig (mode_);
    float binWidth = cfg.goertzelBinWidth;
    int numBins = static_cast<int> ((maxFeedbackHz - minFeedbackHz) / binWidth);

    bins_.resize (numBins);
    float freq = minFeedbackHz;
    for (int i = 0; i < numBins; ++i)
    {
        float k = freq * static_cast<float> (blockSize_) / static_cast<float> (sampleRate_);
        bins_[i].coeff  = 2.0f * std::cos (2.0f * 3.14159265358979323846f * k / static_cast<float> (blockSize_));
        bins_[i].freqHz = freq;
        freq += binWidth;
    }
}

float GoertzelDetector::goertzelMag (const float* samples, int numSamples, float targetFreq) const
{
    float k = targetFreq * static_cast<float> (numSamples) / static_cast<float> (sampleRate_);
    float w = 2.0f * 3.14159265358979323846f * k / static_cast<float> (numSamples);
    float coeff = 2.0f * std::cos (w);
    float s1 = 0.0f, s2 = 0.0f;

    for (int i = 0; i < numSamples; ++i)
    {
        float s0 = samples[i] + coeff * s1 - s2;
        s2 = s1;
        s1 = s0;
    }

    return s1 * s1 + s2 * s2 - coeff * s1 * s2;
}

const std::vector<GoertzelDetector::DetectedTone>& GoertzelDetector::detect (const float* samples, int numSamples)
{
    // Update running average energy (for adaptive threshold)
    float energy = 0.0f;
    for (int i = 0; i < numSamples; ++i)
        energy += samples[i] * samples[i];
    energy /= static_cast<float> (numSamples);
    runningAvgEnergy_ += alphaEnergy_ * (energy - runningAvgEnergy_);
    runningAvgEnergy_ = std::max (runningAvgEnergy_, 1e-10f);
    float refDb = 10.0f * std::log10 (runningAvgEnergy_);

    float binWidth = getModeConfig (mode_).goertzelBinWidth;
    float mergeDist = binWidth * 0.6f;

    // --- Mark all current detections as "not yet confirmed this frame" ---
    for (auto& det : currentDetections_)
        det.holdCount = 0;  // will be set to >0 if re-detected

    // --- Evaluate each Goertzel bin ---
    for (const auto& bin : bins_)
    {
        float mag    = goertzelMag (samples, numSamples, bin.freqHz);
        float magDb  = 10.0f * std::log10 (std::max (mag, 1e-10f));
        float relDb  = magDb - refDb;

        if (relDb <= thresholdDb_)
            continue;

        // Find matching existing detection
        bool matched = false;
        for (auto& det : currentDetections_)
        {
            if (std::abs (det.frequency - bin.freqHz) < mergeDist)
            {
                det.magnitudeDb = magDb;
                det.holdCount   = std::max (det.holdCount + 1, 1);
                matched = true;
                break;
            }
        }

        // New detection: add with holdCount=1 (must persist holdRequired_ frames)
        if (!matched)
        {
            DetectedTone dt;
            dt.frequency   = bin.freqHz;
            dt.magnitudeDb = magDb;
            dt.holdCount   = 1;
            currentDetections_.push_back (dt);
        }
    }

    // --- Remove detections that lost energy (holdCount == 0 means not re-detected this frame) ---
    // But keep them if they were recently confirmed (holdCount >= holdRequired_ for hysteresis)
    // The FeedbackSuppressor handles the actual notch release timing
    currentDetections_.erase (
        std::remove_if (currentDetections_.begin(), currentDetections_.end(),
            [this] (const DetectedTone& dt)
            {
                // Remove if: never confirmed (holdCount < holdRequired_) and lost this frame
                // OR was confirmed but now lost for holdRequired_ consecutive frames
                return dt.holdCount == 0;
            }),
        currentDetections_.end());

    // --- Sort by magnitude descending, limit to maxNotches ---
    std::sort (currentDetections_.begin(), currentDetections_.end(),
        [] (const DetectedTone& a, const DetectedTone& b) { return a.magnitudeDb > b.magnitudeDb; });

    if (static_cast<int> (currentDetections_.size()) > maxNotches)
        currentDetections_.resize (maxNotches);

    return currentDetections_;
}

void GoertzelDetector::reset()
{
    currentDetections_.clear();
    pendingDetections_.clear();
    runningAvgEnergy_ = 1e-10f;
}

} // namespace DeFeedback