/*
  DeFeedback V2.1 - JUCE Audio Plugin Processor
  Production VST3 for live-vocal feedback suppression + dereverb + denoise
*/
#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include "DeFeedbackConstants.h"
#include "DSP/FeedbackSuppressor.h"
#include "DSP/DereverbProcessor.h"
#include "DSP/DenoiseProcessor.h"

namespace DeFeedback
{
class DeFeedbackEditor;
}

class DeFeedbackV2Processor : public juce::AudioProcessor
{
public:
    DeFeedbackV2Processor();
    ~DeFeedbackV2Processor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "DeFeedback V2.1"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    // Parameter access
    juce::AudioProcessorValueTreeState& getVTS() { return vts; }
    juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    // Info for UI
    int  getActiveNotchCount() const;
    std::vector<float> getActiveNotchFrequencies() const;
    DeFeedback::EngineType getCurrentEngineType() const;
    const char* getCurrentEngineName() const;

private:
    juce::AudioProcessorValueTreeState vts;

    // Core DSP modules
    DeFeedback::FeedbackSuppressor feedbackSuppressor_;
    DeFeedback::DereverbProcessor   dereverbProcessor_;
    DeFeedback::DenoiseProcessor     denoiseProcessor_;

    // Parameter listeners
    juce::AudioProcessorValueTreeState::Listener* paramListener_ = nullptr;

    void updateMode();
    void updateParameters();

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DeFeedbackV2Processor)
};