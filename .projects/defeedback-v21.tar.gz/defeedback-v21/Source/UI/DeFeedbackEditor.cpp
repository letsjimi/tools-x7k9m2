/*
  DeFeedback V2.1 - Plugin Editor Implementation
*/
#include "DeFeedbackEditor.h"

namespace DeFeedback
{

DeFeedbackEditor::DeFeedbackEditor (DeFeedbackV2Processor& proc)
    : AudioProcessorEditor (proc),
      processor_ (proc),
      modeSelector_ (proc.getVTS()),
      engineSelector_ (proc.getVTS())
{
    // Window size
    setSize (520, 480);

    // Title
    titleLabel_.setText ("DeFeedback V2.1", juce::dontSendNotification);
    titleLabel_.setColour (juce::Label::textColourId, juce::Colour (0xff4fc3f7));
    titleLabel_.setFont (juce::Font (18.0f, juce::Font::bold));
    titleLabel_.setJustificationType (juce::Justification::centred);
    addAndMakeVisible (titleLabel_);

    // Section labels
    auto sectionStyle = [] (juce::Label& l, const juce::String& text)
    {
        l.setText (text, juce::dontSendNotification);
        l.setColour (juce::Label::textColourId, juce::Colour (0xff80c0e0));
        l.setFont (juce::Font (13.0f, juce::Font::bold));
        l.setJustificationType (juce::Justification::centredLeft);
    };
    sectionStyle (feedbackSectionLabel_, "FEEDBACK SUPPRESSION");
    sectionStyle (noiseSectionLabel_,    "NOISE & REVERB");
    sectionStyle (outputSectionLabel_,   "OUTPUT");
    addAndMakeVisible (feedbackSectionLabel_);
    addAndMakeVisible (noiseSectionLabel_);
    addAndMakeVisible (outputSectionLabel_);

    // Mode selector
    addAndMakeVisible (modeSelector_);

    // Engine selector
    addAndMakeVisible (engineSelector_);

    // Parameter sliders (vertical knobs)
    auto& vts = processor_.getVTS();
    strengthSlider_     = std::make_unique<ParameterSlider> (vts, ParamIDs::strength,    "Strength");
    maxNotchesSlider_   = std::make_unique<ParameterSlider> (vts, ParamIDs::maxNotches,  "Max Notches");
    notchQSlider_       = std::make_unique<ParameterSlider> (vts, ParamIDs::notchQ,      "Notch Q");
    releaseSlider_      = std::make_unique<ParameterSlider> (vts, ParamIDs::release,     "Release");
    sensitivitySlider_  = std::make_unique<ParameterSlider> (vts, ParamIDs::sensitivity,  "Sensitivity");
    noiseAmountSlider_  = std::make_unique<ParameterSlider> (vts, ParamIDs::noiseAmount,  "Noise Amt");
    dereverbAmountSlider_ = std::make_unique<ParameterSlider> (vts, ParamIDs::dereverbAmount, "Dereverb Amt");
    outputTrimSlider_   = std::make_unique<ParameterSlider> (vts, ParamIDs::outputTrim,   "Trim dB");

    addAndMakeVisible (*strengthSlider_);
    addAndMakeVisible (*maxNotchesSlider_);
    addAndMakeVisible (*notchQSlider_);
    addAndMakeVisible (*releaseSlider_);
    addAndMakeVisible (*sensitivitySlider_);
    addAndMakeVisible (*noiseAmountSlider_);
    addAndMakeVisible (*dereverbAmountSlider_);
    addAndMakeVisible (*outputTrimSlider_);

    // Status labels
    notchCountLabel_.setColour (juce::Label::textColourId, juce::Colour (0xff4fc3f7));
    notchCountLabel_.setFont (juce::Font (11.0f));
    notchCountLabel_.setJustificationType (juce::Justification::centredLeft);
    addAndMakeVisible (notchCountLabel_);

    notchFreqsLabel_.setColour (juce::Label::textColourId, juce::Colour (0xff808090));
    notchFreqsLabel_.setFont (juce::Font (10.0f));
    notchFreqsLabel_.setJustificationType (juce::Justification::centredLeft);
    addAndMakeVisible (notchFreqsLabel_);

    engineNameLabel_.setColour (juce::Label::textColourId, juce::Colour (0xff808090));
    engineNameLabel_.setFont (juce::Font (10.0f));
    engineNameLabel_.setJustificationType (juce::Justification::centredLeft);
    addAndMakeVisible (engineNameLabel_);

    // Start timer for status updates (~10 Hz)
    startTimer (100);
}

DeFeedbackEditor::~DeFeedbackEditor()
{
    stopTimer();
}

void DeFeedbackEditor::paint (juce::Graphics& g)
{
    // Dark background
    g.fillAll (juce::Colour (0xff12121e));

    // Title bar
    g.setColour (juce::Colour (0xff1a1a2e));
    g.fillRect (0, 0, getWidth(), 36);
    g.setColour (juce::Colour (0xff4fc3f7));
    g.drawLine (0, 36, getWidth(), 36, 1.0f);

    // Section separators
    g.setColour (juce::Colour (0xff2a2a4a));
    g.drawHorizontalLine (160, 8, getWidth() - 8);
    g.drawHorizontalLine (320, 8, getWidth() - 8);
}

void DeFeedbackEditor::resized()
{
    auto area = getLocalBounds();

    // Title
    titleLabel_.setBounds (area.removeFromTop (36));

    // Mode selector
    auto modeArea = area.removeFromTop (50);
    modeSelector_.setBounds (modeArea.reduced (8, 2));

    // Feedback section
    feedbackSectionLabel_.setBounds (area.removeFromTop (16).reduced (8, 0));

    // Feedback sliders row
    auto fbRow = area.removeFromTop (110).reduced (4);
    int sliderW = fbRow.getWidth() / 5;
    strengthSlider_->setBounds     (fbRow.removeFromLeft (sliderW).reduced (2));
    sensitivitySlider_->setBounds  (fbRow.removeFromLeft (sliderW).reduced (2));
    maxNotchesSlider_->setBounds   (fbRow.removeFromLeft (sliderW).reduced (2));
    notchQSlider_->setBounds       (fbRow.removeFromLeft (sliderW).reduced (2));
    releaseSlider_->setBounds      (fbRow.reduced (2));

    // Notch status
    auto statusArea = area.removeFromTop (20).reduced (8, 0);
    notchCountLabel_.setBounds (statusArea.removeFromLeft (100));
    notchFreqsLabel_.setBounds  (statusArea);

    // Noise section
    noiseSectionLabel_.setBounds (area.removeFromTop (16).reduced (8, 0));

    // Engine selector
    auto engArea = area.removeFromTop (42).reduced (8, 2);
    engineSelector_.setBounds (engArea);

    // Noise + Dereverb sliders
    auto ndRow = area.removeFromTop (110).reduced (4);
    int ndSliderW = ndRow.getWidth() / 2;
    noiseAmountSlider_->setBounds    (ndRow.removeFromLeft (ndSliderW).reduced (2));
    dereverbAmountSlider_->setBounds (ndRow.reduced (2));

    engineNameLabel_.setBounds (area.removeFromTop (16).reduced (8, 0));

    // Output section
    outputSectionLabel_.setBounds (area.removeFromTop (16).reduced (8, 0));
    outputTrimSlider_->setBounds  (area.removeFromTop (80).reduced (4, 2));
}

void DeFeedbackEditor::timerCallback()
{
    // Update notch count display
    int activeNotches = processor_.getActiveNotchCount();
    notchCountLabel_.setText ("Notches: " + juce::String (activeNotches), juce::dontSendNotification);

    // Show active frequencies
    auto freqs = processor_.getActiveNotchFrequencies();
    juce::String freqStr;
    for (size_t i = 0; i < freqs.size() && i < 4; ++i)
    {
        if (i > 0) freqStr += ", ";
        freqStr += juce::String (freqs[i], 0) + "Hz";
    }
    if (freqs.size() > 4)
        freqStr += " ...";
    if (freqs.empty())
        freqStr = "None active";
    notchFreqsLabel_.setText (freqStr, juce::dontSendNotification);

    // Engine name
    engineNameLabel_.setText ("Engine: " + juce::String (processor_.getCurrentEngineName()),
                               juce::dontSendNotification);
}

} // namespace DeFeedback