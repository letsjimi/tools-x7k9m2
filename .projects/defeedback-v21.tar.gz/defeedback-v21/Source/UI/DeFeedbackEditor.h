/*
  DeFeedback V2.1 - Plugin Editor (Main GUI)
*/
#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_gui_basics/juce_gui_basics.h>
#include "../PluginProcessor.h"
#include "ModeSelector.h"
#include "EngineSelector.h"
#include "ParameterSlider.h"
#include "../DeFeedbackConstants.h"

namespace DeFeedback
{

class DeFeedbackEditor : public juce::AudioProcessorEditor,
                         public juce::Timer
{
public:
    DeFeedbackEditor (DeFeedbackV2Processor& proc);
    ~DeFeedbackEditor() override;

    void paint (juce::Graphics& g) override;
    void resized() override;
    void timerCallback() override;

private:
    DeFeedbackV2Processor& processor_;

    // Header
    juce::Label titleLabel_;

    // Mode selector
    ModeSelector modeSelector_;

    // Engine selector
    EngineSelector engineSelector_;

    // Parameter sliders
    std::unique_ptr<ParameterSlider> strengthSlider_;
    std::unique_ptr<ParameterSlider> maxNotchesSlider_;
    std::unique_ptr<ParameterSlider> notchQSlider_;
    std::unique_ptr<ParameterSlider> releaseSlider_;
    std::unique_ptr<ParameterSlider> sensitivitySlider_;
    std::unique_ptr<ParameterSlider> noiseAmountSlider_;
    std::unique_ptr<ParameterSlider> dereverbAmountSlider_;
    std::unique_ptr<ParameterSlider> outputTrimSlider_;

    // Status display
    juce::Label notchCountLabel_;
    juce::Label notchFreqsLabel_;
    juce::Label engineNameLabel_;

    // Section headers
    juce::Label feedbackSectionLabel_;
    juce::Label noiseSectionLabel_;
    juce::Label outputSectionLabel_;
};

} // namespace DeFeedback