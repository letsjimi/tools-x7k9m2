/*
  DeFeedback V2.1 - Mode Selector Implementation
*/
#include "ModeSelector.h"
#include "../DeFeedbackConstants.h"

namespace DeFeedback
{

ModeSelector::ModeSelector (juce::AudioProcessorValueTreeState& vts)
    : vts_ (vts)
{
    ultraBtn.setClickingTogglesState (true);
    balancedBtn.setClickingTogglesState (true);
    qualityBtn.setClickingTogglesState (true);
    balancedBtn.setToggleState (true, juce::dontSendNotification);

    ultraBtn.addListener (this);
    balancedBtn.addListener (this);
    qualityBtn.addListener (this);

    modeLabel.setText ("Mode", juce::dontSendNotification);
    modeLabel.setColour (juce::Label::textColourId, juce::Colour (0xffb0b0c0));
    modeLabel.setFont (juce::Font (12.0f, juce::Font::bold));
    modeLabel.setJustificationType (juce::Justification::centred);

    addAndMakeVisible (ultraBtn);
    addAndMakeVisible (balancedBtn);
    addAndMakeVisible (qualityBtn);
    addAndMakeVisible (modeLabel);
}

ModeSelector::~ModeSelector()
{
    ultraBtn.removeListener (this);
    balancedBtn.removeListener (this);
    qualityBtn.removeListener (this);
}

void ModeSelector::resized()
{
    auto area = getLocalBounds();
    modeLabel.setBounds (area.removeFromTop (20));

    int btnW = area.getWidth() / 3;
    auto row = area.reduced (2);
    ultraBtn.setBounds    (row.removeFromLeft (btnW).reduced (2));
    balancedBtn.setBounds (row.removeFromLeft (btnW).reduced (2));
    qualityBtn.setBounds  (row.reduced (2));
}

void ModeSelector::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff1a1a2e));
    g.setColour (juce::Colour (0xff3a3a5a));
    g.drawRoundedRectangle (getLocalBounds().toFloat(), 4.0f, 1.0f);
}

void ModeSelector::buttonClicked (juce::Button* btn)
{
    // Radio-button behavior
    ultraBtn.setToggleState    (btn == &ultraBtn,    juce::dontSendNotification);
    balancedBtn.setToggleState (btn == &balancedBtn, juce::dontSendNotification);
    qualityBtn.setToggleState  (btn == &qualityBtn,  juce::dontSendNotification);

    if (btn == &ultraBtn)       currentMode_ = 0;
    else if (btn == &balancedBtn) currentMode_ = 1;
    else                          currentMode_ = 2;

    // Update parameter
    if (auto* param = vts_.getParameter (ParamIDs::mode))
        param->setValueNotifyingHost (static_cast<float> (currentMode_) / 2.0f);

    updateToggleState();
}

void ModeSelector::updateToggleState()
{
    auto activeColour  = juce::Colour (0xff4fc3f7);
    auto inactiveColour = juce::Colour (0xff3a3a5a);
    auto textActive    = juce::Colour (0xff1a1a2e);
    auto textInactive  = juce::Colour (0xff808090);

    ultraBtn.setColour    (juce::TextButton::buttonColourId, currentMode_ == 0 ? activeColour : inactiveColour);
    ultraBtn.setColour    (juce::TextButton::textColourOffId, currentMode_ == 0 ? textActive : textInactive);
    balancedBtn.setColour (juce::TextButton::buttonColourId, currentMode_ == 1 ? activeColour : inactiveColour);
    balancedBtn.setColour (juce::TextButton::textColourOffId, currentMode_ == 1 ? textActive : textInactive);
    qualityBtn.setColour  (juce::TextButton::buttonColourId, currentMode_ == 2 ? activeColour : inactiveColour);
    qualityBtn.setColour  (juce::TextButton::textColourOffId, currentMode_ == 2 ? textActive : textInactive);
}

} // namespace DeFeedback