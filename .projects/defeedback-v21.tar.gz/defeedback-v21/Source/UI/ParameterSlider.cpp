/*
  DeFeedback V2.1 - Parameter Slider Implementation
*/
#include "ParameterSlider.h"

namespace DeFeedback
{

ParameterSlider::ParameterSlider (juce::AudioProcessorValueTreeState& vts,
                                   const juce::String& paramID,
                                   const juce::String& labelText,
                                   bool isVertical)
    : vts_ (vts), paramID_ (paramID)
{
    slider.setSliderStyle (isVertical ? juce::Slider::LinearVertical
                                       : juce::Slider::LinearHorizontal);
    slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 60, 20);
    slider.setColour (juce::Slider::trackColourId,    juce::Colour (0xff4fc3f7));
    slider.setColour (juce::Slider::thumbColourId,    juce::Colour (0xffe0e0e0));
    slider.setColour (juce::Slider::backgroundColourId, juce::Colour (0xff2a2a3a));

    label.setText (labelText, juce::dontSendNotification);
    label.setColour (juce::Label::textColourId, juce::Colour (0xffb0b0c0));
    label.setJustificationType (juce::Justification::centred);
    label.setFont (juce::Font (11.0f));

    attachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>
        (vts_, paramID_, slider);

    addAndMakeVisible (slider);
    addAndMakeVisible (label);
}

ParameterSlider::~ParameterSlider()
{
    vts_.removeParameterListener (paramID_, this);
}

void ParameterSlider::resized()
{
    auto area = getLocalBounds();

    if (slider.getSliderStyle() == juce::Slider::LinearVertical)
    {
        label.setBounds (area.removeFromTop (18));
        slider.setBounds (area.reduced (4));
    }
    else
    {
        label.setBounds (area.removeFromLeft (80));
        slider.setBounds (area.reduced (2));
    }
}

void ParameterSlider::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff1a1a2e));
}

void ParameterSlider::parameterChanged (const juce::String&, float)
{
    // Slider attachment handles this
}

} // namespace DeFeedback