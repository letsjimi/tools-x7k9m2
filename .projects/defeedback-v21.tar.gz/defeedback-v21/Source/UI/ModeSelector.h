/*
  DeFeedback V2.1 - Mode Selector Component
  Three-way toggle: Ultra / Balanced / Quality
*/
#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>

namespace DeFeedback
{

class ModeSelector : public juce::Component,
                     public juce::Button::Listener
{
public:
    ModeSelector (juce::AudioProcessorValueTreeState& vts);
    ~ModeSelector() override;

    void resized() override;
    void paint (juce::Graphics& g) override;
    void buttonClicked (juce::Button* btn) override;

private:
    void updateToggleState();

    juce::AudioProcessorValueTreeState& vts_;
    juce::TextButton ultraBtn    { "ULTRA" };
    juce::TextButton balancedBtn { "BALANCED" };
    juce::TextButton qualityBtn  { "QUALITY" };
    juce::Label      modeLabel   { {}, "Mode" };

    int currentMode_ = 1; // Balanced default
};

} // namespace DeFeedback