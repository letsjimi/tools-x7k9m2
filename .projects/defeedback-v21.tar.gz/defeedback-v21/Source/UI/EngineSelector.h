/*
  DeFeedback V2.1 - Engine Selector Component
  Dropdown for noise-reduction engine selection
*/
#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>

namespace DeFeedback
{

class EngineSelector : public juce::Component
{
public:
    EngineSelector (juce::AudioProcessorValueTreeState& vts);
    ~EngineSelector() override = default;

    void resized() override;
    void paint (juce::Graphics& g) override;

private:
    juce::AudioProcessorValueTreeState& vts_;
    juce::Label     engineLabel { {}, "Noise Engine" };
    juce::ComboBox  engineCombo;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> attachment;
};

} // namespace DeFeedback