/*
  DeFeedback V2.1 - Parameter Slider Component
*/
#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>

namespace DeFeedback
{

class ParameterSlider : public juce::Component,
                        public juce::AudioProcessorValueTreeState::Listener
{
public:
    ParameterSlider (juce::AudioProcessorValueTreeState& vts, const juce::String& paramID,
                     const juce::String& label, bool isVertical = true);
    ~ParameterSlider() override;

    void resized() override;
    void paint (juce::Graphics& g) override;

    void parameterChanged (const juce::String& paramID, float newValue) override;

    juce::Slider& getSlider() { return slider; }

private:
    juce::AudioProcessorValueTreeState& vts_;
    juce::String paramID_;
    juce::Slider slider;
    juce::Label  label;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachment;
};

} // namespace DeFeedback