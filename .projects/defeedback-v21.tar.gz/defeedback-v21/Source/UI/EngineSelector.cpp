/*
  DeFeedback V2.1 - Engine Selector Implementation
*/
#include "EngineSelector.h"

namespace DeFeedback
{

EngineSelector::EngineSelector (juce::AudioProcessorValueTreeState& vts)
    : vts_ (vts)
{
    engineLabel.setText ("Noise Engine", juce::dontSendNotification);
    engineLabel.setColour (juce::Label::textColourId, juce::Colour (0xffb0b0c0));
    engineLabel.setFont (juce::Font (11.0f));
    engineLabel.setJustificationType (juce::Justification::centredLeft);

    engineCombo.addItem ("WebRTC",       1);
    engineCombo.addItem ("RNNoise",      2);
    engineCombo.addItem ("DeepFilterNet", 3);
    engineCombo.addItem ("SpeexDSP",     4);
    engineCombo.setSelectedId (1);

    engineCombo.setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff2a2a3a));
    engineCombo.setColour (juce::ComboBox::textColourId,      juce::Colour (0xffe0e0e0));
    engineCombo.setColour (juce::ComboBox::outlineColourId,   juce::Colour (0xff4fc3f7));

    attachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>
        (vts_, DeFeedback::ParamIDs::noiseEngine, engineCombo);

    addAndMakeVisible (engineLabel);
    addAndMakeVisible (engineCombo);
}

void EngineSelector::resized()
{
    auto area = getLocalBounds();
    engineLabel.setBounds (area.removeFromTop (18));
    engineCombo.setBounds (area.reduced (2));
}

void EngineSelector::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff1a1a2e));
}

} // namespace DeFeedback